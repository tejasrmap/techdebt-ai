import os
import uuid
import tempfile
import asyncio
import multiprocessing
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta
import pytest
from pydantic import ValidationError
from fastapi.testclient import TestClient

from app.config import (
    Settings,
    DEFAULT_DEV_SECRET,
    PROHIBITED_SECRET_DEFAULTS,
    PROHIBITED_PLACEHOLDER_SUBSTRINGS,
    contains_prohibited_placeholder
)
from app.database import SessionLocal
from app.models.all_models import (
    Organization, User, Project, ScheduledReview, ReviewJob,
    HistoricalAssessment, Assessment, DistributedLock
)
from app.services.scheduler_service import (
    run_scheduled_job,
    acquire_distributed_lock,
    release_distributed_lock,
    renew_distributed_lock,
    register_job_in_scheduler,
    scheduler
)
from app.services.ai_analyzer import AITechnologyDebtAnalyzer
from app.services.memento_adapter import MementoMemoryAdapter
from app.main import app

client = TestClient(app)

def get_or_create_test_org(db) -> Organization:
    org = db.query(Organization).first()
    if not org:
        org = Organization(name="Test Org " + uuid.uuid4().hex[:6], slug="test-org-" + uuid.uuid4().hex[:6])
        db.add(org)
        db.commit()
        db.refresh(org)
    return org

def get_or_create_test_project(db) -> Project:
    org = get_or_create_test_org(db)
    proj = db.query(Project).filter(Project.org_id == org.id).first()
    if not proj:
        proj = Project(org_id=org.id, name="Test Project " + uuid.uuid4().hex[:6])
        db.add(proj)
        db.commit()
        db.refresh(proj)
    return proj


# -------------------------------------------------------------
# 1. DOCKER SECRETS & PLACEHOLDER VALIDATION TESTS
# -------------------------------------------------------------
def test_production_rejects_default_secrets():
    """Verify production configuration rejects known default secret keys and weak values."""
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": DEFAULT_DEV_SECRET,
        "ENCRYPTION_KEY": "a" * 32,
        "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="FATAL SECURITY VIOLATION"):
            Settings()

    # Reject short secret key (< 32 characters)
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "short-secret-key-too-brief",
        "ENCRYPTION_KEY": "a" * 32,
        "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="at least 32 characters long"):
            Settings()

def test_production_rejects_all_placeholder_secrets():
    """
    Verify production configuration strictly rejects template placeholders from .env.example:
    - replace-with
    - your-secret
    - example-key
    - change-me
    - changeme
    - default
    """
    placeholders = [
        "replace-with-at-least-32-char-random-jwt-secret-key-prod",
        "your-secret-key-goes-here-32chars-long",
        "example-key-value-for-testing-prod-32c",
        "change-me-before-deploying-production-32c",
        "changeme-12345678901234567890123456",
        "default-secret-production-key-32chars"
    ]
    for ph in placeholders:
        with patch.dict(os.environ, {
            "ENVIRONMENT": "production",
            "SECRET_KEY": ph,
            "ENCRYPTION_KEY": "a-strong-random-encryption-key-valid",
            "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
        }):
            with pytest.raises(ValueError, match="strictly rejected"):
                Settings()

def test_sample_env_example_cannot_launch_production():
    """Ensure that the exact sample .env.example cannot be used unchanged in production."""
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "replace-with-at-least-32-char-random-jwt-secret-key-prod",
        "ENCRYPTION_KEY": "replace-with-at-least-32-char-random-fernet-key-prod",
        "DATABASE_URL": "postgresql://postgres:replace-with-strong-db-password-in-production@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="strictly rejected"):
            Settings()

def test_production_rejects_default_db_password():
    """Verify production rejects known default postgres passwords in DATABASE_URL."""
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "a-strong-random-production-secret-key-that-is-long-enough",
        "ENCRYPTION_KEY": "a-strong-production-fernet-key-valid",
        "DATABASE_URL": "postgresql://postgres:postgrespassword@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="DATABASE_URL must not use default"):
            Settings()


# -------------------------------------------------------------
# 2. SAFE DATABASE MIGRATION TESTS (ISOLATED DISPOSABLE DATABASE)
# -------------------------------------------------------------
def assert_safe_test_database(url: str):
    """Safeguard: Refuse to execute destructive migration tests against production databases."""
    lower_url = url.lower()
    if "production" in lower_url or (not "test" in lower_url and not "temp" in lower_url and not "disposable" in lower_url):
        raise ValueError(f"ABORT: Destructive migration test cannot run against non-test database URL: {url}")

def test_migration_safeguard_rejects_production_urls():
    """Verify safeguard rejects production database URLs for migration tests."""
    with pytest.raises(ValueError, match="ABORT: Destructive migration test cannot run"):
        assert_safe_test_database("postgresql://admin:secret@production-db.company.internal:5432/techdebt")
    with pytest.raises(ValueError, match="ABORT: Destructive migration test cannot run"):
        assert_safe_test_database("postgresql://user:pass@db:5432/techdebt_db")

def test_alembic_startup_fails_on_migration_error():
    """Verify application startup fails if Alembic migration fails without falling back to create_all."""
    from app.main import lifespan
    with patch("alembic.command.upgrade", side_effect=Exception("Simulated schema migration syntax error")):
        with patch.object(app, "router"):
            async def run():
                async with lifespan(app):
                    pass
            with pytest.raises(RuntimeError, match="Application startup aborted: Alembic migrations failed"):
                asyncio.run(run())

def test_safe_database_migration_downgrade_and_upgrade_on_disposable_db():
    """
    Test Alembic rollback to base and re-upgrade to head on an isolated disposable test database.
    Production and development databases (techdebt.db) are strictly preserved and untouched.
    """
    from alembic.config import Config
    from alembic import command
    from sqlalchemy import create_engine, inspect

    # Create isolated disposable SQLite database file in OS temp directory
    disposable_file = os.path.join(tempfile.gettempdir(), f"disposable_migration_{uuid.uuid4().hex}.db")
    disposable_url = f"sqlite:///{disposable_file}"
    assert_safe_test_database(disposable_url)

    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ini_path = os.path.join(base_dir, "alembic.ini")
    alembic_cfg = Config(ini_path)
    alembic_cfg.set_main_option("script_location", os.path.join(base_dir, "alembic"))
    alembic_cfg.set_main_option("sqlalchemy.url", disposable_url)

    try:
        # 1. Clean upgrade to head on disposable DB
        command.upgrade(alembic_cfg, "head")

        engine = create_engine(disposable_url)
        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
        assert "organizations" in tables
        assert "distributed_locks" in tables
        assert "assessments" in tables
        engine.dispose()

        # 2. Downgrade to base on disposable DB
        command.downgrade(alembic_cfg, "base")

        engine = create_engine(disposable_url)
        inspector = inspect(engine)
        tables_after_downgrade = set(inspector.get_table_names())
        assert "organizations" not in tables_after_downgrade
        assert "distributed_locks" not in tables_after_downgrade
        engine.dispose()

        # 3. Re-upgrade to head on disposable DB
        command.upgrade(alembic_cfg, "head")

        engine = create_engine(disposable_url)
        inspector = inspect(engine)
        tables_reupgraded = set(inspector.get_table_names())
        assert "organizations" in tables_reupgraded
        assert "distributed_locks" in tables_reupgraded
        engine.dispose()

    finally:
        # Clean up temporary disposable DB
        if os.path.exists(disposable_file):
            try:
                os.remove(disposable_file)
            except Exception:
                pass


# -------------------------------------------------------------
# 3. SCHEDULER: GENUINE MULTIPROCESSING CONCURRENCY & LEASES
# -------------------------------------------------------------
def _run_worker_job_in_process(schedule_id: str, worker_id: str, queue: multiprocessing.Queue):
    """Independent worker process entry point for genuine multiprocessing concurrency test."""
    from app.services.scheduler_service import run_scheduled_job
    from unittest.mock import patch
    from app.models.all_models import Assessment

    async def mock_review(*args, **kwargs):
        # Simulate slight processing duration
        import time
        time.sleep(0.1)
        return Assessment(project_id="test_pid", status="completed", overall_health_score=80.0)

    with patch("app.services.scheduler_service.execute_project_review", side_effect=mock_review):
        executed = run_scheduled_job(schedule_id, worker_id=worker_id)
        queue.put((worker_id, executed))

def test_genuine_multiprocessing_scheduler_concurrency():
    """
    Genuine multiprocessing concurrency test:
    Two separate OS worker processes simultaneously attempt to execute the same scheduled review.
    Verifies that atomic distributed locking allows exactly one worker to execute, while the other is rejected.
    """
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(org_id=org.id, name=f"Multiprocess Proj {uuid.uuid4().hex[:6]}")
        db.add(proj)
        db.commit()

        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Daily",
            cron_expression="0 0 * * *",
            is_active=True
        )
        db.add(schedule)
        db.commit()
        schedule_id = schedule.id

        ctx = multiprocessing.get_context("spawn")
        queue = ctx.Queue()

        p1 = ctx.Process(target=_run_worker_job_in_process, args=(schedule_id, "process_worker_1", queue))
        p2 = ctx.Process(target=_run_worker_job_in_process, args=(schedule_id, "process_worker_2", queue))

        # Launch both independent worker processes simultaneously
        p1.start()
        p2.start()

        p1.join(timeout=10)
        p2.join(timeout=10)

        results = []
        while not queue.empty():
            results.append(queue.get())

        assert len(results) == 2, f"Expected 2 process results, got: {results}"
        executed_count = sum(1 for _, res in results if res is True)
        rejected_count = sum(1 for _, res in results if res is False)

        # Exactly one worker process must have executed the review
        assert executed_count == 1, f"Expected exactly 1 execution, got {executed_count}"
        assert rejected_count == 1, f"Expected exactly 1 rejection, got {rejected_count}"

        # Verify only one completed ReviewJob in database
        jobs = db.query(ReviewJob).filter(ReviewJob.scheduled_review_id == schedule_id).all()
        assert len(jobs) == 1
        assert jobs[0].status == "Completed"

    finally:
        db.close()

def test_lock_renewal_and_long_execution():
    """
    Test safe lease mechanism:
    Verify that an active lease can be renewed during execution longer than 10 minutes.
    """
    db = SessionLocal()
    try:
        lock_key = f"long_exec_lock_{uuid.uuid4().hex[:6]}"
        owner = "long_worker_1"

        # Acquire initial 60-second lease
        acquired = acquire_distributed_lock(db, lock_key, owner, ttl_seconds=60)
        assert acquired is True

        # Check initial expiration
        lock_rec = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        initial_expires = lock_rec.expires_at

        # Renew lease for an additional 900 seconds (15 minutes) for long-running execution
        renewed = renew_distributed_lock(db, lock_key, owner, extension_seconds=900)
        assert renewed is True

        db.refresh(lock_rec)
        assert lock_rec.expires_at > initial_expires
        assert (lock_rec.expires_at - datetime.utcnow()).total_seconds() > 800

        # Non-owner cannot renew lease
        invalid_renew = renew_distributed_lock(db, lock_key, "imposter_worker", extension_seconds=600)
        assert invalid_renew is False

        # Release lock
        released = release_distributed_lock(db, lock_key, owner)
        assert released is True
    finally:
        db.close()

def test_expired_lock_recovery():
    """
    Test that expired locks (e.g. from a crashed worker) are safely reclaimed and acquired by a new worker.
    """
    db = SessionLocal()
    try:
        lock_key = f"expired_recovery_lock_{uuid.uuid4().hex[:6]}"

        # Insert a pre-expired lock (expired 15 minutes ago)
        expired_lock = DistributedLock(
            lock_key=lock_key,
            owner_id="crashed_worker",
            acquired_at=datetime.utcnow() - timedelta(minutes=20),
            expires_at=datetime.utcnow() - timedelta(minutes=10)
        )
        db.add(expired_lock)
        db.commit()

        # New worker attempts to acquire the lock
        acquired = acquire_distributed_lock(db, lock_key, "new_healthy_worker", ttl_seconds=300)
        assert acquired is True

        # Verify ownership was transferred to new worker
        lock_rec = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert lock_rec.owner_id == "new_healthy_worker"
        assert lock_rec.expires_at > datetime.utcnow()

        release_distributed_lock(db, lock_key, "new_healthy_worker")
    finally:
        db.close()

def test_avoid_duplicate_scheduling_during_periodic_sync():
    """
    Verify that periodic schedule synchronization does not recreate jobs or reset cron timers
    when schedule configuration has not changed.
    """
    db = SessionLocal()
    try:
        proj = get_or_create_test_project(db)
        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Weekly",
            cron_expression="0 0 * * 1",
            is_active=True
        )
        db.add(schedule)
        db.commit()

        job_id = f"review_job_{schedule.id}"

        # First registration
        register_job_in_scheduler(schedule)
        first_job = scheduler.get_job(job_id)
        assert first_job is not None

        # Subsequent periodic sync with identical cron expression must NOT recreate or change job instance
        register_job_in_scheduler(schedule)
        second_job = scheduler.get_job(job_id)
        assert second_job is not None
        assert first_job.id == second_job.id

        # Clean up
        scheduler.remove_job(job_id)
    finally:
        db.close()


# -------------------------------------------------------------
# 4. AI PROVIDER VERIFICATION TESTS (AUTHENTICATED PROBES)
# -------------------------------------------------------------
def test_ai_provider_verification_gemini_unconfigured():
    analyzer = AITechnologyDebtAnalyzer(gemini_key="")
    res = asyncio.run(analyzer.verify_connectivity("gemini"))
    assert res["status"] == "unconfigured"
    assert res["connected"] is False

def test_ai_provider_verification_gemini_connected():
    analyzer = AITechnologyDebtAnalyzer(gemini_key="valid-mock-key")
    mock_resp = MagicMock(status_code=200)
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("gemini"))
        assert res["status"] == "connected"
        assert res["connected"] is True

def test_ai_provider_verification_gemini_invalid_key():
    analyzer = AITechnologyDebtAnalyzer(gemini_key="invalid-key")
    mock_resp = MagicMock(status_code=403, text="API key not valid")
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("gemini"))
        assert res["status"] == "invalid_credentials"
        assert res["connected"] is False

def test_ai_provider_verification_gemini_quota_exceeded():
    analyzer = AITechnologyDebtAnalyzer(gemini_key="rate-limited-key")
    mock_resp = MagicMock(status_code=429)
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("gemini"))
        assert res["status"] == "quota_exceeded"
        assert res["connected"] is False

def test_ai_provider_verification_openai_connected():
    analyzer = AITechnologyDebtAnalyzer(openai_key="sk-mock-valid-key")
    mock_resp = MagicMock(status_code=200)
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("openai"))
        assert res["status"] == "connected"
        assert res["connected"] is True

def test_ai_provider_verification_openai_invalid_key():
    analyzer = AITechnologyDebtAnalyzer(openai_key="sk-invalid-key")
    mock_resp = MagicMock(status_code=401)
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("openai"))
        assert res["status"] == "invalid_credentials"
        assert res["connected"] is False


# -------------------------------------------------------------
# 5. MEMENTO INTEGRATION TESTS (MOCKED & LIVE)
# -------------------------------------------------------------
def test_memento_mocked_remote_memory_creation_success():
    """Mocked test: remote memory creation records storage_provider=memento_cloud."""
    mem = MementoMemoryAdapter(api_key="valid-memento-token", endpoint="https://api.memento.ai/v1")
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(org_id=org.id, name=f"Memento Cloud Proj {uuid.uuid4().hex[:6]}")
        db.add(proj)
        db.commit()

        ass = Assessment(project_id=proj.id, status="completed", overall_health_score=90.0)
        db.add(ass)
        db.commit()

        mock_resp = MagicMock(status_code=201)
        with patch("httpx.AsyncClient.post", return_value=mock_resp):
            hist = asyncio.run(mem.record_assessment_snapshot(
                db=db,
                project_id=proj.id,
                assessment_id=ass.id,
                overall_score=90.0,
                risk_classification="Healthy",
                tech_scores=[],
                identified_risks=[]
            ))
            assert hist.storage_provider == "memento_cloud"
            assert hist.sync_status == "synced_to_memento_cloud"
            assert hist.sync_error == ""
    finally:
        db.close()

def test_memento_mocked_remote_memory_retrieval_success():
    """Mocked test: get_historical_memories retrieves cloud memories when available."""
    mem = MementoMemoryAdapter(api_key="valid-memento-token", endpoint="https://api.memento.ai/v1")
    db = SessionLocal()
    try:
        proj = get_or_create_test_project(db)
        cloud_payload = {
            "memories": [
                {"id": "cloud_mem_1", "health_score": 92.0, "risk_classification": "Healthy"}
            ]
        }
        mock_resp = MagicMock(status_code=200, json=lambda: cloud_payload)
        with patch("httpx.AsyncClient.get", return_value=mock_resp):
            memories = asyncio.run(mem.get_historical_memories(db, proj.id))
            assert memories["storage_provider"] == "memento_cloud"
            assert memories["remote_sync_status"] == "synced"
            assert len(memories["memories"]) == 1
    finally:
        db.close()

def test_memento_cloud_failure_retains_truthful_postgresql_fallback():
    """Mocked test: Cloud write failure retains truthful PostgreSQL fallback record."""
    mem = MementoMemoryAdapter(api_key="invalid-memento-token", endpoint="https://api.memento.ai/v1")
    db = SessionLocal()
    try:
        proj = get_or_create_test_project(db)
        ass = Assessment(project_id=proj.id, status="completed", overall_health_score=75.0)
        db.add(ass)
        db.commit()

        # Simulate remote HTTP 500 failure
        mock_resp = MagicMock(status_code=500, text="Internal Server Error")
        with patch("httpx.AsyncClient.post", return_value=mock_resp):
            hist = asyncio.run(mem.record_assessment_snapshot(
                db=db,
                project_id=proj.id,
                assessment_id=ass.id,
                overall_score=75.0,
                risk_classification="Good",
                tech_scores=[],
                identified_risks=[]
            ))
            # Provenance must be PostgreSQL fallback
            assert hist.storage_provider == "postgresql"
            assert hist.sync_status == "sync_failed_fallback_postgresql"
            assert "HTTP 500" in hist.sync_error
    finally:
        db.close()

@pytest.mark.skipif(
    not os.getenv("MEMENTO_API_KEY"),
    reason="MEMENTO_API_KEY environment variable required for live integration test"
)
def test_memento_live_api_connectivity_and_operations():
    """
    Live Memento API integration test.
    Only executed when actual MEMENTO_API_KEY is available in the environment.
    """
    api_key = os.getenv("MEMENTO_API_KEY")
    mem = MementoMemoryAdapter(api_key=api_key)
    res = asyncio.run(mem.verify_connectivity())
    assert "status" in res
    assert "mode" in res
