import logging
import asyncio
import os
import uuid
from datetime import datetime, timedelta
from typing import Optional
from croniter import croniter
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.database import SessionLocal
from app.models.all_models import (
    ScheduledReview, ReviewJob, Project, TechnologyScore,
    RiskFinding, EvidenceSource, Assessment, AuditLog, DistributedLock
)
from app.services.firecrawl_service import FirecrawlIntelligenceService
from app.services.ai_analyzer import AITechnologyDebtAnalyzer
from app.services.memento_adapter import MementoMemoryAdapter

logger = logging.getLogger(__name__)

scheduler = BackgroundScheduler()

def acquire_distributed_lock(db: Session, lock_key: str, owner_id: str, ttl_seconds: int = 600) -> bool:
    """
    Atomically acquire a distributed lock in the database.
    Prevents simultaneous execution across multiple worker processes.
    Expired locks are automatically reclaimed.
    """
    now = datetime.utcnow()
    expires_at = now + timedelta(seconds=ttl_seconds)

    # 1. Clean up expired lock for this key if it exists
    try:
        db.query(DistributedLock).filter(
            DistributedLock.lock_key == lock_key,
            DistributedLock.expires_at <= now
        ).delete(synchronize_session=False)
        db.commit()
    except Exception:
        db.rollback()

    # 2. Attempt atomic insert
    try:
        lock = DistributedLock(
            lock_key=lock_key,
            owner_id=owner_id,
            acquired_at=now,
            expires_at=expires_at
        )
        db.add(lock)
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        return False
    except Exception as e:
        logger.warning(f"Error acquiring lock {lock_key}: {e}")
        db.rollback()
        return False

def release_distributed_lock(db: Session, lock_key: str, owner_id: str) -> bool:
    """Release an active distributed lock owned by owner_id."""
    try:
        deleted = (
            db.query(DistributedLock)
            .filter(
                DistributedLock.lock_key == lock_key,
                DistributedLock.owner_id == owner_id
            )
            .delete(synchronize_session=False)
        )
        db.commit()
        return deleted > 0
    except Exception as e:
        logger.warning(f"Error releasing lock {lock_key}: {e}")
        db.rollback()
        return False

def renew_distributed_lock(db: Session, lock_key: str, owner_id: str, extension_seconds: int = 600) -> bool:
    """
    Extend the expiration time of an active lease held by owner_id.
    Ensures safe lock renewal for reviews executing longer than lease TTL (e.g. > 10 minutes).
    """
    now = datetime.utcnow()
    new_expires_at = now + timedelta(seconds=extension_seconds)
    try:
        updated = (
            db.query(DistributedLock)
            .filter(
                DistributedLock.lock_key == lock_key,
                DistributedLock.owner_id == owner_id,
                DistributedLock.expires_at > now
            )
            .update({"expires_at": new_expires_at})
        )
        db.commit()
        return updated > 0
    except Exception as e:
        logger.warning(f"Error renewing lease {lock_key} for {owner_id}: {e}")
        db.rollback()
        return False

def validate_and_compute_next_run(cron_expr: str) -> datetime:
    """Validate cron expression and return next execution datetime."""
    if not croniter.is_valid(cron_expr):
        raise ValueError(f"Invalid cron expression: '{cron_expr}'")
    iter_obj = croniter(cron_expr, datetime.utcnow())
    return iter_obj.get_next(datetime)

async def execute_project_review(
    project_id: str,
    trigger_type: str = "scheduled",
    db_session: Optional[Session] = None,
    enforce_org_id: Optional[str] = None
) -> Assessment:
    """Core review pipeline executed manually or via scheduler."""
    close_db = False
    if db_session is None:
        db = SessionLocal()
        close_db = True
    else:
        db = db_session

    try:
        query = db.query(Project).filter(Project.id == project_id)
        if enforce_org_id:
            query = query.filter(Project.org_id == enforce_org_id)
        project = query.first()
        if not project:
            raise ValueError(f"Project {project_id} not found or unauthorized")

        from app.services.integration_config_service import (
            get_firecrawl_service_for_org,
            get_ai_analyzer_for_org,
            get_memento_adapter_for_org
        )

        firecrawl_svc = get_firecrawl_service_for_org(project.org_id, db)
        ai_analyzer = get_ai_analyzer_for_org(project.org_id, db)
        memento_adapter = get_memento_adapter_for_org(project.org_id, db)

        # Step 1: Create Assessment record
        assessment = Assessment(
            project_id=project_id,
            trigger_type=trigger_type,
            status="processing",
            overall_health_score=None,
            risk_classification="Healthy",
            confidence_level="High"
        )
        db.add(assessment)
        db.commit()
        db.refresh(assessment)

        # Step 2: Iterate over project technologies & gather intelligence
        total_scores = []
        all_risks = []
        tech_score_records = []

        for p_tech in project.project_technologies:
            tech = p_tech.technology
            # Gather live intelligence / registry metadata
            intel = await firecrawl_svc.gather_technology_intelligence(
                tech_name=tech.name,
                ecosystem=tech.ecosystem,
                installed_version=p_tech.installed_version
            )

            # Update tech with latest registry version if unknown
            if tech.latest_stable_version == "unknown" and intel.get("latest_stable_version"):
                tech.latest_stable_version = intel["latest_stable_version"]
                tech.is_deprecated = intel.get("is_deprecated", False)
                db.commit()

            # Step 3: Run AI / evidence-grounded scoring
            analysis = await ai_analyzer.analyze_technology(
                tech_name=tech.name,
                installed_version=p_tech.installed_version,
                latest_version=intel.get("latest_stable_version", tech.latest_stable_version),
                is_deprecated=intel.get("is_deprecated", tech.is_deprecated),
                evidence_sources=intel.get("evidence_sources", []),
                project_context=project.description
            )

            overall_tech_score = analysis.get("overall_score", 85.0)
            total_scores.append(overall_tech_score)

            # Save TechnologyScore
            score_rec = TechnologyScore(
                assessment_id=assessment.id,
                technology_id=tech.id,
                overall_score=overall_tech_score,
                risk_classification=analysis.get("risk_classification", "Good"),
                maintenance_health=analysis.get("maintenance_health", 90.0),
                security_exposure=analysis.get("security_exposure", 95.0),
                version_currency=analysis.get("version_currency", 90.0),
                community_activity=analysis.get("community_activity", 85.0),
                documentation_quality=analysis.get("documentation_quality", 85.0),
                ecosystem_compatibility=analysis.get("ecosystem_compatibility", 90.0),
                sustainability=analysis.get("sustainability", 90.0),
                upgrade_complexity=analysis.get("upgrade_complexity", 90.0),
                confidence_level=analysis.get("confidence_level", "High"),
                recommended_action=analysis.get("recommended_action", ""),
                upgrade_complexity_level=analysis.get("upgrade_complexity_level", "Low"),
                notes="; ".join(analysis.get("identified_problems", []))
            )
            db.add(score_rec)

            # Save Evidence Sources
            for ev in intel.get("evidence_sources", []):
                ev_rec = EvidenceSource(
                    assessment_id=assessment.id,
                    technology_id=tech.id,
                    url=ev.get("url", ""),
                    title=ev.get("title", tech.name),
                    source_type=ev.get("source_type", "documentation"),
                    reliability_score=ev.get("reliability_score", 1.0),
                    publication_date=ev.get("publication_date"),
                    is_official=ev.get("is_official", True),
                    snippet=ev.get("snippet", "")
                )
                db.add(ev_rec)

            # Save Risk Findings
            for r in analysis.get("risks", []):
                risk_rec = RiskFinding(
                    assessment_id=assessment.id,
                    technology_id=tech.id,
                    project_id=project.id,
                    severity=r.get("severity", "Medium"),
                    title=r.get("title", ""),
                    description=r.get("description", ""),
                    business_impact=r.get("business_impact", ""),
                    technical_impact=r.get("technical_impact", ""),
                    status="Open"
                )
                db.add(risk_rec)
                all_risks.append(r)

            tech_score_records.append({
                "technology_name": tech.name,
                "score": overall_tech_score,
                "classification": analysis.get("risk_classification", "Good")
            })

        # Calculate Project-level composite score
        if not total_scores:
            assessment.overall_health_score = None
            assessment.risk_classification = "Not Assessed"
            assessment.confidence_level = "Unknown"
            assessment.status = "completed"
            assessment.summary = "No technologies detected in project inventory. Please add dependencies or upload a manifest to run an assessment."
            project.last_assessment_date = datetime.utcnow()
            db.commit()
            return assessment

        avg_score = round(sum(total_scores) / len(total_scores), 1)
        from app.services.ai_analyzer import classify_risk
        project_classification = classify_risk(avg_score)

        assessment.overall_health_score = avg_score
        assessment.risk_classification = project_classification
        assessment.status = "completed"
        assessment.summary = (
            f"Assessment completed. Evaluated {len(total_scores)} technologies. "
            f"Overall health score is {avg_score}/100 ({project_classification}). "
            f"Identified {len(all_risks)} actionable risk finding(s)."
        )

        project.last_assessment_date = datetime.utcnow()
        db.commit()

        # Step 4: Record in Memento Memory
        await memento_adapter.record_assessment_snapshot(
            db=db,
            project_id=project.id,
            assessment_id=assessment.id,
            overall_score=avg_score,
            risk_classification=project_classification,
            tech_scores=tech_score_records,
            identified_risks=all_risks,
            project_name=project.name
        )

        return assessment

    except Exception as e:
        logger.error(f"Error executing assessment for project {project_id}: {e}")
        db.rollback()
        if 'assessment' in locals() and assessment:
            assessment.status = "failed"
            assessment.summary = f"Review failed: {str(e)}"
            db.commit()
        raise e
    finally:
        if close_db:
            db.close()

def run_scheduled_job(scheduled_review_id: str, max_retries: int = 2, worker_id: Optional[str] = None) -> bool:
    """
    APScheduler sync worker execution with atomic distributed locking, retries and status logging.
    Returns True if job was executed, False if skipped due to lock or inactive state.
    """
    db = SessionLocal()
    assigned_worker = worker_id or f"worker_{os.getpid()}_{uuid.uuid4().hex[:8]}"
    lock_key = f"review_job_lock_{scheduled_review_id}"
    lock_acquired = False

    try:
        review = db.query(ScheduledReview).filter(ScheduledReview.id == scheduled_review_id).first()
        if not review or not review.is_active:
            return False

        # 1. Atomic distributed lock acquisition
        lock_acquired = acquire_distributed_lock(db, lock_key, assigned_worker, ttl_seconds=600)
        if not lock_acquired:
            logger.info(
                f"Duplicate review execution prevented for schedule {scheduled_review_id}: "
                f"Lock currently held by another worker process."
            )
            return False

        # 2. Secondary check for active Running job
        active_running = (
            db.query(ReviewJob)
            .filter(
                ReviewJob.scheduled_review_id == scheduled_review_id,
                ReviewJob.status == "Running",
                ReviewJob.started_at > datetime.utcnow() - timedelta(minutes=10)
            )
            .first()
        )
        if active_running:
            logger.info(f"Active running job {active_running.id} already in progress for schedule {scheduled_review_id}.")
            return False

        job = ReviewJob(
            scheduled_review_id=scheduled_review_id,
            status="Running",
            started_at=datetime.utcnow()
        )
        db.add(job)
        db.commit()

        # 3. Run review pipeline with retry backoff
        success = False
        last_error = ""
        for attempt in range(max_retries):
            try:
                asyncio.run(execute_project_review(
                    project_id=review.project_id,
                    trigger_type="scheduled",
                    db_session=db
                ))
                success = True
                break
            except Exception as e:
                last_error = str(e)
                logger.warning(f"Review job attempt {attempt + 1} failed for schedule {scheduled_review_id}: {e}")
                import time
                time.sleep(1.0 * (attempt + 1))

        if success:
            job.status = "Completed"
            job.completed_at = datetime.utcnow()
            review.last_run_at = datetime.utcnow()
            review.next_run_at = validate_and_compute_next_run(review.cron_expression)
            db.commit()
            return True
        else:
            job.status = "Failed"
            job.error_message = f"Failed after {max_retries} attempts: {last_error}"
            job.completed_at = datetime.utcnow()
            db.commit()
            return False

    except Exception as e:
        logger.error(f"Error in scheduled job execution: {e}")
        db.rollback()
        return False
    finally:
        if lock_acquired:
            release_distributed_lock(db, lock_key, assigned_worker)
        db.close()

def register_job_in_scheduler(schedule: ScheduledReview):
    """
    Register or update recurring job in APScheduler.
    Prevents duplicate scheduling or timer reset during periodic schedule synchronization.
    """
    job_id = f"review_job_{schedule.id}"
    try:
        existing = scheduler.get_job(job_id)
        if not schedule.is_active:
            if existing:
                scheduler.remove_job(job_id)
                logger.info(f"Removed inactive review job from scheduler: {job_id}")
            return

        trigger = CronTrigger.from_crontab(schedule.cron_expression)
        if existing:
            # If job already exists with matching trigger expression, avoid duplicate rescheduling
            if str(existing.trigger) == str(trigger):
                return
            scheduler.reschedule_job(job_id, trigger=trigger)
            logger.info(f"Updated recurring review job trigger: {job_id} ({schedule.cron_expression})")
        else:
            scheduler.add_job(
                run_scheduled_job,
                trigger=trigger,
                args=[schedule.id],
                id=job_id,
                replace_existing=True
            )
            logger.info(f"Registered recurring review job: {job_id} ({schedule.cron_expression})")
    except Exception as e:
        logger.error(f"Failed to register job {job_id}: {e}")
        raise ValueError(f"Failed to register recurring schedule in APScheduler: {str(e)}")

def unregister_job_from_scheduler(schedule_id: str):
    """Remove recurring job from APScheduler."""
    job_id = f"review_job_{schedule_id}"
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)
        logger.info(f"Removed review job from scheduler: {job_id}")

def restore_all_scheduled_jobs():
    """Restore all active recurring review jobs on application startup."""
    db = SessionLocal()
    try:
        active_reviews = db.query(ScheduledReview).filter(ScheduledReview.is_active == True).all()
        for r in active_reviews:
            try:
                # Update next run at
                r.next_run_at = validate_and_compute_next_run(r.cron_expression)
                register_job_in_scheduler(r)
            except Exception as e:
                logger.warning(f"Could not restore schedule {r.id}: {e}")
        db.commit()
        logger.info(f"Restored {len(active_reviews)} scheduled review jobs.")
    except Exception as e:
        logger.error(f"Error restoring scheduled jobs: {e}")
        db.rollback()
    finally:
        db.close()

def start_scheduler():
    if not scheduler.running:
        scheduler.start()
        restore_all_scheduled_jobs()
