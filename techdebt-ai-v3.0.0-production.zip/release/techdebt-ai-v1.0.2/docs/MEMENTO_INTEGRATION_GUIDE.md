# Memento AI Memory Integration Guide & API Contract

## 1. Overview & Service Contract

TechDebt AI integrates with **Memento AI Memory** (`https://api.memento.ai/v1`) to persist and retrieve longitudinal software technology debt assessments across projects.

When configured, historical snapshots of technology reviews (including overall health scores, individual technology dimension scores, and identified architectural risks) are synchronized to Memento Cloud Memory. If the remote service is unavailable, unreachable, or unconfigured, the system seamlessly and truthfully falls back to local PostgreSQL/SQLite relational storage without interrupting user workflows.

---

## 2. Authentication

Memento AI requires Bearer token authentication on all HTTP endpoints:

```http
Authorization: Bearer <MEMENTO_API_KEY>
Content-Type: application/json
```

- Keys are configured per organization in `IntegrationSetting` and encrypted at rest with Fernet cryptography.
- Keys are never logged in plaintext or exposed in API responses.

---

## 3. Supported API Endpoints

### A. Health & Connectivity Verification
- **Method**: `GET`
- **Path**: `/health`
- **Headers**: `Authorization: Bearer <API_KEY>`
- **Expected Responses**:
  - `200 OK`: Service operational, credentials validated.
  - `401 Unauthorized` / `403 Forbidden`: Invalid or revoked API key.
  - `5xx`: Cloud service temporarily unavailable.

### B. Memory Snapshot Creation
- **Method**: `POST`
- **Path**: `/memories`
- **Headers**: `Authorization: Bearer <API_KEY>`, `Content-Type: application/json`
- **Request Body Schema**:
  ```json
  {
    "project_id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
    "project_name": "Customer Web Portal",
    "overall_health_score": 88.5,
    "risk_classification": "Healthy",
    "technology_scores": [
      {
        "technology_name": "react",
        "overall_score": 92.0,
        "risk_classification": "Healthy"
      }
    ],
    "risks": [
      {
        "severity": "Low",
        "title": "Minor version drift",
        "description": "React 19 available"
      }
    ],
    "recorded_at": "2026-11-06T00:00:00Z"
  }
  ```
- **Responses**:
  - `201 Created` / `200 OK`: Memory snapshot successfully committed to Memento Cloud.
  - `4xx / 5xx`: Remote write failure (triggers automatic PostgreSQL fallback).

### C. Historical Memory Retrieval
- **Method**: `GET`
- **Path**: `/memories?project_id={project_id}&limit={limit}`
- **Headers**: `Authorization: Bearer <API_KEY>`
- **Response Schema**:
  ```json
  {
    "memories": [
      {
        "id": "mem_01hqxyz...",
        "project_id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        "overall_health_score": 88.5,
        "risk_classification": "Healthy",
        "recorded_at": "2026-11-06T00:00:00Z"
      }
    ]
  }
  ```

---

## 4. Truthful Fallback & Provenance Architecture

```mermaid
sequenceDiagram
    participant Review as Review Pipeline
    participant Adapter as MementoMemoryAdapter
    participant Cloud as Memento Cloud API
    participant DB as PostgreSQL Storage

    Review->>Adapter: record_assessment_snapshot()
    alt Memento Configured
        Adapter->>Cloud: POST /memories
        alt Cloud Write Succeeds (HTTP 201)
            Cloud-->>Adapter: 201 Created
            Adapter->>DB: Save snapshot (storage_provider: "memento_cloud", sync_status: "synced_to_memento_cloud")
        else Cloud Write Fails (Timeout/HTTP Error)
            Cloud-->>Adapter: Error / Timeout
            Adapter->>DB: Save snapshot (storage_provider: "postgresql", sync_status: "sync_failed_fallback_postgresql")
        end
    else Memento Not Configured
        Adapter->>DB: Save snapshot (storage_provider: "postgresql", sync_status: "local_postgresql_only")
    end
    DB-->>Adapter: HistoricalAssessment Record
    Adapter-->>Review: Assessment with verified provenance
```

---

## 5. Automated Verification Suites

The implementation is verified through two distinct test layers:
1. **Mocked Unit & Isolation Tests**: Validate remote memory writes, remote retrieval, retry backoffs, and fallback state transitions without external network calls.
2. **Live Integration Tests**: Dynamically execute real HTTP requests against the Memento Cloud API when `MEMENTO_API_KEY` is present in the environment (`@pytest.mark.skipif(not os.getenv("MEMENTO_API_KEY"))`).
