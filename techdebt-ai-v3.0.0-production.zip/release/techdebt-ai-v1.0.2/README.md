# TechDebt AI — Technology Debt Review Assistant

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.100%2B-009688.svg)](https://fastapi.tiangolo.com)
[![React 19](https://img.shields.io/badge/React-19-61DAFB.svg)](https://react.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0%2B-3178C6.svg)](https://www.typescriptlang.org)
[![Tailwind CSS v4](https://img.shields.io/badge/TailwindCSS-v4-38B2AC.svg)](https://tailwindcss.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

**TechDebt AI** is an intelligent, evidence-grounded technology assessment platform engineered for CTOs, engineering managers, and technical architects. It continuously evaluates software dependencies, frameworks, languages, and libraries across 8 weighted categories to pinpoint architectural risk, unmaintained packages, deprecations, and upgrade blockers.

---

## 🌟 Key Features

1. **Enterprise Security & Organization-Aware Integrations**
   - True tenant isolation enforced across all database models, API endpoints, and background jobs.
   - **Organization-Aware API Integrations**: Firecrawl, AI reasoning (OpenAI/Gemini), and Memento memory instances are initialized using organization-specific credentials decrypted at rest (Fernet encryption). Platform environment keys serve only as an explicitly configured fallback (`ALLOW_PLATFORM_INTEGRATION_FALLBACK`).
   - Organization-specific technology catalog visibility: Organizations only view packages and technologies linked to their own projects.
   - **Privilege Escalation Prevention**: Only Administrators can invite Administrator or Engineering Manager roles; Engineering Managers are strictly limited to Developer and Viewer invitations.
   - Invitation tokens are stored hashed (SHA-256) at rest with single-use validation and expiration.
   - Active session tracking with instantaneous token revocation on logout (`jti` blocklist) and automatic expired token purge.
   - In-memory sliding-window API rate limiting (429 with `Retry-After`) and strict file upload sanitization (2MB limit).

2. **Multi-Ecosystem Dependency Parser & Live Registries**
   - Seamlessly parses and normalizes dependencies from 8 package ecosystems:
     - `package.json` (npm / Node.js)
     - `requirements.txt` & `pyproject.toml` (PEP 621 / Poetry / Python)
     - `pom.xml` (Maven / Java)
     - `build.gradle` (Gradle / Kotlin / Android)
     - `Cargo.toml` (Rust)
     - `go.mod` (Go Modules)
     - `composer.json` (PHP / Packagist)
   - Real vulnerability intelligence querying the official Google OSV API for published CVEs.

3. **Firecrawl Web Intelligence & Accurate Provenance**
   - Official documentation and release announcement search with trusted domain validation.
   - **Publication Date Accuracy**: Missing publication dates remain unknown (`None`) without fabricated timestamps.
   - **Maintenance Status Distinctions**: Explicitly categorizes packages into `Active`, `Deprecated`, `End of life`, `Unmaintained` (>3 years without release), or `Unknown`.
   - Exponential backoff retry handling for external API rate limits.

4. **Evidence-Grounded 8-Category Debt Scoring**
   Weighted formula calculating composite health (0–100) computed purely in Python:
   - **Maintenance Health (20%)**
   - **Security Exposure (20%)**
   - **Version Currency (15%)**
   - **Community Activity (10%)**
   - **Documentation Quality (10%)**
   - **Ecosystem Compatibility (10%)**
   - **Long-term Sustainability (10%)**
   - **Upgrade Complexity (5%)**
   - **Confidence-Aware States**: Dedicated `Not Assessed` (score = `None` for unassessed projects) and `Insufficient Evidence` states.
   - Missing security information defaults to neutral unverified baselines (60.0 with Low confidence) rather than misleading 100/100 scores.
   - Prompt-injection defense wrapping crawled content in fenced `<untrusted_crawled_content>` XML delimiters.

5. **Memento Historical Memory Layer with Truthful Provenance**
   - Truthful connectivity verification via live HTTP probe against `https://api.memento.ai/v1/health`.
   - Remote write failures are never reported as cloud successes; seamlessly falls back to PostgreSQL and truthfully reports `storage_provider: "postgresql"` and `sync_status: "sync_failed_fallback_postgresql"`.
   - Contextual delta breakdowns: score drift, newly emerged risks, and resolved items.

6. **Dedicated Worker Architecture & Atomic Distributed Locking**
   - APScheduler is permanently disabled inside the web API process and runs exclusively in the dedicated background worker process (`python -m app.worker`).
   - Atomic database-level distributed locking (`distributed_locks` table) prevents simultaneous review execution across multiple worker containers or replicas.
   - Safe lease renewal mechanism allows long-running technology reviews (>10 minutes) without lease loss, and expired locks from crashed workers are automatically reclaimed.
   - Background worker continuously synchronizes persistent database schedule states without duplicate job registrations.

7. **Risk Management Center**
   - Full risk lifecycle triage: `Open` ➔ `Investigating` ➔ `Planned` ➔ `In Progress` ➔ `Resolved` ➔ `Accepted Risk`.
   - Business & technical impact analysis, assignee management, and resolution audit notes.

8. **Board-Ready Reports**
   - One-click PDF generation with ReportLab executive styling.
   - Complete CSV inventory manifests for audit compliance.

---

## 🚀 Quick Start & Deployment Guide

### Prerequisites
- Python 3.10+
- Node.js 18+ and npm
- (Optional) Docker and Docker Compose

---

### Method 1: Local Development (Instant Out-of-the-Box)

#### 1. Backend Setup
```bash
cd backend

# Install dependencies
pip install -r requirements.txt

# Apply database migrations
python -m alembic upgrade head

# Start backend server (auto-initializes & seeds development demo accounts into SQLite)
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
The API documentation is accessible at: `http://localhost:8000/docs`.

#### 2. Frontend Setup
In a new terminal:
```bash
cd frontend

# Install frontend packages
npm install

# Start Vite development server
npm run dev
```
Open your browser at: `http://localhost:5173`.

---

### Method 2: Production Docker Deployment

In production, all services communicate over an internal network with Nginx acting as the secure reverse proxy. Direct backend and database ports are restricted to localhost only (`127.0.0.1:8000` and `127.0.0.1:5432`). External user traffic enters exclusively through Nginx on port 80.

#### 1. Generate Required Production Secrets
> [!IMPORTANT]
> The production configuration **strictly rejects** all template placeholders (e.g. `replace-with`, `your-secret`, `change-me`, `default`). The `.env.example` file cannot be used unchanged to launch production.

Generate cryptographically secure 256-bit random keys:
```bash
# Generate SECRET_KEY (at least 32 characters)
openssl rand -hex 32

# Generate ENCRYPTION_KEY (at least 16 characters)
openssl rand -hex 32

# Generate POSTGRES_PASSWORD
openssl rand -hex 24
```

#### 2. Configure Environment File
Create your production `.env` file:
```bash
cp .env.example .env
```
Edit `.env` and insert the generated secrets:
```ini
ENVIRONMENT=production
ENABLE_DEMO_SEED=false

# Must NOT contain 'replace-with', 'your-secret', or default placeholders
SECRET_KEY=<your-generated-64-character-jwt-hex>
ENCRYPTION_KEY=<your-generated-64-character-fernet-hex>
POSTGRES_PASSWORD=<your-generated-strong-db-password>
POSTGRES_USER=postgres
POSTGRES_DB=techdebt_db

CORS_ORIGINS=http://localhost,http://localhost:80
```

#### 3. Build & Launch Containers
```bash
docker compose up --build -d
```
The production stack initiates 4 isolated containers:
- **`techdebt_frontend`**: Nginx web server serving compiled React SPA and reverse proxying `/api/` traffic to `http://backend:8000/api/` (Port 80).
- **`techdebt_backend`**: FastAPI REST API handling business logic (bound internally / `127.0.0.1:8000`).
- **`techdebt_worker`**: Dedicated background review worker process executing APScheduler jobs with atomic distributed locking.
- **`techdebt_postgres`**: PostgreSQL 15 database container (bound to `127.0.0.1:5432`).

---

## 🔑 Development Demo Credentials (Local Dev Only)

> [!NOTE]
> Demo accounts are **automatically disabled** in production (`ENABLE_DEMO_SEED=false` or `ENVIRONMENT=production`). The credentials below exist strictly for rapid local development testing against SQLite:

| Role | Email | Development Password |
| :--- | :--- | :--- |
| **CTO / Administrator** | `admin@techdebt.ai` | `AdminPass123!` |
| **Engineering Manager** | `manager@techdebt.ai` | `ManagerPass123!` |
| **Developer** | `dev@techdebt.ai` | `DevPass123!` |

*(In production, organizations register their own initial Administrator account from the landing page).*

---

## 🧪 Automated Testing

### Backend Unit, Integration & Multiprocessing Tests (Pytest)
```bash
cd backend
python -m pytest -v
```
**Test Results: 55 passed, 1 skipped (live API requiring MEMENTO_API_KEY) in 60.74s across 6 modules:**
- `test_audit_fixes.py` (21 tests): Docker secret enforcement, placeholder rejection (`replace-with`), isolated disposable migration rollback, genuine multiprocessing worker concurrency, lease renewals (>10 min), expired lock recovery, and Memento mocked/live tests.
- `test_ai_and_integrations.py` (9 tests): Semantic versioning delta (`packaging.version`), Pydantic validation, deterministic scoring, and Firecrawl dates.
- `test_api.py` (6 tests): Health check, authentication, profile `/auth/me`, dashboard aggregates, project CRUD, and risk management.
- `test_core.py` (10 tests): Multi-ecosystem dependency parsers, ReportLab PDF and CSV generation.
- `test_e2e_lifecycle.py` (1 test): Complete 26-step automated end-to-end user acceptance journey.
- `test_security_multitenancy.py` (9 tests): Cross-organization data isolation, privilege escalation defense, hashed token validation, and JWT revocation.

### Frontend Component Tests (Vitest)
```bash
cd frontend
npm test
```
**Test Results: 4 passed in 2.66s:**
- HealthBadge color variations and score derivations
- 'Not Assessed' and zero score handling
- RiskBadge severity styling
- Navbar rendering and authentication state

### Code Quality & Build Checks
```bash
# TypeScript compilation & production bundling
cd frontend && npm run build

# Fast static code analysis
cd frontend && npx oxlint
```
- **TypeScript & Vite**: Built in **885ms** with 0 errors.
- **Oxlint**: 0 errors across 23 files.

---

## 🏛️ System Architecture & Nginx Routing

```mermaid
flowchart TD
    User["Client Browser (Port 80)"]

    subgraph DOCKER ["Production Container Network"]
        subgraph NGINX ["Nginx Reverse Proxy (Frontend Container)"]
            SPA["React Static SPA (try_files /index.html)"]
            Proxy["Reverse Proxy /api/ -> backend:8000/api/"]
        end

        subgraph BACKEND ["FastAPI REST API (Backend Container)"]
            API_Engine["FastAPI API Routers"]
            Config["IntegrationConfigService"]
        end

        subgraph WORKER ["Dedicated Worker Process (Worker Container)"]
            APSched["APScheduler Engine"]
            Lock["Atomic Distributed Lock Engine"]
        end

        subgraph DB ["PostgreSQL 15 (DB Container)"]
            Tables["17 Relational Tables + distributed_locks"]
        end
    end

    User -->|HTTP /| SPA
    User -->|HTTP /api/| Proxy
    Proxy --> API_Engine
    API_Engine --> Tables
    WORKER --> Lock
    Lock --> Tables
```

---

## 📄 License
MIT License. Built for modern software engineering teams.
