# TechDebt AI v1.0.4 — Technology Debt Review Assistant

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.100%2B-009688.svg)](https://fastapi.tiangolo.com)
[![React 19](https://img.shields.io/badge/React-19-61DAFB.svg)](https://react.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0%2B-3178C6.svg)](https://www.typescriptlang.org)
[![Tailwind CSS v4](https://img.shields.io/badge/TailwindCSS-v4-38B2AC.svg)](https://tailwindcss.com)
[![Release](https://img.shields.io/badge/Release-v1.0.4-emerald.svg)](release/techdebt-ai-v1.0.4-production.zip)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

**TechDebt AI** is a production-grade, enterprise technology debt assessment and software engineering intelligence platform developed by **GT InnoX LLP**. It continuously inspects software repositories, frameworks, programming languages, and third-party dependencies across 8 weighted categories to discover architectural debt, deprecations, end-of-life packages, and maintenance risks before they impact production.

---

## 🌟 Core Architecture & Capabilities

1. **Enterprise Multi-Tenancy & Security**
   - Cryptographic credential encryption at rest using Fernet keys (`cryptography`).
   - Strict organization-level data isolation across all API endpoints, reports, database records, and background worker jobs.
   - **Organization-Aware API Integrations**: Firecrawl, AI inference (Gemini/OpenAI), and Memento memory are initialized using decrypted organization settings. Global platform environment keys serve solely as an explicit administrator fallback (`ALLOW_PLATFORM_INTEGRATION_FALLBACK`).
   - Role-Based Access Control (`Administrator`, `Engineering Manager`, `Developer`, `Viewer`) with privilege escalation prevention.
   - Instantaneous JWT token revocation on logout (`revoked_tokens` table with `jti` blocklist) and automatic expired token purging.
   - In-memory sliding-window API rate limiting (HTTP 429 with `Retry-After`) and file upload sanitization (2MB limit).

2. **Distributed Scheduler with Atomic Locking & Fencing Tokens**
   - APScheduler is permanently disabled inside web API processes and runs exclusively in the dedicated background worker (`python -m app.worker`).
   - Atomic conditional SQL `UPDATE` / conditional `INSERT` locking on the `distributed_locks` table eliminates race conditions during expired lease reclamation.
   - **Fencing Token (`generation`) Protection**: Workers increment and track lock generation numbers. Ten pipeline checkpoints throughout assessment execution verify lease ownership and fencing tokens, guaranteeing zero stale writes or split-brain commits.
   - Background `LockHeartbeat` thread periodically renews leases for long-running reviews (>10 minutes) with bounded retry budgets.

3. **Multi-Ecosystem Dependency Parser & Registry Intelligence**
   - Ingests and parses manifest files from 8 major software package ecosystems:
     - `package.json` (npm / Node.js)
     - `requirements.txt` & `pyproject.toml` (PEP 621 / Poetry / Python)
     - `pom.xml` (Maven / Java)
     - `build.gradle` (Gradle / Kotlin / Android)
     - `Cargo.toml` (Rust)
     - `go.mod` (Go Modules)
     - `composer.json` (PHP / Packagist)
   - Real vulnerability scanning via the official Google Open Source Vulnerabilities (OSV) API.

4. **Firecrawl Web Intelligence & Trusted Provenance**
   - Extracts release notes, deprecation bulletins, and security advisories from official documentation sources.
   - Strict publication date provenance (missing dates remain `None` rather than fabricated timestamps).
   - Fenced `<untrusted_crawled_content>` XML delimiters protect LLM reasoning prompts against prompt injection.

5. **Authoritative Historical Memory Storage**
   - Comprehensive technical evaluation of official Memento (`runmemento.com` / `github.com/veerps57/memento`) verified it as an open-source local-first Model Context Protocol (MCP) server designed for local developer IDEs.
   - TechDebt AI retains PostgreSQL as the authoritative multi-tenant historical memory store, persisting longitudinal architecture score drift, risk progression, and delta snapshots with strict tenant isolation.
   - Unsupported cloud REST endpoints and unused API keys are deprecated and removed.

6. **Evidence-Grounded 8-Category Debt Scoring**
   Deterministic score computation in pure Python across 8 weighted categories:
   - Maintenance Health (20%)
   - Security Exposure (20%)
   - Version Currency (15%)
   - Community Activity (10%)
   - Documentation Quality (10%)
   - Ecosystem Compatibility (10%)
   - Long-term Sustainability (10%)
   - Upgrade Complexity (5%)

---

## 🚀 Quick Start Guide

### Prerequisites
- Python 3.10+
- Node.js 18+ and npm
- Docker and Docker Compose (v2.20+)

---

### Local Development Setup

#### 1. Backend Service
```bash
cd backend

# Install dependencies
pip install -r requirements.txt

# Apply Alembic database migrations
python -m alembic upgrade head

# Seed initial development data
python -c "from app.seed_data import seed; seed()"

# Start FastAPI server
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

#### 2. Dedicated Background Worker
```bash
cd backend
python -m app.worker
```

#### 3. Frontend Web Client
```bash
cd frontend

# Install dependencies
npm install

# Start Vite dev server
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

---

### Production Deployment via Docker Compose

1. Copy the production environment template:
```bash
cp .env.example .env
```
2. Configure mandatory production secrets in `.env`:
   - `POSTGRES_PASSWORD`: Strong password (min 16 chars)
   - `SECRET_KEY`: Cryptographically secure JWT secret (`openssl rand -hex 32`)
   - `ENCRYPTION_KEY`: Valid Fernet 32-byte url-safe base64 key (`python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`)
   - `ENVIRONMENT=production`
   - `ENABLE_DEMO_SEED=false`

3. Launch the containerized production stack:
```bash
docker compose up -d --build
```
The stack boots 4 services:
- `techdebt_postgres`: PostgreSQL 15 database with persistent volume.
- `techdebt_backend`: FastAPI API server running Alembic migrations on startup.
- `techdebt_worker`: Dedicated APScheduler review worker with atomic locking.
- `techdebt_frontend`: Production React 19 build served by Nginx with reverse proxy to backend.

---

## 🧪 Automated Test Suite

### Backend Pytest Suite
```bash
$env:PYTHONPATH="backend"
python -m pytest backend/tests
```
**Results:** **70 passed, 3 skipped** (live provider probes skipped when API keys unconfigured), **0 failures**.

Key test modules:
- `test_audit_fixes.py`: Scheduler Suites A–J (initial acquisition, active rejection, expired reclamation, concurrent multiprocessing, heartbeat renewals, ownership isolation, long-running reviews, fencing token rollback, transient DB interruption), disposable DB migration rollback/upgrade.
- `test_security_multitenancy.py`: Cross-organization negative authorization tests, RBAC enforcement, session revocation, file upload validation, technology catalog visibility.
- `test_ai_and_integrations.py`: AI error handling, prompt injection defense, Firecrawl timeouts, Memento PostgreSQL authoritative storage.
- `test_api.py`: Core REST endpoints (auth, dashboard, projects, technologies, risks).
- `test_core.py`: Weighted scoring calculations, version parsing, risk classification.
- `test_e2e_lifecycle.py`: Complete 26-step end-to-end integration acceptance test.

### Frontend Quality & Test Suite
```bash
cd frontend
npm run test     # Vitest component tests (4 passed)
npm run build    # TypeScript compile & Vite production bundle
npm run lint     # Oxlint static analysis
```

---

## 📚 Documentation Package

Full technical documentation is located in the `docs/` directory:
- [FINAL_COMPLETION_REPORT.md](file:///C:/Users/tejag/Downloads/GenAI/docs/FINAL_COMPLETION_REPORT.md): Executive summary and completion signoff.
- [FINAL_AUDIT.md](file:///C:/Users/tejag/Downloads/GenAI/docs/FINAL_AUDIT.md): Complete engineering and architecture audit findings.
- [DEPLOYMENT_GUIDE.md](file:///C:/Users/tejag/Downloads/GenAI/docs/DEPLOYMENT_GUIDE.md): Production deployment and operational runbook.
- [SECURITY_AUDIT.md](file:///C:/Users/tejag/Downloads/GenAI/docs/SECURITY_AUDIT.md): Application security, threat modeling, and audit report.
- [TESTING_REPORT.md](file:///C:/Users/tejag/Downloads/GenAI/docs/TESTING_REPORT.md): Automated testing results and test matrix.
- [DATABASE_MIGRATION_GUIDE.md](file:///C:/Users/tejag/Downloads/GenAI/docs/DATABASE_MIGRATION_GUIDE.md): Schema management and Alembic migration procedures.
- [SCHEDULER_ARCHITECTURE.md](file:///C:/Users/tejag/Downloads/GenAI/docs/SCHEDULER_ARCHITECTURE.md): Distributed locking, fencing tokens, and worker design.
- [INTEGRATION_GUIDE.md](file:///C:/Users/tejag/Downloads/GenAI/docs/INTEGRATION_GUIDE.md): Firecrawl, GenAI, and Memento/PostgreSQL integration reference.

---

## 👥 Default Demo Credentials (Development Mode Only)

> [!WARNING]
> Demo seeding is strictly disabled when `ENVIRONMENT=production`.

| Role | Email | Password |
|---|---|---|
| Administrator | `admin@techdebt.ai` | `AdminPass123!` |
| Engineering Manager | `manager@techdebt.ai` | `ManagerPass123!` |
| Developer | `dev@techdebt.ai` | `DevPass123!` |
| Viewer | `viewer@techdebt.ai` | `ViewerPass123!` |

---

## 🏢 Developed By

**GT InnoX LLP**  
Engineering Intelligence & Architecture Modernization Group  
Release Version: **v1.0.4** (Production Release)
