import os
import uuid
import tempfile
import asyncio
import multiprocessing
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta
import pytest
from pydantic import ValidationError
from fastapi.testclient import TestClient

from app.config import (
    Settings,
    DEFAULT_DEV_SECRET,
    PROHIBITED_SECRET_DEFAULTS,
    PROHIBITED_PLACEHOLDER_SUBSTRINGS,
    contains_prohibited_placeholder
)
from app.database import SessionLocal
from app.models.all_models import (
    Organization, User, Project, ScheduledReview, ReviewJob,
    HistoricalAssessment, Assessment, DistributedLock, Technology, ProjectTechnology
)
from app.services.scheduler_service import (
    run_scheduled_job,
    execute_project_review,
    acquire_distributed_lock,
    release_distributed_lock,
    renew_distributed_lock,
    get_lock_generation,
    assert_valid_fenced_lease,
    LockHeartbeat,
    register_job_in_scheduler,
    scheduler
)
from app.services.ai_analyzer import AITechnologyDebtAnalyzer
from app.services.memento_adapter import MementoMemoryAdapter
from app.main import app

client = TestClient(app)

def get_or_create_test_org(db) -> Organization:
    org = db.query(Organization).first()
    if not org:
        org = Organization(name="Test Org " + uuid.uuid4().hex[:6], slug="test-org-" + uuid.uuid4().hex[:6])
        db.add(org)
        db.commit()
        db.refresh(org)
    return org

def get_or_create_test_project(db) -> Project:
    org = get_or_create_test_org(db)
    proj = db.query(Project).filter(Project.org_id == org.id).first()
    if not proj:
        proj = Project(org_id=org.id, name="Test Project " + uuid.uuid4().hex[:6])
        db.add(proj)
        db.commit()
        db.refresh(proj)
    return proj


# -------------------------------------------------------------
# 1. DOCKER SECRETS & PLACEHOLDER VALIDATION TESTS
# -------------------------------------------------------------
def test_production_rejects_default_secrets():
    """Verify production configuration rejects known default secret keys and weak values."""
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": DEFAULT_DEV_SECRET,
        "ENCRYPTION_KEY": "a" * 32,
        "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="FATAL SECURITY VIOLATION"):
            Settings()

    # Reject short secret key (< 32 characters)
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "short-secret-key-too-brief",
        "ENCRYPTION_KEY": "a" * 32,
        "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="at least 32 characters long"):
            Settings()

def test_production_rejects_all_placeholder_secrets():
    """
    Verify production configuration strictly rejects template placeholders from .env.example:
    - replace-with
    - your-secret
    - example-key
    - change-me
    - changeme
    - default
    """
    placeholders = [
        "replace-with-at-least-32-char-random-jwt-secret-key-prod",
        "your-secret-key-goes-here-32chars-long",
        "example-key-value-for-testing-prod-32c",
        "change-me-before-deploying-production-32c",
        "changeme-12345678901234567890123456",
        "default-secret-production-key-32chars"
    ]
    for ph in placeholders:
        with patch.dict(os.environ, {
            "ENVIRONMENT": "production",
            "SECRET_KEY": ph,
            "ENCRYPTION_KEY": "a-strong-random-encryption-key-valid",
            "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
        }):
            with pytest.raises(ValueError, match="strictly rejected"):
                Settings()

def test_sample_env_example_cannot_launch_production():
    """Ensure that the exact sample .env.example cannot be used unchanged in production."""
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "replace-with-at-least-32-char-random-jwt-secret-key-prod",
        "ENCRYPTION_KEY": "replace-with-at-least-32-char-random-fernet-key-prod",
        "DATABASE_URL": "postgresql://postgres:replace-with-strong-db-password-in-production@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="strictly rejected"):
            Settings()

def test_production_rejects_default_db_password():
    """Verify production rejects known default postgres passwords in DATABASE_URL."""
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "a-strong-random-production-secret-key-that-is-long-enough",
        "ENCRYPTION_KEY": "a-strong-production-fernet-key-valid",
        "DATABASE_URL": "postgresql://postgres:postgrespassword@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="DATABASE_URL must not use default"):
            Settings()


# -------------------------------------------------------------
# 2. SAFE DATABASE MIGRATION TESTS (ISOLATED DISPOSABLE DATABASE)
# -------------------------------------------------------------
def assert_safe_test_database(url: str):
    """Safeguard: Refuse to execute destructive migration tests against production databases."""
    lower_url = url.lower()
    if "production" in lower_url or (not "test" in lower_url and not "temp" in lower_url and not "disposable" in lower_url):
        raise ValueError(f"ABORT: Destructive migration test cannot run against non-test database URL: {url}")

def test_migration_safeguard_rejects_production_urls():
    """Verify safeguard rejects production database URLs for migration tests."""
    with pytest.raises(ValueError, match="ABORT: Destructive migration test cannot run"):
        assert_safe_test_database("postgresql://admin:secret@production-db.company.internal:5432/techdebt")
    with pytest.raises(ValueError, match="ABORT: Destructive migration test cannot run"):
        assert_safe_test_database("postgresql://user:pass@db:5432/techdebt_db")

def test_alembic_startup_fails_on_migration_error():
    """Verify application startup fails if Alembic migration fails without falling back to create_all."""
    from app.main import lifespan
    with patch("alembic.command.upgrade", side_effect=Exception("Simulated schema migration syntax error")):
        with patch.object(app, "router"):
            async def run():
                async with lifespan(app):
                    pass
            with pytest.raises(RuntimeError, match="Application startup aborted: Alembic migrations failed"):
                asyncio.run(run())

def test_safe_database_migration_downgrade_and_upgrade_on_disposable_db():
    """
    Test Alembic rollback to base and re-upgrade to head on an isolated disposable test database.
    Production and development databases (techdebt.db) are strictly preserved and untouched.
    """
    from alembic.config import Config
    from alembic import command
    from sqlalchemy import create_engine, inspect

    # Create isolated disposable SQLite database file in OS temp directory
    disposable_file = os.path.join(tempfile.gettempdir(), f"disposable_migration_{uuid.uuid4().hex}.db")
    disposable_url = f"sqlite:///{disposable_file}"
    assert_safe_test_database(disposable_url)

    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ini_path = os.path.join(base_dir, "alembic.ini")
    alembic_cfg = Config(ini_path)
    alembic_cfg.set_main_option("script_location", os.path.join(base_dir, "alembic"))
    alembic_cfg.set_main_option("sqlalchemy.url", disposable_url)

    try:
        # 1. Clean upgrade to head on disposable DB
        command.upgrade(alembic_cfg, "head")

        engine = create_engine(disposable_url)
        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
        assert "organizations" in tables
        assert "distributed_locks" in tables
        assert "assessments" in tables
        engine.dispose()

        # 2. Downgrade to base on disposable DB
        command.downgrade(alembic_cfg, "base")

        engine = create_engine(disposable_url)
        inspector = inspect(engine)
        tables_after_downgrade = set(inspector.get_table_names())
        assert "organizations" not in tables_after_downgrade
        assert "distributed_locks" not in tables_after_downgrade
        engine.dispose()

        # 3. Re-upgrade to head on disposable DB
        command.upgrade(alembic_cfg, "head")

        engine = create_engine(disposable_url)
        inspector = inspect(engine)
        tables_reupgraded = set(inspector.get_table_names())
        assert "organizations" in tables_reupgraded
        assert "distributed_locks" in tables_reupgraded
        engine.dispose()

    finally:
        # Clean up temporary disposable DB
        if os.path.exists(disposable_file):
            try:
                os.remove(disposable_file)
            except Exception:
                pass


# -------------------------------------------------------------
# 3. SCHEDULER: GENUINE MULTIPROCESSING CONCURRENCY & LEASES
# -------------------------------------------------------------
def _run_worker_job_in_process(schedule_id: str, worker_id: str, queue: multiprocessing.Queue):
    """Independent worker process entry point for genuine multiprocessing concurrency test."""
    from app.services.scheduler_service import run_scheduled_job
    from unittest.mock import patch
    from app.models.all_models import Assessment

    async def mock_review(*args, **kwargs):
        # Simulate slight processing duration
        import time
        time.sleep(0.1)
        return Assessment(project_id="test_pid", status="completed", overall_health_score=80.0)

    with patch("app.services.scheduler_service.execute_project_review", side_effect=mock_review):
        executed = run_scheduled_job(schedule_id, worker_id=worker_id)
        queue.put((worker_id, executed))

def _acquire_lock_in_process(lock_key: str, worker_id: str, queue: multiprocessing.Queue):
    """Independent worker process entry point for concurrent expired-lock reclamation testing."""
    from app.database import SessionLocal
    from app.services.scheduler_service import acquire_distributed_lock
    db = SessionLocal()
    try:
        acquired = acquire_distributed_lock(db, lock_key, worker_id, ttl_seconds=60)
        queue.put((worker_id, acquired))
    finally:
        db.close()

def test_genuine_multiprocessing_scheduler_concurrency():
    """
    Genuine multiprocessing concurrency test:
    Two separate OS worker processes simultaneously attempt to execute the same scheduled review.
    Verifies that atomic distributed locking allows exactly one worker to execute, while the other is rejected.
    """
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(org_id=org.id, name=f"Multiprocess Proj {uuid.uuid4().hex[:6]}")
        db.add(proj)
        db.commit()

        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Daily",
            cron_expression="0 0 * * *",
            is_active=True
        )
        db.add(schedule)
        db.commit()
        schedule_id = schedule.id

        ctx = multiprocessing.get_context("spawn")
        queue = ctx.Queue()

        p1 = ctx.Process(target=_run_worker_job_in_process, args=(schedule_id, "process_worker_1", queue))
        p2 = ctx.Process(target=_run_worker_job_in_process, args=(schedule_id, "process_worker_2", queue))

        # Launch both independent worker processes simultaneously
        p1.start()
        p2.start()

        p1.join(timeout=10)
        p2.join(timeout=10)

        # Timeout cleanup for worker processes
        for p in (p1, p2):
            if p.is_alive():
                p.terminate()
                p.join(timeout=2)

        # Exit-code checks
        assert p1.exitcode == 0, f"Worker process 1 exited with code {p1.exitcode}"
        assert p2.exitcode == 0, f"Worker process 2 exited with code {p2.exitcode}"

        # Retrieve results using queue.get(timeout=5)
        results = []
        for _ in range(2):
            try:
                results.append(queue.get(timeout=5))
            except Exception as e:
                pytest.fail(f"Timed out waiting for worker result from queue: {e}")

        assert len(results) == 2, f"Expected 2 process results, got: {results}"
        executed_count = sum(1 for _, res in results if res is True)
        rejected_count = sum(1 for _, res in results if res is False)

        # Exactly one worker process must have executed the review
        assert executed_count == 1, f"Expected exactly 1 execution, got {executed_count}"
        assert rejected_count == 1, f"Expected exactly 1 rejection, got {rejected_count}"

        # Verify only one completed ReviewJob in database
        jobs = db.query(ReviewJob).filter(ReviewJob.scheduled_review_id == schedule_id).all()
        assert len(jobs) == 1
        assert jobs[0].status == "Completed"

    finally:
        db.close()

def test_lock_renewal_and_long_execution():
    """
    Test safe lease mechanism:
    Verify that an active lease can be renewed during execution longer than 10 minutes.
    """
    db = SessionLocal()
    try:
        lock_key = f"long_exec_lock_{uuid.uuid4().hex[:6]}"
        owner = "long_worker_1"

        # Acquire initial 60-second lease
        acquired = acquire_distributed_lock(db, lock_key, owner, ttl_seconds=60)
        assert acquired is True

        # Check initial expiration
        lock_rec = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        initial_expires = lock_rec.expires_at

        # Renew lease for an additional 900 seconds (15 minutes) for long-running execution
        renewed = renew_distributed_lock(db, lock_key, owner, extension_seconds=900)
        assert renewed is True

        db.refresh(lock_rec)
        assert lock_rec.expires_at > initial_expires
        assert (lock_rec.expires_at - datetime.utcnow()).total_seconds() > 800

        # Non-owner cannot renew lease
        invalid_renew = renew_distributed_lock(db, lock_key, "imposter_worker", extension_seconds=600)
        assert invalid_renew is False

        # Release lock
        released = release_distributed_lock(db, lock_key, owner)
        assert released is True
    finally:
        db.close()

def test_expired_lock_recovery():
    """
    Test that expired locks (e.g. from a crashed worker) are safely reclaimed and acquired by a new worker.
    """
    db = SessionLocal()
    try:
        lock_key = f"expired_recovery_lock_{uuid.uuid4().hex[:6]}"

        # Insert a pre-expired lock (expired 15 minutes ago)
        expired_lock = DistributedLock(
            lock_key=lock_key,
            owner_id="crashed_worker",
            acquired_at=datetime.utcnow() - timedelta(minutes=20),
            expires_at=datetime.utcnow() - timedelta(minutes=10)
        )
        db.add(expired_lock)
        db.commit()

        # New worker attempts to acquire the lock
        acquired = acquire_distributed_lock(db, lock_key, "new_healthy_worker", ttl_seconds=300)
        assert acquired is True

        # Verify ownership was transferred to new worker
        lock_rec = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert lock_rec.owner_id == "new_healthy_worker"
        assert lock_rec.expires_at > datetime.utcnow()

        release_distributed_lock(db, lock_key, "new_healthy_worker")
    finally:
        db.close()

def test_avoid_duplicate_scheduling_during_periodic_sync():
    """
    Verify that periodic schedule synchronization does not recreate jobs or reset cron timers
    when schedule configuration has not changed.
    """
    db = SessionLocal()
    try:
        proj = get_or_create_test_project(db)
        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Weekly",
            cron_expression="0 0 * * 1",
            is_active=True
        )
        db.add(schedule)
        db.commit()

        job_id = f"review_job_{schedule.id}"

        # First registration
        register_job_in_scheduler(schedule)
        first_job = scheduler.get_job(job_id)
        assert first_job is not None

        # Subsequent periodic sync with identical cron expression must NOT recreate or change job instance
        register_job_in_scheduler(schedule)
        second_job = scheduler.get_job(job_id)
        assert second_job is not None
        assert first_job.id == second_job.id

        # Clean up
        scheduler.remove_job(job_id)
    finally:
        db.close()

def test_dedicated_worker_real_scheduled_assessment():
    """
    Execute a real scheduled assessment through the dedicated worker pipeline end-to-end.
    Verifies that run_scheduled_job():
    1. Successfully acquires distributed lock
    2. Runs complete project assessment pipeline with intelligence and scoring
    3. Creates completed ReviewJob audit entry
    4. Records historical snapshot in database
    5. Cleanly releases distributed lock upon completion
    """
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(
            org_id=org.id,
            name=f"Worker Schedule Project {uuid.uuid4().hex[:6]}",
            description="Dedicated worker assessment integration test"
        )
        db.add(proj)
        db.commit()

        # Add real technologies
        t1 = Technology(name=f"react-{uuid.uuid4().hex[:4]}", ecosystem="npm", latest_stable_version="18.2.0")
        t2 = Technology(name=f"fastapi-{uuid.uuid4().hex[:4]}", ecosystem="pypi", latest_stable_version="0.109.0")
        db.add_all([t1, t2])
        db.commit()

        pt1 = ProjectTechnology(project_id=proj.id, technology_id=t1.id, installed_version="18.2.0")
        pt2 = ProjectTechnology(project_id=proj.id, technology_id=t2.id, installed_version="0.100.0")
        db.add_all([pt1, pt2])
        db.commit()

        # Create scheduled review
        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Daily",
            cron_expression="0 2 * * *",
            is_active=True
        )
        db.add(schedule)
        db.commit()

        # Execute scheduled job directly through the worker execution entry point
        worker_id = f"test_worker_{uuid.uuid4().hex[:6]}"
        result = run_scheduled_job(schedule.id, worker_id=worker_id)
        assert result is True, "Scheduled job should have completed successfully"

        # Verify ReviewJob was recorded with Completed status
        job = db.query(ReviewJob).filter(ReviewJob.scheduled_review_id == schedule.id).first()
        assert job is not None
        assert job.status == "Completed"
        assert job.completed_at is not None

        # Verify Assessment was created
        assessment = (
            db.query(Assessment)
            .filter(Assessment.project_id == proj.id)
            .order_by(Assessment.created_at.desc())
            .first()
        )
        assert assessment is not None
        assert assessment.status == "completed"
        assert assessment.overall_health_score is not None
        assert assessment.overall_health_score > 0

        # Verify HistoricalAssessment snapshot was recorded
        hist = (
            db.query(HistoricalAssessment)
            .filter(HistoricalAssessment.project_id == proj.id)
            .first()
        )
        assert hist is not None
        assert hist.health_score == assessment.overall_health_score
        assert hist.storage_provider in ["memento_cloud", "postgresql"]

        # Verify distributed lock was released
        lock_key = f"review_job_lock_{schedule.id}"
        lock = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert lock is None or lock.expires_at <= datetime.utcnow()
    finally:
        db.close()

def test_worker_safely_aborts_on_lock_loss():
    """
    Verify that assessment execution safely aborts if distributed lock ownership is lost.
    Ensures safe early termination, failure logging, and prevents modifying or releasing locks owned by others.
    """
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(org_id=org.id, name=f"Lock Loss Proj {uuid.uuid4().hex[:6]}")
        db.add(proj)
        db.commit()

        # Add a technology to project
        tech = Technology(name=f"test-pkg-{uuid.uuid4().hex[:4]}", ecosystem="npm", latest_stable_version="1.0.0")
        db.add(tech)
        db.commit()

        p_tech = ProjectTechnology(project_id=proj.id, technology_id=tech.id, installed_version="1.0.0")
        db.add(p_tech)
        db.commit()

        # 1. Direct execute_project_review with should_abort returning True
        with pytest.raises(RuntimeError, match="lost distributed lock ownership"):
            asyncio.run(execute_project_review(
                project_id=proj.id,
                trigger_type="scheduled",
                db_session=db,
                should_abort=lambda: True
            ))

        # 2. Scheduled job aborts safely and logs Failure status without retrying
        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Daily",
            cron_expression="0 0 * * *",
            is_active=True
        )
        db.add(schedule)
        db.commit()

        async def mock_exec_with_lock_lost(*args, **kwargs):
            raise RuntimeError("Review aborted: Worker lost distributed lock ownership")

        with patch("app.services.scheduler_service.execute_project_review", side_effect=mock_exec_with_lock_lost):
            executed = run_scheduled_job(schedule.id, max_retries=1)
            assert executed is False

        # ReviewJob must be marked Failed
        job = db.query(ReviewJob).filter(ReviewJob.scheduled_review_id == schedule.id).first()
        assert job is not None
        assert job.status == "Failed"
        assert "lost distributed lock" in job.error_message.lower() or "lost" in job.error_message.lower()
    finally:
        db.close()

def test_long_running_heartbeat_renewal_and_safe_loss_abort():
    """
    Comprehensive long-running concurrency & lease loss integration test:
    1. Starts worker 1 with a short initial lease (TTL 2s).
    2. Executes a simulated long-running assessment.
    3. Allows the heartbeat to renew the lease multiple times.
    4. Starts a second worker during the first execution.
    5. Verifies that the second worker cannot acquire the lock.
    6. Simulates lock ownership loss.
    7. Verifies that the original worker stops safely.
    8. Verifies that no stale results are committed.
    """
    db = SessionLocal()
    schedule_id = None
    lock_key = None
    try:
        org = get_or_create_test_org(db)
        proj = Project(
            org_id=org.id,
            name=f"Long Running Concurrency {uuid.uuid4().hex[:6]}",
            description="Long-running heartbeat concurrency test"
        )
        db.add(proj)
        db.commit()

        tech = Technology(name=f"pkg-{uuid.uuid4().hex[:4]}", ecosystem="npm", latest_stable_version="1.0.0")
        db.add(tech)
        db.commit()

        p_tech = ProjectTechnology(project_id=proj.id, technology_id=tech.id, installed_version="1.0.0")
        db.add(p_tech)
        db.commit()

        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Daily",
            cron_expression="0 0 * * *",
            is_active=True
        )
        db.add(schedule)
        db.commit()
        schedule_id = schedule.id
        lock_key = f"review_job_lock_{schedule_id}"

        worker_1_id = "worker_long_running_1"
        worker_2_id = "worker_concurrent_2"

        # 1. Acquire initial short lease for worker 1 (TTL 2 seconds)
        acquired = acquire_distributed_lock(db, lock_key, worker_1_id, ttl_seconds=2)
        assert acquired is True

        # Start heartbeat with short interval (0.3s) and extension (2s)
        from app.services.scheduler_service import LockHeartbeat
        heartbeat_1 = LockHeartbeat(lock_key, worker_1_id, interval=0.3, lease_extension=2)
        heartbeat_1.start()

        # 2 & 3. Allow heartbeat to renew the lease multiple times (sleep 1.0s)
        import time
        time.sleep(1.0)
        lock_rec_1 = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert lock_rec_1 is not None
        assert lock_rec_1.owner_id == worker_1_id
        assert lock_rec_1.expires_at > datetime.utcnow()

        # 4 & 5. Worker 2 attempts to run during worker 1's active lease; must be rejected
        worker_2_acquired = acquire_distributed_lock(db, lock_key, worker_2_id, ttl_seconds=5)
        assert worker_2_acquired is False, "Worker 2 must NOT acquire lock while Worker 1 holds active lease"

        worker_2_run_res = run_scheduled_job(schedule_id, worker_id=worker_2_id)
        assert worker_2_run_res is False, "Worker 2 execution must be rejected due to active lock"

        # 6. Simulate lock ownership loss for worker 1
        heartbeat_1.mark_lost()
        assert heartbeat_1.is_lock_lost() is True

        # 7. Execute review with should_abort=heartbeat_1.is_lock_lost; verify it stops safely
        with pytest.raises(RuntimeError, match="Worker lost distributed lock ownership"):
            asyncio.run(execute_project_review(
                project_id=proj.id,
                trigger_type="scheduled",
                db_session=db,
                should_abort=heartbeat_1.is_lock_lost
            ))

        # 8. Verify no stale completed assessment results were committed to database
        completed_assessments = (
            db.query(Assessment)
            .filter(Assessment.project_id == proj.id, Assessment.status == "completed")
            .all()
        )
        assert len(completed_assessments) == 0, "No completed assessment should be committed by a worker that lost its lock"

        heartbeat_1.stop()
    finally:
        if lock_key:
            db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
            db.commit()
        db.close()


# -------------------------------------------------------------
# 3B. SCHEDULER SUITE TESTS A THROUGH J (EXHAUSTIVE CONCURRENCY)
# -------------------------------------------------------------
def test_scheduler_suite_a_initial_acquisition():
    """Test A: Initial lock acquisition on an unoccupied key."""
    db = SessionLocal()
    lock_key = f"suite_a_lock_{uuid.uuid4().hex[:6]}"
    worker_id = "suite_worker_a"
    try:
        acquired = acquire_distributed_lock(db, lock_key, worker_id, ttl_seconds=60)
        assert acquired is True

        lock_rec = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert lock_rec is not None
        assert lock_rec.owner_id == worker_id
        assert lock_rec.generation == 1
        assert lock_rec.expires_at > datetime.utcnow()
    finally:
        db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
        db.commit()
        db.close()

def test_scheduler_suite_b_active_ownership_rejection():
    """Test B: Active ownership rejection while lease is held."""
    db = SessionLocal()
    lock_key = f"suite_b_lock_{uuid.uuid4().hex[:6]}"
    worker_1 = "suite_worker_b1"
    worker_2 = "suite_worker_b2"
    try:
        acquired_1 = acquire_distributed_lock(db, lock_key, worker_1, ttl_seconds=60)
        assert acquired_1 is True

        # Second worker must be rejected
        acquired_2 = acquire_distributed_lock(db, lock_key, worker_2, ttl_seconds=60)
        assert acquired_2 is False

        lock_rec = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert lock_rec.owner_id == worker_1
        assert lock_rec.generation == 1
    finally:
        db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
        db.commit()
        db.close()

def test_scheduler_suite_c_expired_lock_reclamation():
    """Test C: Expired lock reclamation increments generation atomically."""
    db = SessionLocal()
    lock_key = f"suite_c_lock_{uuid.uuid4().hex[:6]}"
    old_worker = "crashed_worker_c"
    new_worker = "healthy_worker_c"
    try:
        # Pre-seed expired lock
        expired_lock = DistributedLock(
            lock_key=lock_key,
            owner_id=old_worker,
            generation=1,
            acquired_at=datetime.utcnow() - timedelta(seconds=120),
            expires_at=datetime.utcnow() - timedelta(seconds=60)
        )
        db.add(expired_lock)
        db.commit()

        # Reclaim expired lock
        acquired = acquire_distributed_lock(db, lock_key, new_worker, ttl_seconds=300)
        assert acquired is True

        db.refresh(expired_lock)
        assert expired_lock.owner_id == new_worker
        assert expired_lock.generation == 2
        assert expired_lock.expires_at > datetime.utcnow()
    finally:
        db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
        db.commit()
        db.close()

def test_scheduler_suite_d_concurrent_expired_lock_reclamation():
    """Test D: Concurrent expired lock reclamation across independent worker processes."""
    db = SessionLocal()
    lock_key = f"suite_d_lock_{uuid.uuid4().hex[:6]}"
    try:
        expired_lock = DistributedLock(
            lock_key=lock_key,
            owner_id="crashed_old_worker",
            generation=1,
            acquired_at=datetime.utcnow() - timedelta(seconds=120),
            expires_at=datetime.utcnow() - timedelta(seconds=60)
        )
        db.add(expired_lock)
        db.commit()

        ctx = multiprocessing.get_context("spawn")
        queue = ctx.Queue()

        p1 = ctx.Process(target=_acquire_lock_in_process, args=(lock_key, "worker_d_1", queue))
        p2 = ctx.Process(target=_acquire_lock_in_process, args=(lock_key, "worker_d_2", queue))

        p1.start()
        p2.start()

        p1.join(timeout=10)
        p2.join(timeout=10)

        for p in (p1, p2):
            if p.is_alive():
                p.terminate()
                p.join(timeout=2)

        assert p1.exitcode == 0
        assert p2.exitcode == 0

        results = [queue.get(timeout=5) for _ in range(2)]
        won = sum(1 for _, res in results if res is True)
        lost = sum(1 for _, res in results if res is False)

        assert won == 1, f"Exactly 1 process must reclaim the expired lock; results: {results}"
        assert lost == 1, f"Exactly 1 process must be rejected; results: {results}"

        # In DB, generation must be 2
        lock_rec = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert lock_rec.generation == 2
    finally:
        db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
        db.commit()
        db.close()

def test_scheduler_suite_e_heartbeat_renewal_multiple_times():
    """Test E: Heartbeat renewal periodically extends lease expiration."""
    db = SessionLocal()
    lock_key = f"suite_e_lock_{uuid.uuid4().hex[:6]}"
    worker_id = "heartbeat_worker_e"
    try:
        acquired = acquire_distributed_lock(db, lock_key, worker_id, ttl_seconds=3)
        assert acquired is True

        gen = get_lock_generation(db, lock_key, worker_id)
        assert gen == 1

        hb = LockHeartbeat(lock_key, worker_id, interval=0.2, lease_extension=4, generation=gen)
        hb.start()

        import time
        time.sleep(0.7)  # Multiple renewal triggers

        assert hb.is_lock_lost() is False

        lock_rec = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert lock_rec.owner_id == worker_id
        assert lock_rec.expires_at > datetime.utcnow()
        hb.stop()
    finally:
        db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
        db.commit()
        db.close()

def test_scheduler_suite_f_worker_ownership_renewal_isolation():
    """Test F: Worker ownership isolation: non-owners or wrong generations cannot renew."""
    db = SessionLocal()
    lock_key = f"suite_f_lock_{uuid.uuid4().hex[:6]}"
    worker_1 = "owner_worker_f"
    imposter = "imposter_worker_f"
    try:
        acquire_distributed_lock(db, lock_key, worker_1, ttl_seconds=60)

        # Imposter renewal fails
        assert renew_distributed_lock(db, lock_key, imposter, extension_seconds=300) is False

        # Wrong generation renewal fails
        assert renew_distributed_lock(db, lock_key, worker_1, extension_seconds=300, expected_generation=999) is False

        # Valid owner and generation succeeds
        assert renew_distributed_lock(db, lock_key, worker_1, extension_seconds=300, expected_generation=1) is True
    finally:
        db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
        db.commit()
        db.close()

def test_scheduler_suite_g_worker_ownership_release_isolation():
    """Test G: Worker release isolation: non-owners or wrong generations cannot release."""
    db = SessionLocal()
    lock_key = f"suite_g_lock_{uuid.uuid4().hex[:6]}"
    worker_1 = "owner_worker_g"
    imposter = "imposter_worker_g"
    try:
        acquire_distributed_lock(db, lock_key, worker_1, ttl_seconds=60)

        # Imposter release fails
        assert release_distributed_lock(db, lock_key, imposter) is False
        assert db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first() is not None

        # Wrong generation release fails
        assert release_distributed_lock(db, lock_key, worker_1, expected_generation=999) is False
        assert db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first() is not None

        # Legitimate owner releases
        assert release_distributed_lock(db, lock_key, worker_1, expected_generation=1) is True
        assert db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first() is None
    finally:
        db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
        db.commit()
        db.close()

def test_scheduler_suite_h_long_running_assessment_heartbeat():
    """Test H: Long-running review execution maintains heartbeat without losing lease."""
    db = SessionLocal()
    org = get_or_create_test_org(db)
    proj = Project(org_id=org.id, name=f"Suite H Proj {uuid.uuid4().hex[:6]}")
    db.add(proj)
    db.commit()

    lock_key = f"suite_h_lock_{uuid.uuid4().hex[:6]}"
    worker_id = "long_worker_h"
    try:
        acquired = acquire_distributed_lock(db, lock_key, worker_id, ttl_seconds=2)
        assert acquired is True

        gen = get_lock_generation(db, lock_key, worker_id)
        hb = LockHeartbeat(lock_key, worker_id, interval=0.2, lease_extension=3, generation=gen)
        hb.start()

        # Execute review with heartbeat running
        res = asyncio.run(execute_project_review(
            project_id=proj.id,
            trigger_type="scheduled",
            db_session=db,
            should_abort=hb.is_lock_lost,
            fencing_key=lock_key,
            fencing_owner=worker_id,
            fencing_generation=gen
        ))
        assert res is not None
        assert res.status == "completed"
        assert hb.is_lock_lost() is False
        hb.stop()
    finally:
        db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
        db.commit()
        db.close()

def test_scheduler_suite_i_mid_execution_fencing_rejection_and_rollback():
    """Test I: Mid-execution lock loss or fencing token change safely rolls back without stale writes."""
    db = SessionLocal()
    org = get_or_create_test_org(db)
    proj = Project(org_id=org.id, name=f"Suite I Proj {uuid.uuid4().hex[:6]}")
    db.add(proj)
    db.commit()

    lock_key = f"suite_i_lock_{uuid.uuid4().hex[:6]}"
    worker_id = "worker_i_initial"
    try:
        acquire_distributed_lock(db, lock_key, worker_id, ttl_seconds=60)

        # Fencing assertion with generation mismatch immediately raises RuntimeError
        with pytest.raises(RuntimeError, match="Fencing token validation failed"):
            assert_valid_fenced_lease(db, lock_key, worker_id, expected_generation=999)

        # In pipeline, passing stale expected generation aborts execution immediately
        with pytest.raises(RuntimeError, match="Fencing token validation failed"):
            asyncio.run(execute_project_review(
                project_id=proj.id,
                trigger_type="scheduled",
                db_session=db,
                fencing_key=lock_key,
                fencing_owner=worker_id,
                fencing_generation=999  # Stale generation
            ))
    finally:
        db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).delete()
        db.commit()
        db.close()

def test_scheduler_suite_j_transient_db_interruption_during_heartbeat():
    """Test J: LockHeartbeat retries on transient errors and marks lock lost if retries exceeded."""
    lock_key = f"suite_j_lock_{uuid.uuid4().hex[:6]}"
    worker_id = "worker_j_transient"

    # Heartbeat targeting non-existent lock will fail after retries and mark lock as lost
    hb = LockHeartbeat(lock_key, worker_id, interval=0.1, lease_extension=10, max_retries=2, generation=1)
    hb.start()

    import time
    time.sleep(0.4)

    assert hb.is_lock_lost() is True, "Heartbeat must flag lock as lost when renewal fails"
    hb.stop()


# -------------------------------------------------------------
# 4. AI PROVIDER VERIFICATION TESTS (AUTHENTICATED PROBES)
# -------------------------------------------------------------
def test_ai_provider_verification_gemini_unconfigured():
    analyzer = AITechnologyDebtAnalyzer(gemini_key="")
    res = asyncio.run(analyzer.verify_connectivity("gemini"))
    assert res["status"] == "unconfigured"
    assert res["connected"] is False

def test_ai_provider_verification_gemini_connected():
    analyzer = AITechnologyDebtAnalyzer(gemini_key="valid-mock-key")
    mock_resp = MagicMock(status_code=200)
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("gemini"))
        assert res["status"] == "connected"
        assert res["connected"] is True

def test_ai_provider_verification_gemini_invalid_key():
    analyzer = AITechnologyDebtAnalyzer(gemini_key="invalid-key")
    mock_resp = MagicMock(status_code=403, text="API key not valid")
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("gemini"))
        assert res["status"] == "invalid_credentials"
        assert res["connected"] is False

def test_ai_provider_verification_gemini_quota_exceeded():
    analyzer = AITechnologyDebtAnalyzer(gemini_key="rate-limited-key")
    mock_resp = MagicMock(status_code=429)
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("gemini"))
        assert res["status"] == "quota_exceeded"
        assert res["connected"] is False

def test_ai_provider_verification_openai_connected():
    analyzer = AITechnologyDebtAnalyzer(openai_key="sk-mock-valid-key")
    mock_resp = MagicMock(status_code=200)
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("openai"))
        assert res["status"] == "connected"
        assert res["connected"] is True

def test_ai_provider_verification_openai_invalid_key():
    analyzer = AITechnologyDebtAnalyzer(openai_key="sk-invalid-key")
    mock_resp = MagicMock(status_code=401)
    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("openai"))
        assert res["status"] == "invalid_credentials"
        assert res["connected"] is False

@pytest.mark.skipif(
    not os.getenv("GEMINI_API_KEY"),
    reason="GEMINI_API_KEY environment variable required for live integration test"
)
def test_ai_provider_live_gemini_connectivity():
    """Live Gemini API connectivity test when actual GEMINI_API_KEY is configured in environment."""
    key = os.getenv("GEMINI_API_KEY")
    analyzer = AITechnologyDebtAnalyzer(gemini_key=key)
    res = asyncio.run(analyzer.verify_connectivity("gemini"))
    assert res["status"] in ["connected", "invalid_credentials", "quota_exceeded"]
    assert "message" in res

@pytest.mark.skipif(
    not os.getenv("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY environment variable required for live integration test"
)
def test_ai_provider_live_openai_connectivity():
    """Live OpenAI API connectivity test when actual OPENAI_API_KEY is configured in environment."""
    key = os.getenv("OPENAI_API_KEY")
    analyzer = AITechnologyDebtAnalyzer(openai_key=key)
    res = asyncio.run(analyzer.verify_connectivity("openai"))
    assert res["status"] in ["connected", "invalid_credentials", "quota_exceeded"]
    assert "message" in res


# -------------------------------------------------------------
# 5. MEMENTO ARCHITECTURE & AUTHORITATIVE POSTGRESQL MEMORY
# -------------------------------------------------------------
def test_memento_authoritative_postgresql_memory_creation():
    """Verify that snapshot creation authoritatively records postgresql provenance."""
    mem = MementoMemoryAdapter()
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(org_id=org.id, name=f"Memento Auth Proj {uuid.uuid4().hex[:6]}")
        db.add(proj)
        db.commit()

        ass = Assessment(project_id=proj.id, status="completed", overall_health_score=90.0)
        db.add(ass)
        db.commit()

        hist = asyncio.run(mem.record_assessment_snapshot(
            db=db,
            project_id=proj.id,
            assessment_id=ass.id,
            overall_score=90.0,
            risk_classification="Healthy",
            tech_scores=[],
            identified_risks=[]
        ))
        assert hist.storage_provider == "postgresql"
        assert hist.sync_status == "authoritative_postgresql"
        assert hist.sync_error == ""
    finally:
        db.close()

def test_memento_authoritative_postgresql_memory_retrieval():
    """Verify that get_historical_memories retrieves memories authoritatively from PostgreSQL."""
    mem = MementoMemoryAdapter()
    db = SessionLocal()
    try:
        proj = get_or_create_test_project(db)
        ass = Assessment(project_id=proj.id, status="completed", overall_health_score=85.0)
        db.add(ass)
        db.commit()

        asyncio.run(mem.record_assessment_snapshot(
            db=db,
            project_id=proj.id,
            assessment_id=ass.id,
            overall_score=85.0,
            risk_classification="Good",
            tech_scores=[],
            identified_risks=[]
        ))

        memories = asyncio.run(mem.get_historical_memories(db, proj.id))
        assert memories["storage_provider"] == "postgresql"
        assert memories["remote_sync_status"] == "authoritative_postgresql"
        assert len(memories["memories"]) >= 1
    finally:
        db.close()

def test_memento_mcp_architecture_verification():
    """Verify that verify_connectivity() truthfully reports PostgreSQL as authoritative and notes MCP architecture."""
    mem = MementoMemoryAdapter()
    res = asyncio.run(mem.verify_connectivity())
    assert res["status"] == "postgresql_authoritative"
    assert res["mode"] == "postgresql"
    assert res["connected"] is True
    assert res["mcp_architecture"] == "local_first_mcp_sqlite"
    assert "runmemento.com" in res["message"]

def test_memento_delta_comparison_with_postgresql_provenance():
    """Verify that generate_delta_comparison reports postgresql storage provider."""
    mem = MementoMemoryAdapter()
    db = SessionLocal()
    try:
        proj = get_or_create_test_project(db)
        ass = Assessment(project_id=proj.id, status="completed", overall_health_score=88.0)
        db.add(ass)
        db.commit()

        asyncio.run(mem.record_assessment_snapshot(
            db=db,
            project_id=proj.id,
            assessment_id=ass.id,
            overall_score=88.0,
            risk_classification="Healthy",
            tech_scores=[],
            identified_risks=[]
        ))

        comp = asyncio.run(mem.generate_delta_comparison(db, ass.id))
        assert comp["storage_provider"] == "postgresql"
        assert comp["current_health_score"] == 88.0
    finally:
        db.close()

@pytest.mark.skipif(
    not os.getenv("MEMENTO_API_KEY"),
    reason="MEMENTO_API_KEY environment variable required for live integration test"
)
def test_memento_live_api_connectivity_and_operations():
    """
    Live Memento API integration test.
    Only executed when actual MEMENTO_API_KEY is available in the environment.
    """
    api_key = os.getenv("MEMENTO_API_KEY")
    endpoint = os.getenv("MEMENTO_API_URL", "https://api.memento.ai/v1")
    mem = MementoMemoryAdapter(api_key=api_key, endpoint=endpoint)

    res = asyncio.run(mem.verify_connectivity())
    assert "status" in res
    assert "mode" in res
