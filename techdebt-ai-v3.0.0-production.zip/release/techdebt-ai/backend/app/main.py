import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.config import settings
from app.database import engine, Base
from app.api.v1 import api_v1_router
from app.seed_data import seed
from app.services.scheduler_service import start_scheduler, scheduler

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("techdebt_ai")

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Run Alembic migrations programmatically
    logger.info("Verifying and applying Alembic database migrations...")
    try:
        import os
        from alembic.config import Config
        from alembic import command
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        ini_path = os.path.join(base_dir, "alembic.ini")
        if os.path.exists(ini_path):
            alembic_cfg = Config(ini_path)
            alembic_cfg.set_main_option("script_location", os.path.join(base_dir, "alembic"))
            alembic_cfg.set_main_option("sqlalchemy.url", settings.DATABASE_URL)
            command.upgrade(alembic_cfg, "head")
            logger.info("Alembic schema migrations successfully applied to head.")
        else:
            Base.metadata.create_all(bind=engine)
    except Exception as e:
        logger.warning(f"Alembic startup migration note: {e}. Ensuring schema via metadata.")
        Base.metadata.create_all(bind=engine)
    
    try:
        seed()
    except Exception as e:
        logger.warning(f"Seed step notice: {e}")

    try:
        start_scheduler()
        logger.info("Background review scheduler started.")
    except Exception as e:
        logger.warning(f"Scheduler initialization note: {e}")

    yield

    # Shutdown
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("Background review scheduler gracefully shut down.")

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="TechDebt AI – Production-grade Technology Debt Review Assistant for engineering teams.",
    version="1.0.0",
    lifespan=lifespan
)

# Explicit CORS Origins (never wildcard in production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Accept"],
)

# Global Exception Handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception on {request.method} {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "An internal server error occurred.",
            "error_code": "INTERNAL_SERVER_ERROR"
        }
    )

# Include v1 API router
app.include_router(api_v1_router, prefix=settings.API_V1_STR)

@app.get("/health", tags=["Health"])
def health_check():
    return {
        "status": "healthy",
        "app": settings.PROJECT_NAME,
        "environment": settings.ENVIRONMENT,
        "api_version": "v1"
    }

@app.get("/", tags=["Root"])
def root():
    return {
        "message": "Welcome to TechDebt AI API – Technology Debt Review Assistant",
        "docs_url": "/docs",
        "health_check": "/health",
        "version": "1.0.0"
    }
