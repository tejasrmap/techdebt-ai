import os
import sys
from typing import Optional, List
from pydantic import BaseModel, field_validator

DEFAULT_DEV_SECRET = "techdebt-ai-super-secret-development-key-2025-jwt"

class Settings(BaseModel):
    PROJECT_NAME: str = "TechDebt AI"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development").lower()

    # JWT Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", DEFAULT_DEV_SECRET)
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440"))  # 24 hours default

    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./techdebt.db")

    # AI Providers
    OPENAI_API_KEY: Optional[str] = os.getenv("OPENAI_API_KEY", "")
    GEMINI_API_KEY: Optional[str] = os.getenv("GEMINI_API_KEY", "")
    DEFAULT_AI_PROVIDER: str = os.getenv("DEFAULT_AI_PROVIDER", "gemini")
    AI_MODEL_NAME: str = os.getenv("AI_MODEL_NAME", "gemini-1.5-flash")
    AI_TEMPERATURE: float = float(os.getenv("AI_TEMPERATURE", "0.2"))

    # Intelligence & Memory
    FIRECRAWL_API_KEY: Optional[str] = os.getenv("FIRECRAWL_API_KEY", "")
    FIRECRAWL_API_URL: str = os.getenv("FIRECRAWL_API_URL", "https://api.firecrawl.dev/v1")
    MEMENTO_API_KEY: Optional[str] = os.getenv("MEMENTO_API_KEY", "")
    MEMENTO_API_URL: str = os.getenv("MEMENTO_API_URL", "https://api.memento.ai/v1")

    # Security & Upload Validation
    MAX_UPLOAD_SIZE_BYTES: int = 2 * 1024 * 1024  # 2 MB max
    ENABLE_DEMO_SEED: bool = os.getenv("ENABLE_DEMO_SEED", "true").lower() == "true"
    ENCRYPTION_KEY: Optional[str] = os.getenv("ENCRYPTION_KEY", "")
    ALLOW_PLATFORM_INTEGRATION_FALLBACK: bool = os.getenv("ALLOW_PLATFORM_INTEGRATION_FALLBACK", "false").lower() == "true"

    # CORS Origins
    CORS_ORIGINS: List[str] = []

    def __init__(self, **values):
        super().__init__(**values)
        raw_origins = os.getenv("CORS_ORIGINS", "")
        if raw_origins:
            self.CORS_ORIGINS = [o.strip() for o in raw_origins.split(",") if o.strip()]
        else:
            if self.ENVIRONMENT == "production":
                # In production, require explicit origins or default to localhost domain without wildcard
                self.CORS_ORIGINS = ["http://localhost", "https://localhost"]
            else:
                self.CORS_ORIGINS = [
                    "http://localhost:5173",
                    "http://127.0.0.1:5173",
                    "http://localhost:3000",
                    "http://localhost:8000"
                ]

        # Enforce strong secret key in production
        if self.ENVIRONMENT == "production":
            if self.SECRET_KEY == DEFAULT_DEV_SECRET or len(self.SECRET_KEY) < 32:
                raise ValueError(
                    "FATAL SECURITY VIOLATION: In production, SECRET_KEY must be set via environment variable "
                    "and must be at least 32 characters long. Hardcoded default secrets are strictly prohibited."
                )

settings = Settings()
