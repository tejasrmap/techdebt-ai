import logging
import asyncio
import os
import uuid
from datetime import datetime, timedelta
from typing import Optional, Callable, Any, Dict, List
from croniter import croniter
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.database import SessionLocal
from app.models.all_models import (
    ScheduledReview, ReviewJob, Project, TechnologyScore,
    RiskFinding, EvidenceSource, Assessment, AuditLog, DistributedLock
)
from app.services.firecrawl_service import FirecrawlIntelligenceService
from app.services.ai_analyzer import AITechnologyDebtAnalyzer
from app.services.memento_adapter import MementoMemoryAdapter

logger = logging.getLogger(__name__)

scheduler = BackgroundScheduler()

def acquire_distributed_lock(db: Session, lock_key: str, owner_id: str, ttl_seconds: int = 600) -> bool:
    """
    Atomically acquire a distributed lock in the database.
    Prevents simultaneous execution across multiple worker processes.
    Expired locks are automatically reclaimed.
    """
    now = datetime.utcnow()
    expires_at = now + timedelta(seconds=ttl_seconds)

    try:
        existing = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        if existing:
            if existing.expires_at <= now:
                # Reclaim expired lock safely without session identity map conflicts
                existing.owner_id = owner_id
                existing.acquired_at = now
                existing.expires_at = expires_at
                db.commit()
                return True
            # Lock is active and held by an unexpired lease
            return False

        # No lock exists: insert new
        lock = DistributedLock(
            lock_key=lock_key,
            owner_id=owner_id,
            acquired_at=now,
            expires_at=expires_at
        )
        db.add(lock)
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        return False
    except Exception as e:
        logger.warning(f"Error acquiring lock {lock_key}: {e}")
        db.rollback()
        return False

def release_distributed_lock(db: Session, lock_key: str, owner_id: str) -> bool:
    """Release an active distributed lock owned by owner_id."""
    try:
        deleted = (
            db.query(DistributedLock)
            .filter(
                DistributedLock.lock_key == lock_key,
                DistributedLock.owner_id == owner_id
            )
            .delete(synchronize_session=False)
        )
        db.commit()
        return deleted > 0
    except Exception as e:
        logger.warning(f"Error releasing lock {lock_key}: {e}")
        db.rollback()
        return False

def renew_distributed_lock(db: Session, lock_key: str, owner_id: str, extension_seconds: int = 600) -> bool:
    """
    Extend the expiration time of an active lease held by owner_id.
    Ensures safe lock renewal for reviews executing longer than lease TTL (e.g. > 10 minutes).
    """
    now = datetime.utcnow()
    new_expires_at = now + timedelta(seconds=extension_seconds)
    try:
        updated = (
            db.query(DistributedLock)
            .filter(
                DistributedLock.lock_key == lock_key,
                DistributedLock.owner_id == owner_id,
                DistributedLock.expires_at > now
            )
            .update({"expires_at": new_expires_at})
        )
        db.commit()
        return updated > 0
    except Exception as e:
        logger.warning(f"Error renewing lease {lock_key} for {owner_id}: {e}")
        db.rollback()
        return False

import threading

class LockHeartbeat:
    """
    Background heartbeat thread that periodically renews the distributed lease.
    If renewal fails (indicating lost lock ownership or persistent database failure
    exceeding the bounded retry budget), sets `lost_lock_event`, enabling the worker
    to safely abort assessment execution immediately without committing stale results.
    """
    def __init__(self, lock_key: str, worker_id: str, interval: float = 15.0, lease_extension: int = 600, max_retries: int = 3):
        self.lock_key = lock_key
        self.worker_id = worker_id
        self.interval = float(interval)
        self.lease_extension = lease_extension
        self.max_retries = max_retries
        self.stop_event = threading.Event()
        self.lost_lock_event = threading.Event()
        self.thread: Optional[threading.Thread] = None

    def start(self):
        self.thread = threading.Thread(target=self._run, name=f"Heartbeat_{self.lock_key}", daemon=True)
        self.thread.start()

    def _run(self):
        import time
        while not self.stop_event.wait(self.interval):
            if self.stop_event.is_set():
                break

            renewal_successful = False
            # Bounded retry loop for transient database connectivity or locking errors
            for attempt in range(self.max_retries):
                if self.stop_event.is_set():
                    return
                db = SessionLocal()
                try:
                    # Verify lock state and ownership in database
                    now = datetime.utcnow()
                    lock_rec = (
                        db.query(DistributedLock)
                        .filter(DistributedLock.lock_key == self.lock_key)
                        .first()
                    )

                    # If lock record is gone, owned by another worker, or already expired:
                    if not lock_rec or lock_rec.owner_id != self.worker_id or lock_rec.expires_at <= now:
                        logger.error(
                            f"CRITICAL: Worker {self.worker_id} verified lost ownership for lease {self.lock_key}! "
                            f"(Record owner: {lock_rec.owner_id if lock_rec else 'None'}, "
                            f"expired: {lock_rec.expires_at <= now if lock_rec else True})"
                        )
                        self.lost_lock_event.set()
                        return

                    # Extend lease atomically
                    lock_rec.expires_at = now + timedelta(seconds=self.lease_extension)
                    db.commit()
                    renewal_successful = True
                    break
                except Exception as e:
                    logger.warning(
                        f"Transient DB exception during lock heartbeat attempt {attempt + 1}/{self.max_retries} "
                        f"for {self.lock_key}: {e}"
                    )
                    db.rollback()
                    time.sleep(0.2 * (attempt + 1))
                finally:
                    db.close()

            # If bounded retries exhausted without safe renewal, treat lock as lost
            if not renewal_successful and not self.stop_event.is_set():
                logger.error(
                    f"CRITICAL: Worker {self.worker_id} failed to renew lease {self.lock_key} "
                    f"after {self.max_retries} attempts! Marking lock as lost to protect data safety."
                )
                self.lost_lock_event.set()
                break

    def is_lock_lost(self) -> bool:
        return self.lost_lock_event.is_set()

    def mark_lost(self):
        """Allows tests or external events to signal that lock ownership was lost."""
        self.lost_lock_event.set()

    def stop(self):
        self.stop_event.set()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2.0)

def validate_and_compute_next_run(cron_expr: str) -> datetime:
    """Validate cron expression and return next execution datetime."""
    if not croniter.is_valid(cron_expr):
        raise ValueError(f"Invalid cron expression: '{cron_expr}'")
    iter_obj = croniter(cron_expr, datetime.utcnow())
    return iter_obj.get_next(datetime)

async def execute_project_review(
    project_id: str,
    trigger_type: str = "scheduled",
    db_session: Optional[Session] = None,
    enforce_org_id: Optional[str] = None,
    should_abort: Optional[Callable[[], bool]] = None
) -> Assessment:
    """Core review pipeline executed manually or via scheduler."""
    close_db = False
    if db_session is None:
        db = SessionLocal()
        close_db = True
    else:
        db = db_session

    try:
        query = db.query(Project).filter(Project.id == project_id)
        if enforce_org_id:
            query = query.filter(Project.org_id == enforce_org_id)
        project = query.first()
        if not project:
            raise ValueError(f"Project {project_id} not found or unauthorized")

        from app.services.integration_config_service import (
            get_firecrawl_service_for_org,
            get_ai_analyzer_for_org,
            get_memento_adapter_for_org
        )

        firecrawl_svc = get_firecrawl_service_for_org(project.org_id, db)
        ai_analyzer = get_ai_analyzer_for_org(project.org_id, db)
        memento_adapter = get_memento_adapter_for_org(project.org_id, db)

        # Step 1: Create Assessment record
        assessment = Assessment(
            project_id=project_id,
            trigger_type=trigger_type,
            status="processing",
            overall_health_score=None,
            risk_classification="Healthy",
            confidence_level="High"
        )
        db.add(assessment)
        db.commit()
        db.refresh(assessment)

        # Step 2: Iterate over project technologies & gather intelligence
        total_scores = []
        all_risks = []
        tech_score_records = []

        for p_tech in project.project_technologies:
            if should_abort and should_abort():
                logger.error(f"Execution aborted for project {project_id}: Distributed lock ownership lost or cancelled.")
                raise RuntimeError("Review aborted: Worker lost distributed lock ownership")

            tech = p_tech.technology
            # Gather live intelligence / registry metadata
            intel = await firecrawl_svc.gather_technology_intelligence(
                tech_name=tech.name,
                ecosystem=tech.ecosystem,
                installed_version=p_tech.installed_version
            )

            if should_abort and should_abort():
                logger.error(f"Execution aborted for project {project_id}: Distributed lock ownership lost during intelligence gathering.")
                raise RuntimeError("Review aborted: Worker lost distributed lock ownership")

            # Update tech with latest registry version if unknown
            if tech.latest_stable_version == "unknown" and intel.get("latest_stable_version"):
                tech.latest_stable_version = intel["latest_stable_version"]
                tech.is_deprecated = intel.get("is_deprecated", False)
                db.commit()

            # Step 3: Run AI / evidence-grounded scoring
            analysis = await ai_analyzer.analyze_technology(
                tech_name=tech.name,
                installed_version=p_tech.installed_version,
                latest_version=intel.get("latest_stable_version", tech.latest_stable_version),
                is_deprecated=intel.get("is_deprecated", tech.is_deprecated),
                evidence_sources=intel.get("evidence_sources", []),
                project_context=project.description
            )

            # Check 3: Lock ownership checkpoint after AI analysis
            if should_abort and should_abort():
                logger.error(f"Execution aborted for project {project_id}: Distributed lock ownership lost after AI analysis of {tech.name}.")
                raise RuntimeError("Review aborted: Worker lost distributed lock ownership")

            overall_tech_score = analysis.get("overall_score", 85.0)
            total_scores.append(overall_tech_score)

            # Save TechnologyScore
            score_rec = TechnologyScore(
                assessment_id=assessment.id,
                technology_id=tech.id,
                overall_score=overall_tech_score,
                risk_classification=analysis.get("risk_classification", "Good"),
                maintenance_health=analysis.get("maintenance_health", 90.0),
                security_exposure=analysis.get("security_exposure", 95.0),
                version_currency=analysis.get("version_currency", 90.0),
                community_activity=analysis.get("community_activity", 85.0),
                documentation_quality=analysis.get("documentation_quality", 85.0),
                ecosystem_compatibility=analysis.get("ecosystem_compatibility", 90.0),
                sustainability=analysis.get("sustainability", 90.0),
                upgrade_complexity=analysis.get("upgrade_complexity", 90.0),
                confidence_level=analysis.get("confidence_level", "High"),
                recommended_action=analysis.get("recommended_action", ""),
                upgrade_complexity_level=analysis.get("upgrade_complexity_level", "Low"),
                notes="; ".join(analysis.get("identified_problems", []))
            )
            db.add(score_rec)

            # Save Evidence Sources
            for ev in intel.get("evidence_sources", []):
                ev_rec = EvidenceSource(
                    assessment_id=assessment.id,
                    technology_id=tech.id,
                    url=ev.get("url", ""),
                    title=ev.get("title", tech.name),
                    source_type=ev.get("source_type", "documentation"),
                    reliability_score=ev.get("reliability_score", 1.0),
                    publication_date=ev.get("publication_date"),
                    is_official=ev.get("is_official", True),
                    snippet=ev.get("snippet", "")
                )
                db.add(ev_rec)

            # Save Risk Findings
            for r in analysis.get("risks", []):
                risk_rec = RiskFinding(
                    assessment_id=assessment.id,
                    technology_id=tech.id,
                    project_id=project.id,
                    severity=r.get("severity", "Medium"),
                    title=r.get("title", ""),
                    description=r.get("description", ""),
                    business_impact=r.get("business_impact", ""),
                    technical_impact=r.get("technical_impact", ""),
                    status="Open"
                )
                db.add(risk_rec)
                all_risks.append(r)

            tech_score_records.append({
                "technology_name": tech.name,
                "score": overall_tech_score,
                "classification": analysis.get("risk_classification", "Good")
            })

        # Calculate Project-level composite score
        if not total_scores:
            assessment.overall_health_score = None
            assessment.risk_classification = "Not Assessed"
            assessment.confidence_level = "Unknown"
            assessment.status = "completed"
            assessment.summary = "No technologies detected in project inventory. Please add dependencies or upload a manifest to run an assessment."
            project.last_assessment_date = datetime.utcnow()
            db.commit()
            return assessment

        avg_score = round(sum(total_scores) / len(total_scores), 1)
        from app.services.ai_analyzer import classify_risk
        project_classification = classify_risk(avg_score)

        # Check 4: Lock ownership checkpoint immediately before persisting assessment results
        if should_abort and should_abort():
            logger.error(f"Execution aborted for project {project_id}: Distributed lock ownership lost immediately before persisting assessment results.")
            raise RuntimeError("Review aborted: Worker lost distributed lock ownership")

        assessment.overall_health_score = avg_score
        assessment.risk_classification = project_classification
        assessment.status = "completed"
        assessment.summary = (
            f"Assessment completed. Evaluated {len(total_scores)} technologies. "
            f"Overall health score is {avg_score}/100 ({project_classification}). "
            f"Identified {len(all_risks)} actionable risk finding(s)."
        )

        project.last_assessment_date = datetime.utcnow()
        db.commit()

        # Check 5: Lock ownership checkpoint immediately before historical snapshot creation
        if should_abort and should_abort():
            logger.error(f"Execution aborted for project {project_id}: Distributed lock ownership lost immediately before historical snapshot creation.")
            raise RuntimeError("Review aborted: Worker lost distributed lock ownership")

        # Step 4: Record in Memento Memory
        await memento_adapter.record_assessment_snapshot(
            db=db,
            project_id=project.id,
            assessment_id=assessment.id,
            overall_score=avg_score,
            risk_classification=project_classification,
            tech_scores=tech_score_records,
            identified_risks=all_risks,
            project_name=project.name
        )

        return assessment

    except Exception as e:
        logger.error(f"Error executing assessment for project {project_id}: {e}")
        db.rollback()
        # CRITICAL: If lock ownership was lost, suppress status mutation to prevent stale commit
        if should_abort and should_abort():
            logger.warning(f"Worker lost lock ownership for project {project_id}; suppressing status write to prevent stale commit.")
            raise e

        if 'assessment' in locals() and assessment:
            try:
                assessment.status = "failed"
                assessment.summary = f"Review failed: {str(e)}"
                db.commit()
            except Exception:
                db.rollback()
        raise e
    finally:
        if close_db:
            db.close()

def run_scheduled_job(scheduled_review_id: str, max_retries: int = 2, worker_id: Optional[str] = None) -> bool:
    """
    APScheduler sync worker execution with atomic distributed locking, retries and status logging.
    Returns True if job was executed, False if skipped due to lock or inactive state.
    """
    db = SessionLocal()
    assigned_worker = worker_id or f"worker_{os.getpid()}_{uuid.uuid4().hex[:8]}"
    lock_key = f"review_job_lock_{scheduled_review_id}"
    lock_acquired = False

    try:
        review = db.query(ScheduledReview).filter(ScheduledReview.id == scheduled_review_id).first()
        if not review or not review.is_active:
            return False

        # 1. Atomic distributed lock acquisition
        lock_acquired = acquire_distributed_lock(db, lock_key, assigned_worker, ttl_seconds=600)
        if not lock_acquired:
            logger.info(
                f"Duplicate review execution prevented for schedule {scheduled_review_id}: "
                f"Lock currently held by another worker process."
            )
            return False

        # 2. Secondary check for active Running job
        active_running = (
            db.query(ReviewJob)
            .filter(
                ReviewJob.scheduled_review_id == scheduled_review_id,
                ReviewJob.status == "Running",
                ReviewJob.started_at > datetime.utcnow() - timedelta(minutes=10)
            )
            .first()
        )
        if active_running:
            logger.info(f"Active running job {active_running.id} already in progress for schedule {scheduled_review_id}.")
            return False

        job = ReviewJob(
            scheduled_review_id=scheduled_review_id,
            status="Running",
            started_at=datetime.utcnow()
        )
        db.add(job)
        db.commit()

        # Start reliable lock heartbeat to extend lease periodically during execution
        heartbeat = LockHeartbeat(lock_key, assigned_worker, interval=15, lease_extension=600)
        heartbeat.start()

        # 3. Run review pipeline with retry backoff and lock loss detection
        success = False
        last_error = ""
        for attempt in range(max_retries):
            if heartbeat.is_lock_lost():
                last_error = "Distributed lock ownership was lost by this worker."
                logger.error(f"Scheduled review {scheduled_review_id} aborted: worker lost distributed lock.")
                break

            try:
                asyncio.run(execute_project_review(
                    project_id=review.project_id,
                    trigger_type="scheduled",
                    db_session=db,
                    should_abort=heartbeat.is_lock_lost
                ))
                success = True
                break
            except Exception as e:
                last_error = str(e)
                if heartbeat.is_lock_lost():
                    logger.error(f"Review job for {scheduled_review_id} safely aborted due to lost lock: {e}")
                    break
                logger.warning(f"Review job attempt {attempt + 1} failed for schedule {scheduled_review_id}: {e}")
                import time
                time.sleep(1.0 * (attempt + 1))

        if success:
            if heartbeat.is_lock_lost():
                logger.error(
                    f"Scheduled review {scheduled_review_id}: Review finished but worker lost lock before job status commit; "
                    f"suppressing job commit to prevent stale update."
                )
                db.rollback()
                return False

            job.status = "Completed"
            job.completed_at = datetime.utcnow()
            review.last_run_at = datetime.utcnow()
            review.next_run_at = validate_and_compute_next_run(review.cron_expression)
            db.commit()
            return True
        else:
            if heartbeat.is_lock_lost():
                logger.warning(
                    f"Scheduled review {scheduled_review_id}: Worker lost lock during execution; "
                    f"suppressing job status commit so active lock owner controls execution."
                )
                db.rollback()
                return False

            job.status = "Failed"
            job.error_message = f"Failed after {max_retries} attempts: {last_error}"
            job.completed_at = datetime.utcnow()
            db.commit()
            return False

    except Exception as e:
        logger.error(f"Error in scheduled job execution: {e}")
        db.rollback()
        return False
    finally:
        lock_lost_state = False
        if 'heartbeat' in locals() and heartbeat:
            lock_lost_state = heartbeat.is_lock_lost()
            heartbeat.stop()

        if lock_acquired and not lock_lost_state:
            release_distributed_lock(db, lock_key, assigned_worker)
        db.close()

def register_job_in_scheduler(schedule: ScheduledReview):
    """
    Register or update recurring job in APScheduler.
    Prevents duplicate scheduling or timer reset during periodic schedule synchronization.
    """
    job_id = f"review_job_{schedule.id}"
    try:
        existing = scheduler.get_job(job_id)
        if not schedule.is_active:
            if existing:
                scheduler.remove_job(job_id)
                logger.info(f"Removed inactive review job from scheduler: {job_id}")
            return

        trigger = CronTrigger.from_crontab(schedule.cron_expression)
        if existing:
            # If job already exists with matching trigger expression, avoid duplicate rescheduling
            if str(existing.trigger) == str(trigger):
                return
            scheduler.reschedule_job(job_id, trigger=trigger)
            logger.info(f"Updated recurring review job trigger: {job_id} ({schedule.cron_expression})")
        else:
            scheduler.add_job(
                run_scheduled_job,
                trigger=trigger,
                args=[schedule.id],
                id=job_id,
                replace_existing=True
            )
            logger.info(f"Registered recurring review job: {job_id} ({schedule.cron_expression})")
    except Exception as e:
        logger.error(f"Failed to register job {job_id}: {e}")
        raise ValueError(f"Failed to register recurring schedule in APScheduler: {str(e)}")

def unregister_job_from_scheduler(schedule_id: str):
    """Remove recurring job from APScheduler."""
    job_id = f"review_job_{schedule_id}"
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)
        logger.info(f"Removed review job from scheduler: {job_id}")

def restore_all_scheduled_jobs():
    """Restore all active recurring review jobs on application startup."""
    db = SessionLocal()
    try:
        active_reviews = db.query(ScheduledReview).filter(ScheduledReview.is_active == True).all()
        for r in active_reviews:
            try:
                # Update next run at
                r.next_run_at = validate_and_compute_next_run(r.cron_expression)
                register_job_in_scheduler(r)
            except Exception as e:
                logger.warning(f"Could not restore schedule {r.id}: {e}")
        db.commit()
        logger.info(f"Restored {len(active_reviews)} scheduled review jobs.")
    except Exception as e:
        logger.error(f"Error restoring scheduled jobs: {e}")
        db.rollback()
    finally:
        db.close()

def start_scheduler():
    if not scheduler.running:
        scheduler.start()
        restore_all_scheduled_jobs()
