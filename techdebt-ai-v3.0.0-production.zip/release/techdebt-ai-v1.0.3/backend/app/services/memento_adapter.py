import os
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from app.config import settings
from app.models.all_models import HistoricalAssessment, Assessment, TechnologyScore, RiskFinding, Project

logger = logging.getLogger(__name__)

class MementoMemoryAdapter:
    """
    Adapter layer for historical assessment memory context.
    
    Official Memento Architecture Evaluation:
    Official Memento (https://runmemento.com, https://github.com/veerps57/memento) is an open-source
    local-first Model Context Protocol (MCP) server that operates over stdio JSON-RPC using an embedded
    SQLite database at ~/.local/share/memento/memento.db.
    
    In a multi-tenant enterprise backend:
    1. Spawning local stdio MCP processes inside a multi-worker backend lacks tenant isolation (all tenants
       would share a single SQLite file) and causes SQLite concurrency locking bottlenecks.
    2. runmemento.com does NOT provide a hosted multi-tenant cloud REST API.
    
    Therefore, TechDebt AI retains PostgreSQL as the authoritative multi-tenant historical memory store.
    Unsupported cloud REST endpoints are disabled, and the system truthfully reports PostgreSQL provenance.
    """
    def __init__(self, api_key: Optional[str] = None, endpoint: Optional[str] = None):
        self.api_key = api_key if api_key is not None else settings.MEMENTO_API_KEY
        self.endpoint = (endpoint or settings.MEMENTO_API_URL).rstrip("/")
        self.mode = "postgresql"
        self.is_configured = True

    async def verify_connectivity(self) -> Dict[str, Any]:
        """
        Verify historical memory integration status.
        Truthfully reports PostgreSQL as the authoritative multi-tenant storage engine,
        clarifying that official Memento is a local-first MCP stdio tool.
        """
        return {
            "status": "postgresql_authoritative",
            "mode": "postgresql",
            "connected": True,
            "mcp_architecture": "local_first_mcp_sqlite",
            "message": (
                "PostgreSQL is active as the authoritative multi-tenant historical memory store. "
                "Official Memento (runmemento.com) is an MCP stdio tool designed for local developer IDEs; "
                "unsupported cloud REST integration is disabled."
            )
        }

    async def record_assessment_snapshot(
        self,
        db: Session,
        project_id: str,
        assessment_id: str,
        overall_score: Optional[float],
        risk_classification: str,
        tech_scores: List[Dict[str, Any]],
        identified_risks: List[Dict[str, Any]],
        project_name: str = ""
    ) -> HistoricalAssessment:
        """
        Record assessment snapshot in historical memory and calculate delta from previous assessment.
        Authoritatively persisted in PostgreSQL with strict tenant-isolation.
        """
        # Find previous assessment for this project
        prev_record = (
            db.query(HistoricalAssessment)
            .filter(HistoricalAssessment.project_id == project_id)
            .order_by(HistoricalAssessment.created_at.desc())
            .first()
        )

        score_delta = 0.0
        summary_of_changes = "Initial baseline assessment recorded."
        new_risks_count = len(identified_risks)
        resolved_risks_count = 0
        score_val = overall_score if overall_score is not None else 0.0

        if prev_record:
            prev_val = prev_record.health_score if prev_record.health_score is not None else 0.0
            score_delta = round(score_val - prev_val, 1)
            prev_snapshot = prev_record.snapshot_data or {}
            prev_risk_titles = {r.get("title") for r in prev_snapshot.get("risks", [])}
            curr_risk_titles = {r.get("title") for r in identified_risks}

            new_risks = curr_risk_titles - prev_risk_titles
            resolved_risks = prev_risk_titles - curr_risk_titles
            new_risks_count = len(new_risks)
            resolved_risks_count = len(resolved_risks)

            if score_delta > 0:
                summary_of_changes = f"Health score improved by +{score_delta} points. {resolved_risks_count} previously active risk(s) resolved."
            elif score_delta < 0:
                summary_of_changes = f"Health score declined by {score_delta} points. {new_risks_count} new risk(s) identified (e.g. {', '.join(list(new_risks)[:2]) if new_risks else 'version drift'})."
            else:
                summary_of_changes = "Health score remained stable compared to the previous assessment."

        snapshot_payload = {
            "project_id": project_id,
            "project_name": project_name,
            "overall_health_score": overall_score,
            "risk_classification": risk_classification,
            "technology_scores": tech_scores,
            "risks": identified_risks,
            "recorded_at": datetime.utcnow().isoformat(),
            "storage_provider": "postgresql",
            "sync_status": "authoritative_postgresql"
        }

        actual_storage_provider = "postgresql"
        sync_status = "authoritative_postgresql"
        sync_error = ""

        hist_entry = HistoricalAssessment(
            project_id=project_id,
            assessment_id=assessment_id,
            health_score=score_val,
            score_delta=score_delta,
            risk_classification=risk_classification,
            snapshot_data=snapshot_payload,
            summary_of_changes=summary_of_changes,
            new_risks_count=new_risks_count,
            resolved_risks_count=resolved_risks_count,
            storage_provider=actual_storage_provider,
            sync_status=sync_status,
            sync_error=sync_error
        )
        db.add(hist_entry)
        db.commit()
        db.refresh(hist_entry)

        return hist_entry

    async def get_historical_memories(
        self,
        db: Session,
        project_id: str,
        limit: int = 10
    ) -> Dict[str, Any]:
        """
        Retrieve historical memories authoritatively from PostgreSQL.
        Always reports active source.
        """
        local_records = (
            db.query(HistoricalAssessment)
            .filter(HistoricalAssessment.project_id == project_id)
            .order_by(HistoricalAssessment.created_at.desc())
            .limit(limit)
            .all()
        )
        return {
            "storage_provider": "postgresql",
            "remote_sync_status": "authoritative_postgresql",
            "memories": [
                {
                    "id": r.id,
                    "assessment_id": r.assessment_id,
                    "health_score": r.health_score,
                    "score_delta": r.score_delta,
                    "risk_classification": r.risk_classification,
                    "summary_of_changes": r.summary_of_changes,
                    "storage_provider": r.storage_provider or "postgresql",
                    "sync_status": r.sync_status or "authoritative_postgresql",
                    "created_at": r.created_at.isoformat() if r.created_at else None
                }
                for r in local_records
            ]
        }

    async def generate_delta_comparison(
        self,
        db: Session,
        assessment_id: str,
        caller_org_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Compare the given assessment against its immediate predecessor within the same organization.
        Transparently identifies PostgreSQL as the authoritative storage provider.
        """
        query = db.query(Assessment).join(Project).filter(Assessment.id == assessment_id)
        if caller_org_id:
            query = query.filter(Project.org_id == caller_org_id)

        current_assessment = query.first()
        if not current_assessment:
            return {"error": "Assessment not found or unauthorized"}

        # Check historical snapshot record to verify actual storage provenance
        hist_rec = db.query(HistoricalAssessment).filter(HistoricalAssessment.assessment_id == assessment_id).first()
        actual_provider = hist_rec.storage_provider if (hist_rec and hist_rec.storage_provider) else "postgresql"
        actual_sync_status = hist_rec.sync_status if (hist_rec and hist_rec.sync_status) else "authoritative_postgresql"

        # Find prior assessment for the same project
        prior_assessment = (
            db.query(Assessment)
            .filter(
                Assessment.project_id == current_assessment.project_id,
                Assessment.created_at < current_assessment.created_at,
                Assessment.status == "completed"
            )
            .order_by(Assessment.created_at.desc())
            .first()
        )

        curr_scores = {s.technology_id: s for s in current_assessment.scores}
        
        comparison = {
            "current_assessment_id": current_assessment.id,
            "current_date": current_assessment.created_at.strftime("%Y-%m-%d %H:%M"),
            "current_health_score": current_assessment.overall_health_score,
            "current_risk_classification": current_assessment.risk_classification,
            "has_prior_assessment": prior_assessment is not None,
            "prior_health_score": prior_assessment.overall_health_score if prior_assessment else None,
            "score_change": round((current_assessment.overall_health_score or 0) - (prior_assessment.overall_health_score or 0), 1) if prior_assessment else 0.0,
            "storage_provider": actual_provider,
            "remote_sync_status": actual_sync_status,
            "technology_changes": [],
            "new_risks": [],
            "resolved_risks": [],
            "next_steps_recommendation": ""
        }

        if prior_assessment:
            prior_scores = {s.technology_id: s for s in prior_assessment.scores}
            for tech_id, c_score in curr_scores.items():
                p_score = prior_scores.get(tech_id)
                tech_name = c_score.technology.name if c_score.technology else tech_id
                delta = round(c_score.overall_score - p_score.overall_score, 1) if p_score else 0.0
                comparison["technology_changes"].append({
                    "technology_name": tech_name,
                    "previous_score": p_score.overall_score if p_score else None,
                    "current_score": c_score.overall_score,
                    "change": delta,
                    "previous_status": p_score.risk_classification if p_score else "New",
                    "current_status": c_score.risk_classification,
                    "notes": c_score.notes
                })

            curr_risks = db.query(RiskFinding).filter(RiskFinding.assessment_id == current_assessment.id).all()
            prior_risks = db.query(RiskFinding).filter(RiskFinding.assessment_id == prior_assessment.id).all()
            
            p_titles = {r.title: r for r in prior_risks}
            for cr in curr_risks:
                if cr.title not in p_titles:
                    comparison["new_risks"].append({
                        "severity": cr.severity,
                        "title": cr.title,
                        "description": cr.description
                    })
            
            c_titles = {r.title: r for r in curr_risks}
            for pr in prior_risks:
                if pr.title not in c_titles:
                    comparison["resolved_risks"].append({
                        "severity": pr.severity,
                        "title": pr.title
                    })

            if comparison["score_change"] < 0:
                comparison["next_steps_recommendation"] = "Prioritize updating packages that experienced version drift or new deprecation notices. Review the high-priority risk tickets."
            else:
                comparison["next_steps_recommendation"] = "Technology health is steady or improving. Maintain automated weekly scans to catch new vulnerabilities early."
        else:
            comparison["next_steps_recommendation"] = "Initial assessment established as benchmark baseline. Future assessments will track health score trends and regressions."

        return comparison
