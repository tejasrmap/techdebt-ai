"""
Historical Assessment Memory Adapter (formerly Memento Memory Adapter).
Retained for backwards-compatibility.
"""
from app.services.historical_memory_adapter import (
    HistoricalAssessmentMemoryAdapter,
    MementoMemoryAdapter
)

__all__ = ["HistoricalAssessmentMemoryAdapter", "MementoMemoryAdapter"]
