export const app = () => 'ok';
