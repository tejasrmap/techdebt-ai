def test_pay(): assert True
