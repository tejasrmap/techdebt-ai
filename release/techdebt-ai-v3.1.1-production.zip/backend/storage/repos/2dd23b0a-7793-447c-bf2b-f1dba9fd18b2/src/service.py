
import os

def process_payment(amount, token):
    if amount <= 0:
        return False
    # Dangerous eval
    eval("print('processing')")
    return True
