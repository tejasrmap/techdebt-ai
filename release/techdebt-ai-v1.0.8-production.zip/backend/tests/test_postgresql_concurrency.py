"""
TechDebt AI — PostgreSQL Concurrency, Transactional Fencing, and Atomicity Test Suite
Phase 2 PostgreSQL Integration Tests for TechDebt AI v1.0.8

CRITICAL SAFEGUARDS:
1. This test suite executes exclusively against PostgreSQL 15 or newer.
2. Fails explicitly if executed against SQLite or if PostgreSQL is unreachable.
3. Never silently skips PostgreSQL tests.
4. Validates real PostgreSQL row-level locks (SELECT ... FOR UPDATE), transaction isolation,
   lock contention, and atomic commit ordering.
"""
import os
import uuid
import asyncio
import threading
from datetime import datetime, timedelta
from typing import Generator
import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session

from app.models.all_models import (
    Base, Organization, User, Project, Technology, ProjectTechnology,
    Assessment, TechnologyScore, EvidenceSource, RiskFinding,
    HistoricalAssessment, DistributedLock
)
from app.services.scheduler_service import (
    acquire_distributed_lock,
    release_distributed_lock,
    renew_distributed_lock,
    get_lock_generation,
    assert_valid_fenced_lease_transactional,
    verify_ownership_short_transaction,
    StaleGenerationWriteError,
    LockHeartbeat,
    execute_project_review
)
from app.services.historical_memory_adapter import HistoricalAssessmentMemoryAdapter

pytestmark = pytest.mark.postgresql

def get_postgres_test_url() -> str:
    """
    Retrieve PostgreSQL test database URL.
    Enforces Requirement 8 & 9: Fails explicitly if SQLite is configured or no PostgreSQL URL is present.
    """
    url = (
        os.environ.get("POSTGRES_TEST_DATABASE_URL")
        or os.environ.get("TEST_DATABASE_URL")
        or (os.environ.get("DATABASE_URL") if os.environ.get("DATABASE_URL", "").startswith("postgresql") else None)
    )
    if not url or not url.startswith("postgresql"):
        pytest.fail(
            "CRITICAL POSTGRESQL TEST SAFEGUARD: Phase 2 concurrency tests require a live PostgreSQL 15+ "
            "database instance to validate row-level locks and transactional fencing. "
            "Current configuration lacks a valid PostgreSQL URL (POSTGRES_TEST_DATABASE_URL is unset, "
            "local port 5432 is not accepting connections, and Docker daemon is inactive on host). "
            "Failing explicitly to prevent silent SQLite substitution. "
            "Set POSTGRES_TEST_DATABASE_URL=postgresql://user:pass@host:5432/dbname to execute."
        )
    return url

@pytest.fixture(scope="module")
def pg_engine():
    """Create isolated PostgreSQL test engine, verify dialect and version >= 15."""
    url = get_postgres_test_url()
    engine = create_engine(url, pool_pre_ping=True)

    # Verify dialect is PostgreSQL
    dialect_name = engine.dialect.name
    if dialect_name != "postgresql":
        pytest.fail(
            f"CRITICAL TEST SAFEGUARD: Expected 'postgresql' dialect, got '{dialect_name}'. "
            f"Failing explicitly to prevent SQLite substitution."
        )

    # Verify PostgreSQL version >= 15
    with engine.connect() as conn:
        version_num = conn.execute(text("SHOW server_version_num")).scalar()
        version_str = conn.execute(text("SHOW server_version")).scalar()
        if int(version_num) < 150000:
            pytest.fail(
                f"CRITICAL POSTGRESQL TEST SAFEGUARD: TechDebt AI requires PostgreSQL 15 or newer. "
                f"Detected version: {version_str} (server_version_num: {version_num})."
            )

    # Initialize schema in clean disposable test database
    Base.metadata.create_all(bind=engine)
    yield engine
    # Cleanup schema after suite execution
    Base.metadata.drop_all(bind=engine)
    engine.dispose()

@pytest.fixture
def pg_session_factory(pg_engine):
    """SessionFactory bound to isolated PostgreSQL test engine."""
    return sessionmaker(autocommit=False, autoflush=False, bind=pg_engine)


def test_pg_atomic_initial_lock_acquisition(pg_session_factory):
    """
    Test A: Atomic initial lock acquisition against real PostgreSQL.
    Two independent workers attempt to acquire an unowned lock simultaneously.
    Expected: Exactly one succeeds, other receives safe rejection, no duplicate ownership.
    """
    db_w1 = pg_session_factory()
    db_w2 = pg_session_factory()
    lock_key = f"pg_lock_init_{uuid.uuid4().hex[:8]}"
    w1 = "pg_worker_1"
    w2 = "pg_worker_2"

    try:
        results = []
        def acquire_w(db_sess, worker_id):
            res = acquire_distributed_lock(db_sess, lock_key, worker_id, ttl_seconds=60)
            results.append((worker_id, res))

        t1 = threading.Thread(target=acquire_w, args=(db_w1, w1))
        t2 = threading.Thread(target=acquire_w, args=(db_w2, w2))

        t1.start(); t2.start()
        t1.join(); t2.join()

        successes = [wid for wid, res in results if res is True]
        failures = [wid for wid, res in results if res is False]

        assert len(successes) == 1, f"Expected exactly 1 success, got {len(successes)}"
        assert len(failures) == 1, f"Expected exactly 1 failure, got {len(failures)}"

        # Verify PostgreSQL database record has exactly 1 owner and generation = 1
        db_inspect = pg_session_factory()
        lock_rec = db_inspect.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert lock_rec is not None
        assert lock_rec.owner_id == successes[0]
        assert lock_rec.generation == 1
        db_inspect.close()
    finally:
        db_w1.close()
        db_w2.close()


def test_pg_atomic_expired_lock_reclamation(pg_session_factory):
    """
    Test B: Atomic expired-lock reclamation against real PostgreSQL.
    Two independent workers attempt to reclaim the same expired lock.
    Expected: Exactly one succeeds, generation increments exactly once, losing worker rejected.
    """
    db_admin = pg_session_factory()
    db_w1 = pg_session_factory()
    db_w2 = pg_session_factory()
    lock_key = f"pg_lock_expired_{uuid.uuid4().hex[:8]}"

    try:
        # Create an expired lock in PostgreSQL
        past = datetime.utcnow() - timedelta(seconds=60)
        lock_rec = DistributedLock(
            lock_key=lock_key,
            owner_id="initial_dead_worker",
            generation=1,
            acquired_at=past - timedelta(seconds=120),
            expires_at=past
        )
        db_admin.add(lock_rec)
        db_admin.commit()

        results = []
        def reclaim(db_sess, wid):
            res = acquire_distributed_lock(db_sess, lock_key, wid, ttl_seconds=60)
            results.append((wid, res))

        t1 = threading.Thread(target=reclaim, args=(db_w1, "reclaim_worker_a"))
        t2 = threading.Thread(target=reclaim, args=(db_w2, "reclaim_worker_b"))
        t1.start(); t2.start()
        t1.join(); t2.join()

        successes = [wid for wid, res in results if res is True]
        failures = [wid for wid, res in results if res is False]

        assert len(successes) == 1
        assert len(failures) == 1

        db_admin.expire_all()
        updated_lock = db_admin.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()
        assert updated_lock.owner_id == successes[0]
        assert updated_lock.generation == 2
        assert updated_lock.expires_at > datetime.utcnow()
    finally:
        db_admin.close()
        db_w1.close()
        db_w2.close()


def test_pg_heartbeat_renewal_unblocked(pg_session_factory):
    """
    Test C: Heartbeat renewal unblocked during slow operation against real PostgreSQL.
    Worker A holds a lease while performing a controlled slow operation.
    Expected: Heartbeat renewals succeed repeatedly, Worker B cannot acquire active lock,
    no deadlock occurs.
    """
    db_a = pg_session_factory()
    db_b = pg_session_factory()
    lock_key = f"pg_lock_hb_{uuid.uuid4().hex[:8]}"
    worker_a = "pg_worker_heartbeat"

    try:
        acquired = acquire_distributed_lock(db_a, lock_key, worker_a, ttl_seconds=2)
        assert acquired is True
        gen = get_lock_generation(db_a, lock_key, worker_a)

        hb = LockHeartbeat(lock_key, worker_a, interval=0.15, lease_extension=2, generation=gen)
        hb.start()

        import time
        time.sleep(0.6)  # Let heartbeat renew multiple times

        assert hb.is_lock_lost() is False

        # Worker B must be rejected while Worker A holds active renewed lease
        acq_b = acquire_distributed_lock(db_b, lock_key, "competing_worker", ttl_seconds=60)
        assert acq_b is False

        hb.stop()
        release_distributed_lock(db_a, lock_key, worker_a, expected_generation=gen)
    finally:
        if 'hb' in locals() and hb:
            hb.stop()
        db_a.close()
        db_b.close()


def test_pg_worker_ownership_protection(pg_session_factory):
    """
    Test D: Worker ownership protection against real PostgreSQL.
    Worker A must not renew Worker B's lock, release Worker B's lock, or persist with older generation.
    """
    db_a = pg_session_factory()
    db_b = pg_session_factory()
    lock_key = f"pg_lock_prot_{uuid.uuid4().hex[:8]}"

    try:
        acquire_distributed_lock(db_b, lock_key, "worker_legitimate", ttl_seconds=60)
        gen = get_lock_generation(db_b, lock_key, "worker_legitimate")
        assert gen == 1

        # Worker A tries to renew Worker B's lock -> must fail
        renew_res = renew_distributed_lock(db_a, lock_key, "worker_imposter", extension_seconds=60)
        assert renew_res is False

        # Worker A tries to release Worker B's lock -> must fail
        rel_res = release_distributed_lock(db_a, lock_key, "worker_imposter")
        assert rel_res is False

        # Worker A tries to validate fenced lease with stale generation -> must raise StaleGenerationWriteError
        with pytest.raises(StaleGenerationWriteError):
            assert_valid_fenced_lease_transactional(db_a, lock_key, "worker_legitimate", expected_generation=999)
    finally:
        db_a.close()
        db_b.close()


def test_pg_genuine_mid_execution_lock_loss(pg_session_factory):
    """
    Test E: Genuine mid-execution lock loss against real PostgreSQL.
    Worker A acquires generation 1, pauses at controlled point, lease expires,
    Worker B acquires generation 2, Worker A resumes, PostgreSQL rejects stale write,
    Worker A aborts cleanly, Worker B completes successfully.
    """
    db_admin = pg_session_factory()
    lock_key = f"pg_lock_mid_{uuid.uuid4().hex[:8]}"
    worker_a = "pg_worker_mid_a"
    worker_b = "pg_worker_mid_b"

    try:
        org = Organization(name="PG Test Org " + uuid.uuid4().hex[:6], slug="pg-org-" + uuid.uuid4().hex[:6])
        db_admin.add(org); db_admin.commit(); db_admin.refresh(org)

        proj = Project(org_id=org.id, name="PG Fencing Proj", description="Testing PG fencing")
        db_admin.add(proj); db_admin.commit(); db_admin.refresh(proj)

        tech = Technology(name="pg-test-pkg", ecosystem="npm", latest_stable_version="1.0.0")
        db_admin.add(tech); db_admin.commit(); db_admin.refresh(tech)

        p_tech = ProjectTechnology(project_id=proj.id, technology_id=tech.id, installed_version="1.0.0")
        db_admin.add(p_tech); db_admin.commit()

        # Step 1: Worker A acquires generation 1
        acquire_distributed_lock(db_admin, lock_key, worker_a, ttl_seconds=6)
        gen_a = get_lock_generation(db_admin, lock_key, worker_a)
        assert gen_a == 1

        worker_a_paused = threading.Event()
        worker_a_resume = threading.Event()
        worker_a_error = []
        worker_a_finished = threading.Event()

        def stage_hook(stage_name: str):
            if stage_name == "8_before_assessment_persistence":
                worker_a_paused.set()
                worker_a_resume.wait(timeout=10)

        def worker_a_run():
            thread_db = pg_session_factory()
            try:
                asyncio.run(execute_project_review(
                    project_id=proj.id,
                    trigger_type="scheduled",
                    db_session=thread_db,
                    fencing_key=lock_key,
                    fencing_owner=worker_a,
                    fencing_generation=gen_a,
                    stage_hook=stage_hook
                ))
            except Exception as e:
                worker_a_error.append(e)
            finally:
                thread_db.close()
                worker_a_finished.set()

        th_a = threading.Thread(target=worker_a_run, daemon=True)
        th_a.start()

        assert worker_a_paused.wait(timeout=6)

        # Force lease expiration
        past = datetime.utcnow() - timedelta(seconds=120)
        db_admin.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).update({"expires_at": past})
        db_admin.commit()

        # Worker B reclaims lock with generation 2 and completes assessment
        db_b = pg_session_factory()
        try:
            acq_b = acquire_distributed_lock(db_b, lock_key, worker_b, ttl_seconds=60)
            assert acq_b is True
            gen_b = get_lock_generation(db_b, lock_key, worker_b)
            assert gen_b == 2

            res_b = asyncio.run(execute_project_review(
                project_id=proj.id,
                trigger_type="scheduled",
                db_session=db_b,
                fencing_key=lock_key,
                fencing_owner=worker_b,
                fencing_generation=gen_b
            ))
            assert res_b.status == "completed"
            assert res_b.fencing_generation == 2
        finally:
            db_b.close()

        # Resume Worker A -> must fail with StaleGenerationWriteError
        worker_a_resume.set()
        assert worker_a_finished.wait(timeout=6)

        assert len(worker_a_error) == 1
        assert isinstance(worker_a_error[0], StaleGenerationWriteError) or "superseded" in str(worker_a_error[0]).lower()

        # Invariant checks in PostgreSQL:
        db_admin.expire_all()
        assessments = db_admin.query(Assessment).filter(Assessment.project_id == proj.id, Assessment.status == "completed").all()
        assert len(assessments) == 1
        assert assessments[0].fencing_generation == 2

        snapshots = db_admin.query(HistoricalAssessment).filter(HistoricalAssessment.project_id == proj.id).all()
        assert len(snapshots) == 1
        assert snapshots[0].fencing_generation == 2
    finally:
        db_admin.close()


def test_pg_final_persistence_atomicity(pg_session_factory):
    """
    Test F: Final persistence atomicity against real PostgreSQL.
    Verifies that Assessment, TechnologyScore, EvidenceSource, RiskFinding, Project timestamp,
    and HistoricalAssessment snapshot commit together atomically in one transaction.
    """
    db_a = pg_session_factory()
    db_inspect = pg_session_factory()
    lock_key = f"pg_lock_atom_{uuid.uuid4().hex[:8]}"

    try:
        org = Organization(name="Atom Org " + uuid.uuid4().hex[:6], slug="atom-org-" + uuid.uuid4().hex[:6])
        db_a.add(org); db_a.commit(); db_a.refresh(org)

        proj = Project(org_id=org.id, name="Atom Proj")
        db_a.add(proj); db_a.commit(); db_a.refresh(proj)

        tech = Technology(name="atom-pkg", ecosystem="npm", latest_stable_version="2.0.0")
        db_a.add(tech); db_a.commit(); db_a.refresh(tech)

        acquire_distributed_lock(db_a, lock_key, "atom_worker", ttl_seconds=60)
        gen = get_lock_generation(db_a, lock_key, "atom_worker")

        assessment = Assessment(project_id=proj.id, status="processing", fencing_generation=gen)
        db_a.add(assessment); db_a.commit(); db_a.refresh(assessment)
        assessment_id = assessment.id

        # Acquire PostgreSQL row lock
        assert_valid_fenced_lease_transactional(db_a, lock_key, "atom_worker", gen)

        # Stage updates and additions
        db_a.query(Assessment).filter(Assessment.id == assessment_id).update({
            "status": "completed",
            "overall_health_score": 90.0,
            "risk_classification": "Good"
        }, synchronize_session=False)

        db_a.add(TechnologyScore(assessment_id=assessment_id, technology_id=tech.id, overall_score=90.0))
        db_a.add(RiskFinding(assessment_id=assessment_id, technology_id=tech.id, project_id=proj.id, title="Atom Risk"))
        db_a.query(Project).filter(Project.id == proj.id).update({"last_assessment_date": datetime.utcnow()})

        # Non-committing ownership verification
        verify_ownership_short_transaction(db_a, lock_key, "atom_worker", gen)

        # Verify not yet visible in inspection session
        db_inspect.expire_all()
        assert len(db_inspect.query(TechnologyScore).filter(TechnologyScore.assessment_id == assessment_id).all()) == 0

        # Stage historical snapshot
        adapter = HistoricalAssessmentMemoryAdapter()
        asyncio.run(adapter.record_assessment_snapshot(
            db=db_a, project_id=proj.id, assessment_id=assessment_id, overall_score=90.0,
            risk_classification="Good", tech_scores=[], identified_risks=[], project_name=proj.name,
            fencing_generation=gen, auto_commit=False
        ))

        # Commit all atomically
        db_a.commit()

        # Now all exist together in PostgreSQL
        db_inspect.expire_all()
        assert db_inspect.query(Assessment).filter(Assessment.id == assessment_id).first().status == "completed"
        assert len(db_inspect.query(TechnologyScore).filter(TechnologyScore.assessment_id == assessment_id).all()) == 1
        assert len(db_inspect.query(RiskFinding).filter(RiskFinding.assessment_id == assessment_id).all()) == 1
        assert len(db_inspect.query(HistoricalAssessment).filter(HistoricalAssessment.assessment_id == assessment_id).all()) == 1
    finally:
        db_a.close()
        db_inspect.close()


def test_pg_premature_commit_regression(pg_session_factory):
    """
    Test G: Premature commit regression against real PostgreSQL.
    Verify that verify_ownership_short_transaction() never commits caller session.
    """
    db = pg_session_factory()
    db_check = pg_session_factory()
    lock_key = f"pg_premature_{uuid.uuid4().hex[:8]}"

    try:
        acquire_distributed_lock(db, lock_key, "test_worker", ttl_seconds=60)
        gen = get_lock_generation(db, lock_key, "test_worker")

        org = Organization(name="Premature Org " + uuid.uuid4().hex[:6], slug="premature-" + uuid.uuid4().hex[:6])
        db.add(org); db.commit(); db.refresh(org)

        proj = Project(org_id=org.id, name="Uncommitted Proj")
        db.add(proj)  # Added but NOT committed!

        # Call ownership verification
        verify_ownership_short_transaction(db, lock_key, "test_worker", gen)

        # In separate session, uncommitted project MUST NOT exist!
        db_check.expire_all()
        found = db_check.query(Project).filter(Project.name == "Uncommitted Proj").first()
        assert found is None, "Premature commit defect: Object was flushed/committed during verification!"

        # Rollback discards uncommitted project
        db.rollback()
        db.expire_all()
        assert db.query(Project).filter(Project.name == "Uncommitted Proj").first() is None
    finally:
        db.close()
        db_check.close()


def test_pg_concurrent_transaction_behavior(pg_session_factory):
    """
    Test H: Concurrent transaction behavior and row locking in real PostgreSQL.
    Validates SELECT ... FOR UPDATE blocks competing transactions until commit,
    verifying strict commit ordering and wait behavior.
    """
    db_lock_holder = pg_session_factory()
    db_competitor = pg_session_factory()
    lock_key = f"pg_row_lock_{uuid.uuid4().hex[:8]}"

    try:
        acquire_distributed_lock(db_lock_holder, lock_key, "holder", ttl_seconds=60)
        gen = get_lock_generation(db_lock_holder, lock_key, "holder")

        # Session 1 acquires row lock via SELECT ... FOR UPDATE
        assert_valid_fenced_lease_transactional(db_lock_holder, lock_key, "holder", gen)

        blocked_competitor = threading.Event()
        competitor_finished = threading.Event()
        competitor_lock_held_during_wait = []

        def competitor_attempt():
            thread_db = pg_session_factory()
            try:
                blocked_competitor.set()
                # SELECT ... FOR UPDATE in PostgreSQL blocks until db_lock_holder commits or rolls back
                thread_db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).with_for_update().first()
                competitor_lock_held_during_wait.append(True)
                thread_db.commit()
            except Exception:
                competitor_lock_held_during_wait.append(False)
            finally:
                thread_db.close()
                competitor_finished.set()

        th = threading.Thread(target=competitor_attempt, daemon=True)
        th.start()

        assert blocked_competitor.wait(timeout=2)
        import time
        time.sleep(0.3)

        # While db_lock_holder's transaction is open, competitor must be blocked!
        assert len(competitor_lock_held_during_wait) == 0, "Competitor should be blocked on row lock!"

        # Release row lock by committing
        db_lock_holder.commit()

        # Competitor unblocks and finishes
        assert competitor_finished.wait(timeout=3)
        assert len(competitor_lock_held_during_wait) == 1
        assert competitor_lock_held_during_wait[0] is True
    finally:
        db_lock_holder.close()
        db_competitor.close()
