import os
import sys
from typing import Optional, List
from pydantic import BaseModel, field_validator

DEFAULT_DEV_SECRET = "techdebt-ai-super-secret-development-key-2025-jwt"
PROHIBITED_SECRET_DEFAULTS = {
    DEFAULT_DEV_SECRET,
    "techdebt-ai-production-super-secret-key-jwt-2025",
    "techdebt-ai-fernet-encryption-key-prod-2025",
    "changeme",
    "secret",
    "password",
    "admin",
    "12345678"
}

class Settings(BaseModel):
    PROJECT_NAME: str = "TechDebt AI"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: str = "development"

    # JWT Security
    SECRET_KEY: str = DEFAULT_DEV_SECRET
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

    # Database
    DATABASE_URL: str = "sqlite:///./techdebt.db"

    # AI Providers
    OPENAI_API_KEY: Optional[str] = ""
    GEMINI_API_KEY: Optional[str] = ""
    DEFAULT_AI_PROVIDER: str = "gemini"
    AI_MODEL_NAME: str = "gemini-1.5-flash"
    AI_TEMPERATURE: float = 0.2

    # Intelligence & Memory
    FIRECRAWL_API_KEY: Optional[str] = ""
    FIRECRAWL_API_URL: str = "https://api.firecrawl.dev/v1"
    MEMENTO_API_KEY: Optional[str] = ""
    MEMENTO_API_URL: str = "https://api.memento.ai/v1"

    # Security & Upload Validation
    MAX_UPLOAD_SIZE_BYTES: int = 2 * 1024 * 1024  # 2 MB max
    ENABLE_DEMO_SEED: bool = True
    ENCRYPTION_KEY: Optional[str] = ""
    ALLOW_PLATFORM_INTEGRATION_FALLBACK: bool = False

    # CORS Origins
    CORS_ORIGINS: List[str] = []

    def __init__(self, **values):
        values.setdefault("ENVIRONMENT", os.getenv("ENVIRONMENT", "development").lower())
        values.setdefault("SECRET_KEY", os.getenv("SECRET_KEY", DEFAULT_DEV_SECRET))
        values.setdefault("DATABASE_URL", os.getenv("DATABASE_URL", "sqlite:///./techdebt.db"))
        values.setdefault("ENCRYPTION_KEY", os.getenv("ENCRYPTION_KEY", ""))
        values.setdefault("OPENAI_API_KEY", os.getenv("OPENAI_API_KEY", ""))
        values.setdefault("GEMINI_API_KEY", os.getenv("GEMINI_API_KEY", ""))
        values.setdefault("DEFAULT_AI_PROVIDER", os.getenv("DEFAULT_AI_PROVIDER", "gemini"))
        values.setdefault("AI_MODEL_NAME", os.getenv("AI_MODEL_NAME", "gemini-1.5-flash"))
        values.setdefault("AI_TEMPERATURE", float(os.getenv("AI_TEMPERATURE", "0.2")))
        values.setdefault("FIRECRAWL_API_KEY", os.getenv("FIRECRAWL_API_KEY", ""))
        values.setdefault("FIRECRAWL_API_URL", os.getenv("FIRECRAWL_API_URL", "https://api.firecrawl.dev/v1"))
        values.setdefault("MEMENTO_API_KEY", os.getenv("MEMENTO_API_KEY", ""))
        values.setdefault("MEMENTO_API_URL", os.getenv("MEMENTO_API_URL", "https://api.memento.ai/v1"))
        values.setdefault("ENABLE_DEMO_SEED", os.getenv("ENABLE_DEMO_SEED", "true").lower() == "true")
        values.setdefault("ALLOW_PLATFORM_INTEGRATION_FALLBACK", os.getenv("ALLOW_PLATFORM_INTEGRATION_FALLBACK", "false").lower() == "true")
        values.setdefault("ACCESS_TOKEN_EXPIRE_MINUTES", int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440")))

        super().__init__(**values)
        raw_origins = os.getenv("CORS_ORIGINS", "")
        if raw_origins:
            self.CORS_ORIGINS = [o.strip() for o in raw_origins.split(",") if o.strip()]
        else:
            if self.ENVIRONMENT == "production":
                # In production, require explicit origins or default to localhost domain without wildcard
                self.CORS_ORIGINS = ["http://localhost", "https://localhost"]
            else:
                self.CORS_ORIGINS = [
                    "http://localhost:5173",
                    "http://127.0.0.1:5173",
                    "http://localhost:3000",
                    "http://localhost:8000"
                ]

        # Enforce strong secret key and encryption key in production
        if self.ENVIRONMENT == "production":
            # 1. Validate SECRET_KEY
            if not self.SECRET_KEY or self.SECRET_KEY in PROHIBITED_SECRET_DEFAULTS or len(self.SECRET_KEY) < 32:
                raise ValueError(
                    "FATAL SECURITY VIOLATION: In production, SECRET_KEY must be set via environment variable, "
                    "must be at least 32 characters long, and must not match any known default values."
                )

            # 2. Validate ENCRYPTION_KEY
            if not self.ENCRYPTION_KEY or self.ENCRYPTION_KEY in PROHIBITED_SECRET_DEFAULTS or len(self.ENCRYPTION_KEY) < 16:
                raise ValueError(
                    "FATAL SECURITY VIOLATION: In production, ENCRYPTION_KEY must be explicitly set via environment variable, "
                    "must be at least 16 characters long, and must not match known default values."
                )

            # 3. Reject known default database credentials in production
            if "postgrespassword" in self.DATABASE_URL or ":password@" in self.DATABASE_URL:
                raise ValueError(
                    "FATAL SECURITY VIOLATION: In production, DATABASE_URL must not use default or trivial passwords."
                )

settings = Settings()
