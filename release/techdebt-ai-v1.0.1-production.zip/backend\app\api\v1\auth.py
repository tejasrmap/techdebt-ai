from datetime import datetime, timedelta
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.all_models import User, Organization, OrganizationInvitation, AuditLog
from app.schemas.schemas import (
    UserRegister, UserLogin, TokenResponse, UserResponse,
    InvitationCreate, InvitationResponse, InvitationAccept
)
from app.services.auth_service import (
    verify_password, get_password_hash, create_access_token,
    get_current_user, revoke_token, oauth2_scheme,
    require_roles, generate_invitation_token, hash_invitation_token,
    cleanup_expired_revoked_tokens
)
from app.services.rate_limiter import rate_limit_auth

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/register", response_model=TokenResponse)
def register(req: UserRegister, request: Request, db: Session = Depends(get_db)):
    rate_limit_auth(request)
    
    # 1. Check if user already exists
    existing_user = db.query(User).filter(User.email == req.email.lower()).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A user with this email address is already registered."
        )

    # 2. Fix public organization registration: Prevent unauthorized organization joining!
    # Enforce strictly unique organization creation. Existing orgs can only be joined via invitation.
    org_name_clean = req.organization_name.strip()
    slug = org_name_clean.lower().replace(" ", "-")[:40]
    
    existing_org = db.query(Organization).filter(
        (Organization.name.ilike(org_name_clean)) | (Organization.slug == slug)
    ).first()
    
    if existing_org:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An organization with this name already exists. Please choose a distinct name or ask your organization administrator for an invitation."
        )

    org = Organization(name=org_name_clean, slug=slug, plan="enterprise")
    db.add(org)
    db.commit()
    db.refresh(org)

    # 3. Security: Creator of an organization is ALWAYS an Administrator. No public role selection.
    user = User(
        email=req.email.lower(),
        hashed_password=get_password_hash(req.password),
        full_name=req.full_name.strip(),
        org_id=org.id,
        role="Administrator"
    )
    db.add(user)
    
    audit = AuditLog(
        user_id=None,
        org_id=org.id,
        action="auth.organization_registered",
        resource_type="organization",
        resource_id=org.id,
        details={"org_name": org.name, "admin_email": user.email}
    )
    db.add(audit)
    db.commit()
    db.refresh(user)

    token = create_access_token(data={"sub": user.id, "email": user.email, "org_id": org.id})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "org_id": user.org_id,
            "organization_name": org.name,
            "created_at": user.created_at
        }
    }

@router.post("/login", response_model=TokenResponse)
def login(req: UserLogin, request: Request, db: Session = Depends(get_db)):
    rate_limit_auth(request)
    user = db.query(User).filter(User.email == req.email.lower()).first()
    if not user or not verify_password(req.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password."
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is deactivated. Contact organization administrator."
        )

    # Log successful login in audit log
    audit = AuditLog(
        user_id=user.id,
        org_id=user.org_id,
        action="auth.login",
        resource_type="user",
        resource_id=user.id,
        details={"ip": request.client.host if request.client else "unknown"}
    )
    db.add(audit)
    db.commit()

    token = create_access_token(data={"sub": user.id, "email": user.email, "org_id": user.org_id})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "org_id": user.org_id,
            "organization_name": user.organization.name if user.organization else "",
            "created_at": user.created_at
        }
    }

@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    return {
        "id": current_user.id,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "role": current_user.role,
        "org_id": current_user.org_id,
        "organization_name": current_user.organization.name if current_user.organization else "",
        "created_at": current_user.created_at
    }

@router.post("/logout")
def logout(
    token: str = Depends(oauth2_scheme),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Properly revoke the session token
    revoke_token(token, db)
    cleanup_expired_revoked_tokens(db)
    audit = AuditLog(
        user_id=current_user.id,
        org_id=current_user.org_id,
        action="auth.logout",
        resource_type="user",
        resource_id=current_user.id,
        details={}
    )
    db.add(audit)
    db.commit()
    return {"message": "Successfully logged out. Session revoked."}

# --- Secure Invitation-Based Organization Membership ---

ALLOWED_INVITATION_ROLES = {"Administrator", "Engineering Manager", "Developer", "Viewer"}

@router.post("/invitations", response_model=InvitationResponse, status_code=status.HTTP_201_CREATED)
def create_invitation(
    req: InvitationCreate,
    current_user: User = Depends(require_roles(["Administrator", "Engineering Manager"])),
    db: Session = Depends(get_db)
):
    """
    Administrator or Engineering Manager invites a new member into the organization.
    Enforces strict role validation and prevents privilege escalation:
    - Only Administrators may invite Administrator or Engineering Manager accounts.
    - Engineering Managers may only invite Developers and Viewers.
    - Invitation tokens are hashed at rest using SHA-256.
    """
    if req.role not in ALLOWED_INVITATION_ROLES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid invitation role '{req.role}'. Allowed roles: {', '.join(sorted(ALLOWED_INVITATION_ROLES))}"
        )

    # Privilege Escalation Guard
    if current_user.role == "Engineering Manager":
        if req.role in ["Administrator", "Engineering Manager"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Privilege escalation prohibited: Engineering Managers are only permitted to invite Developer and Viewer accounts."
            )
    elif current_user.role != "Administrator":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only Administrators and Engineering Managers can issue invitations."
        )

    # Check if user already exists
    existing_user = db.query(User).filter(User.email == req.email.lower()).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A user with this email address already has an account."
        )

    # Check pending active invitation
    existing_invite = db.query(OrganizationInvitation).filter(
        OrganizationInvitation.org_id == current_user.org_id,
        OrganizationInvitation.email == req.email.lower(),
        OrganizationInvitation.is_accepted == False,
        OrganizationInvitation.expires_at > datetime.utcnow()
    ).first()
    
    if existing_invite:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An active invitation has already been issued to this email address."
        )

    raw_token = generate_invitation_token()
    token_hash = hash_invitation_token(raw_token)

    invite = OrganizationInvitation(
        org_id=current_user.org_id,
        email=req.email.lower(),
        role=req.role,
        token=raw_token[:10] + "...",  # Store masked preview only
        token_hash=token_hash,
        expires_at=datetime.utcnow() + timedelta(days=7),
        invited_by_id=current_user.id
    )
    db.add(invite)
    
    audit = AuditLog(
        user_id=current_user.id,
        org_id=current_user.org_id,
        action="organization.invitation_created",
        resource_type="invitation",
        resource_id=invite.id,
        details={"invited_email": req.email.lower(), "role": req.role}
    )
    db.add(audit)
    db.commit()
    db.refresh(invite)

    invitation_url = f"/register?invite={raw_token}"
    return InvitationResponse(
        id=invite.id,
        org_id=invite.org_id,
        email=invite.email,
        role=invite.role,
        token=raw_token,
        invitation_url=invitation_url,
        expires_at=invite.expires_at,
        is_accepted=invite.is_accepted,
        created_at=invite.created_at
    )

@router.get("/invitations", response_model=List[InvitationResponse])
def list_invitations(
    current_user: User = Depends(require_roles(["Administrator", "Engineering Manager"])),
    db: Session = Depends(get_db)
):
    """List pending invitations for the caller's organization."""
    invites = db.query(OrganizationInvitation).filter(
        OrganizationInvitation.org_id == current_user.org_id,
        OrganizationInvitation.is_accepted == False,
        OrganizationInvitation.expires_at > datetime.utcnow()
    ).order_by(OrganizationInvitation.created_at.desc()).all()
    
    return [
        InvitationResponse(
            id=i.id,
            org_id=i.org_id,
            email=i.email,
            role=i.role,
            token=i.token or "masked_token",
            invitation_url=f"/register?invite={i.token or ''}",
            expires_at=i.expires_at,
            is_accepted=i.is_accepted,
            created_at=i.created_at
        )
        for i in invites
    ]

@router.delete("/invitations/{invitation_id}", status_code=status.HTTP_204_NO_CONTENT)
def revoke_invitation(
    invitation_id: str,
    current_user: User = Depends(require_roles(["Administrator", "Engineering Manager"])),
    db: Session = Depends(get_db)
):
    """Revoke a pending invitation."""
    invite = db.query(OrganizationInvitation).filter(
        OrganizationInvitation.id == invitation_id,
        OrganizationInvitation.org_id == current_user.org_id
    ).first()
    if not invite:
        raise HTTPException(status_code=404, detail="Invitation not found")
    
    db.delete(invite)
    db.commit()
    return None

@router.post("/accept-invitation", response_model=TokenResponse)
def accept_invitation(
    req: InvitationAccept,
    request: Request,
    db: Session = Depends(get_db)
):
    """Accept an organization invitation and complete account registration."""
    rate_limit_auth(request)
    
    token_str = req.token.strip()
    tok_hash = hash_invitation_token(token_str)

    invite = db.query(OrganizationInvitation).filter(
        (OrganizationInvitation.token_hash == tok_hash) | (OrganizationInvitation.token == token_str),
        OrganizationInvitation.is_accepted == False
    ).first()
    
    if not invite:
        raise HTTPException(status_code=400, detail="Invalid, expired, or already accepted invitation token.")

    if invite.expires_at < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Invitation token has expired. Request a new invitation.")

    # Check if email is now taken
    if db.query(User).filter(User.email == invite.email).first():
        raise HTTPException(status_code=400, detail="An account with this email already exists.")

    user = User(
        org_id=invite.org_id,
        email=invite.email,
        full_name=req.full_name.strip(),
        hashed_password=get_password_hash(req.password),
        role=invite.role
    )
    db.add(user)
    
    # Mark invitation single-use consumed
    invite.is_accepted = True
    invite.accepted_at = datetime.utcnow()

    audit = AuditLog(
        user_id=None,
        org_id=invite.org_id,
        action="organization.invitation_accepted",
        resource_type="user",
        resource_id=user.id,
        details={"email": invite.email, "role": invite.role}
    )
    db.add(audit)
    db.commit()
    db.refresh(user)

    token = create_access_token(data={"sub": user.id, "email": user.email, "org_id": user.org_id})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "org_id": user.org_id,
            "organization_name": user.organization.name if user.organization else "",
            "created_at": user.created_at
        }
    }
