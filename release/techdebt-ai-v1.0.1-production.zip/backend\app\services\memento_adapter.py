import os
import logging
import httpx
from datetime import datetime
from typing import Dict, Any, List, Optional
from sqlalchemy.orm import Session
from app.config import settings
from app.models.all_models import HistoricalAssessment, Assessment, TechnologyScore, RiskFinding, Project

logger = logging.getLogger(__name__)

class MementoMemoryAdapter:
    """
    Adapter layer for Memento historical memory context.
    If the remote Memento API is verified and accessible, it syncs memory snapshots.
    Otherwise, it reliably persists to the local PostgreSQL/SQLite database fallback.
    The active mode and synchronization status are always transparently and truthfully reported.
    Never claims cloud success if a remote write fails.
    """
    def __init__(self, api_key: Optional[str] = None, endpoint: Optional[str] = None):
        self.api_key = api_key if api_key is not None else settings.MEMENTO_API_KEY
        self.endpoint = (endpoint or settings.MEMENTO_API_URL).rstrip("/")
        self.is_configured = bool(self.api_key and len(self.api_key.strip()) > 5)
        self.mode = "memento_cloud" if self.is_configured else "postgresql_fallback"

    async def verify_connectivity(self) -> Dict[str, Any]:
        """Verify actual remote Memento API connectivity with real HTTP probe."""
        if not self.is_configured:
            return {
                "status": "local_fallback_active",
                "mode": "postgresql_fallback",
                "connected": False,
                "message": "Memento API key not configured for this organization. Operating in local PostgreSQL fallback mode."
            }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        try:
            async with httpx.AsyncClient(timeout=8.0) as client:
                resp = await client.get(f"{self.endpoint}/health", headers=headers)
                if resp.status_code in [200, 204]:
                    return {
                        "status": "connected",
                        "mode": "memento_cloud",
                        "connected": True,
                        "message": "Memento Cloud memory integration verified successfully."
                    }
                elif resp.status_code in [401, 403]:
                    return {
                        "status": "auth_failed",
                        "mode": "postgresql_fallback",
                        "connected": False,
                        "message": "Invalid Memento API key or authentication rejected."
                    }
                else:
                    return {
                        "status": "unreachable",
                        "mode": "postgresql_fallback",
                        "connected": False,
                        "message": f"Memento endpoint returned HTTP {resp.status_code}."
                    }
        except Exception as e:
            logger.warning(f"Memento connectivity verification failed: {e}")
            return {
                "status": "connection_error",
                "mode": "postgresql_fallback",
                "connected": False,
                "message": f"Could not reach Memento endpoint: {str(e)}"
            }

    async def record_assessment_snapshot(
        self,
        db: Session,
        project_id: str,
        assessment_id: str,
        overall_score: Optional[float],
        risk_classification: str,
        tech_scores: List[Dict[str, Any]],
        identified_risks: List[Dict[str, Any]],
        project_name: str = ""
    ) -> HistoricalAssessment:
        """
        Record assessment snapshot in historical memory and calculate delta from previous assessment.
        Attempts remote sync to Memento Cloud if configured; accurately records sync_status.
        """
        # Find previous assessment for this project
        prev_record = (
            db.query(HistoricalAssessment)
            .filter(HistoricalAssessment.project_id == project_id)
            .order_by(HistoricalAssessment.created_at.desc())
            .first()
        )

        score_delta = 0.0
        summary_of_changes = "Initial baseline assessment recorded."
        new_risks_count = len(identified_risks)
        resolved_risks_count = 0

        score_val = overall_score if overall_score is not None else 0.0

        if prev_record:
            prev_val = prev_record.health_score if prev_record.health_score is not None else 0.0
            score_delta = round(score_val - prev_val, 1)
            prev_snapshot = prev_record.snapshot_data or {}
            prev_risk_titles = {r.get("title") for r in prev_snapshot.get("risks", [])}
            curr_risk_titles = {r.get("title") for r in identified_risks}

            new_risks = curr_risk_titles - prev_risk_titles
            resolved_risks = prev_risk_titles - curr_risk_titles
            new_risks_count = len(new_risks)
            resolved_risks_count = len(resolved_risks)

            if score_delta > 0:
                summary_of_changes = f"Health score improved by +{score_delta} points. {resolved_risks_count} previously active risk(s) resolved."
            elif score_delta < 0:
                summary_of_changes = f"Health score declined by {score_delta} points. {new_risks_count} new risk(s) identified (e.g. {', '.join(list(new_risks)[:2]) if new_risks else 'version drift'})."
            else:
                summary_of_changes = "Health score remained stable compared to the previous assessment."

        snapshot_payload = {
            "project_id": project_id,
            "project_name": project_name,
            "overall_health_score": overall_score,
            "risk_classification": risk_classification,
            "technology_scores": tech_scores,
            "risks": identified_risks,
            "recorded_at": datetime.utcnow().isoformat()
        }

        # Determine cloud sync vs PostgreSQL fallback
        actual_storage_provider = "postgresql"
        sync_status = "local_postgresql_only"
        sync_error = ""

        if self.is_configured:
            cloud_success, cloud_err = await self._push_to_memento_api_with_retry(snapshot_payload)
            if cloud_success:
                actual_storage_provider = "memento_cloud"
                sync_status = "synced_to_memento_cloud"
            else:
                actual_storage_provider = "postgresql"
                sync_status = "sync_failed_fallback_postgresql"
                sync_error = cloud_err or "Failed to synchronize snapshot to Memento Cloud API."
                logger.warning(f"Memento cloud sync failed for project {project_id}: {sync_error}")

        snapshot_payload["storage_provider"] = actual_storage_provider
        snapshot_payload["sync_status"] = sync_status

        hist_entry = HistoricalAssessment(
            project_id=project_id,
            assessment_id=assessment_id,
            health_score=score_val,
            score_delta=score_delta,
            risk_classification=risk_classification,
            snapshot_data=snapshot_payload,
            summary_of_changes=summary_of_changes,
            new_risks_count=new_risks_count,
            resolved_risks_count=resolved_risks_count,
            storage_provider=actual_storage_provider,
            sync_status=sync_status,
            sync_error=sync_error
        )
        db.add(hist_entry)
        db.commit()
        db.refresh(hist_entry)

        return hist_entry

    async def get_historical_memories(
        self,
        db: Session,
        project_id: str,
        limit: int = 10
    ) -> Dict[str, Any]:
        """
        Retrieve historical memories.
        Attempts Memento Cloud retrieval first if configured; falls back to PostgreSQL.
        Always reports active source.
        """
        if self.is_configured:
            try:
                headers = {"Authorization": f"Bearer {self.api_key}"}
                async with httpx.AsyncClient(timeout=6.0) as client:
                    resp = await client.get(
                        f"{self.endpoint}/memories?project_id={project_id}&limit={limit}",
                        headers=headers
                    )
                    if resp.status_code == 200:
                        data = resp.json()
                        return {
                            "storage_provider": "memento_cloud",
                            "remote_sync_status": "synced",
                            "memories": data.get("memories", data.get("data", []))
                        }
            except Exception as e:
                logger.warning(f"Remote Memento memory retrieval failed: {e}. Falling back to PostgreSQL.")

        # Relational fallback
        local_records = (
            db.query(HistoricalAssessment)
            .filter(HistoricalAssessment.project_id == project_id)
            .order_by(HistoricalAssessment.created_at.desc())
            .limit(limit)
            .all()
        )
        return {
            "storage_provider": "postgresql",
            "remote_sync_status": "local_fallback",
            "memories": [
                {
                    "id": r.id,
                    "assessment_id": r.assessment_id,
                    "health_score": r.health_score,
                    "score_delta": r.score_delta,
                    "risk_classification": r.risk_classification,
                    "summary_of_changes": r.summary_of_changes,
                    "storage_provider": r.storage_provider or "postgresql",
                    "sync_status": r.sync_status or "local_postgresql_only",
                    "created_at": r.created_at.isoformat() if r.created_at else None
                }
                for r in local_records
            ]
        }

    async def generate_delta_comparison(
        self,
        db: Session,
        assessment_id: str,
        caller_org_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Compare the given assessment against its immediate predecessor within the same organization.
        Transparently identifies whether storage was Memento Cloud or PostgreSQL.
        """
        query = db.query(Assessment).join(Project).filter(Assessment.id == assessment_id)
        if caller_org_id:
            query = query.filter(Project.org_id == caller_org_id)

        current_assessment = query.first()
        if not current_assessment:
            return {"error": "Assessment not found or unauthorized"}

        # Check historical snapshot record to verify actual storage provenance
        hist_rec = db.query(HistoricalAssessment).filter(HistoricalAssessment.assessment_id == assessment_id).first()
        actual_provider = hist_rec.storage_provider if (hist_rec and hist_rec.storage_provider) else "postgresql"
        actual_sync_status = hist_rec.sync_status if (hist_rec and hist_rec.sync_status) else "local_postgresql_only"

        # Find prior assessment for the same project
        prior_assessment = (
            db.query(Assessment)
            .filter(
                Assessment.project_id == current_assessment.project_id,
                Assessment.created_at < current_assessment.created_at,
                Assessment.status == "completed"
            )
            .order_by(Assessment.created_at.desc())
            .first()
        )

        curr_scores = {s.technology_id: s for s in current_assessment.scores}
        
        comparison = {
            "current_assessment_id": current_assessment.id,
            "current_date": current_assessment.created_at.strftime("%Y-%m-%d %H:%M"),
            "current_health_score": current_assessment.overall_health_score,
            "current_risk_classification": current_assessment.risk_classification,
            "has_prior_assessment": prior_assessment is not None,
            "prior_health_score": prior_assessment.overall_health_score if prior_assessment else None,
            "score_change": round((current_assessment.overall_health_score or 0) - (prior_assessment.overall_health_score or 0), 1) if prior_assessment else 0.0,
            "storage_provider": actual_provider,
            "remote_sync_status": actual_sync_status,
            "technology_changes": [],
            "new_risks": [],
            "resolved_risks": [],
            "next_steps_recommendation": ""
        }

        if prior_assessment:
            prior_scores = {s.technology_id: s for s in prior_assessment.scores}
            for tech_id, c_score in curr_scores.items():
                p_score = prior_scores.get(tech_id)
                tech_name = c_score.technology.name if c_score.technology else tech_id
                delta = round(c_score.overall_score - p_score.overall_score, 1) if p_score else 0.0
                comparison["technology_changes"].append({
                    "technology_name": tech_name,
                    "previous_score": p_score.overall_score if p_score else None,
                    "current_score": c_score.overall_score,
                    "change": delta,
                    "previous_status": p_score.risk_classification if p_score else "New",
                    "current_status": c_score.risk_classification,
                    "notes": c_score.notes
                })

            curr_risks = db.query(RiskFinding).filter(RiskFinding.assessment_id == current_assessment.id).all()
            prior_risks = db.query(RiskFinding).filter(RiskFinding.assessment_id == prior_assessment.id).all()
            
            p_titles = {r.title: r for r in prior_risks}
            for cr in curr_risks:
                if cr.title not in p_titles:
                    comparison["new_risks"].append({
                        "severity": cr.severity,
                        "title": cr.title,
                        "description": cr.description
                    })
            
            c_titles = {r.title: r for r in curr_risks}
            for pr in prior_risks:
                if pr.title not in c_titles:
                    comparison["resolved_risks"].append({
                        "severity": pr.severity,
                        "title": pr.title
                    })

            if comparison["score_change"] < 0:
                comparison["next_steps_recommendation"] = "Prioritize updating packages that experienced version drift or new deprecation notices. Review the high-priority risk tickets."
            else:
                comparison["next_steps_recommendation"] = "Technology health is steady or improving. Maintain automated weekly scans to catch new vulnerabilities early."
        else:
            comparison["next_steps_recommendation"] = "Initial assessment established as benchmark baseline. Future assessments will track health score trends and regressions."

        return comparison

    async def _push_to_memento_api_with_retry(
        self,
        payload: Dict[str, Any],
        max_retries: int = 2
    ) -> tuple[bool, str]:
        """Attempt to push snapshot to Memento Cloud API with retries and return (success, error_msg)."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        last_error = ""
        for attempt in range(max_retries):
            try:
                async with httpx.AsyncClient(timeout=8.0) as client:
                    resp = await client.post(f"{self.endpoint}/memories", json=payload, headers=headers)
                    if resp.status_code in [200, 201]:
                        return True, ""
                    else:
                        last_error = f"HTTP {resp.status_code}: {resp.text[:200]}"
            except Exception as e:
                last_error = str(e)
                logger.warning(f"Memento push attempt {attempt + 1} failed: {e}")
        return False, last_error
