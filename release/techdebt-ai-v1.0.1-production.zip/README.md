# TechDebt AI — Technology Debt Review Assistant

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.100%2B-009688.svg)](https://fastapi.tiangolo.com)
[![React 19](https://img.shields.io/badge/React-19-61DAFB.svg)](https://react.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0%2B-3178C6.svg)](https://www.typescriptlang.org)
[![Tailwind CSS v4](https://img.shields.io/badge/TailwindCSS-v4-38B2AC.svg)](https://tailwindcss.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

**TechDebt AI** is an intelligent, evidence-grounded technology assessment platform engineered for CTOs, engineering managers, and technical architects. It continuously analyzes dependencies, frameworks, languages, and packages across 8 weighted categories to pinpoint architectural risk, unmaintained libraries, deprecations, and upgrade blockers.

---

## 🌟 Key Features

1. **Enterprise Security & Organization-Aware Integrations**
   - True tenant isolation enforced on every resource and endpoint.
   - **Organization-Aware API Integrations**: Firecrawl, AI reasoning (OpenAI/Gemini), and Memento memory instances are initialized using organization-specific decrypted credentials at rest (Fernet encryption). Platform environment keys serve only as an explicitly configured fallback (`ALLOW_PLATFORM_INTEGRATION_FALLBACK`).
   - Organization-specific technology catalog visibility: Organizations only view packages and technologies linked to their own projects.
   - **Privilege Escalation Prevention**: Only Administrators can invite Administrator or Engineering Manager roles; Engineering Managers are strictly limited to Developer and Viewer invitations.
   - Invitation tokens are stored hashed (SHA-256) at rest with single-use validation and expiration.
   - Active session tracking with instantaneous token revocation on logout (`jti` blocklist) and automatic expired token purge.
   - In-memory sliding-window API rate limiting (429 with `Retry-After`) and strict file upload sanitization (2MB limit).

2. **Multi-Ecosystem Dependency Parser & Live Registries**
   - Seamlessly parses and normalizes dependencies from:
     - `package.json` (npm / Node.js)
     - `requirements.txt` & `pyproject.toml` (PEP 621 / Poetry / Python)
     - `pom.xml` (Maven / Java)
     - `build.gradle` (Gradle / Kotlin / Android)
     - `Cargo.toml` (Rust)
     - `go.mod` (Go Modules)
     - `composer.json` (PHP / Packagist)
   - Real vulnerability intelligence querying the official Google OSV API for published CVEs.

3. **Firecrawl Web Intelligence & Accurate Provenance**
   - Official documentation and release announcement search with trusted domain validation.
   - **Publication Date Accuracy**: Missing publication dates remain unknown (`None`) without fabricated timestamps.
   - **Maintenance Status Distinctions**: Explicitly categorizes packages into `Active`, `Deprecated`, `End of life`, `Unmaintained` (>3 years without release), or `Unknown`.
   - Exponential backoff retry handling for external API rate limits.

4. **Evidence-Grounded 8-Category Debt Scoring**
   Weighted formula calculating composite health (0–100) computed purely in Python:
   - **Maintenance Health (20%)**
   - **Security Exposure (20%)**
   - **Version Currency (15%)**
   - **Community Activity (10%)**
   - **Documentation Quality (10%)**
   - **Ecosystem Compatibility (10%)**
   - **Long-term Sustainability (10%)**
   - **Upgrade Complexity (5%)**
   - **Confidence-Aware States**: Dedicated `Not Assessed` (score = `None` for unassessed projects) and `Insufficient Evidence` states.
   - Missing security information defaults to neutral unverified baselines (60.0 with Low confidence) rather than misleading 100/100 scores.
   - Prompt-injection defense wrapping crawled content in fenced `<untrusted_crawled_content>` XML delimiters.

5. **Memento Historical Memory Layer with Truthful Provenance**
   - Truthful connectivity verification (real HTTP probe; no assumed connectivity).
   - Remote write failures are never reported as cloud successes; seamlessly falls back to PostgreSQL and truthfully reports `storage_provider: "postgresql"` and `sync_status: "sync_failed_fallback_postgresql"`.
   - Contextual delta breakdowns: score drift, newly emerged risks, and resolved items.

6. **Risk Management Center**
   - Full risk lifecycle triage: `Open` ➔ `Investigating` ➔ `Planned` ➔ `In Progress` ➔ `Resolved` ➔ `Accepted Risk`.
   - Business & technical impact analysis, assignee management, and resolution audit notes.

7. **Balanced Technology Comparison Engine**
   - Multi-tenant head-to-head comparison between 2–4 technologies (e.g. React vs Angular, FastAPI vs Express, PostgreSQL vs MongoDB).
   - Multi-dimensional trade-off matrix without biased claims.

8. **Automated Review Scheduler & Alembic Migrations**
   - Dynamic APScheduler job registration and automatic startup restoration.
   - Support for schedule updates, disabling/enabling (`PATCH /scheduler/{id}`), and concurrency locking to prevent duplicate worker execution.
   - Complete Alembic migration suite (`001_initial_complete_schema.py`) with named constraints and clean rollback.

9. **Board-Ready Reports**
   - One-click PDF generation with ReportLab executive styling.
   - Complete CSV inventory manifests for audit compliance.

---

## 🚀 Quick Start Guide

### Prerequisites
- Python 3.10+
- Node.js 18+ and npm
- (Optional) Docker and Docker Compose

---

### Method 1: Local Development (Instant Out-of-the-Box)

#### 1. Backend Setup
```bash
cd backend

# Install dependencies
pip install -r requirements.txt

# Start backend server (auto-initializes & seeds demo data into SQLite)
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
The API documentation is accessible at: `http://localhost:8000/docs`.

#### 2. Frontend Setup
In a new terminal:
```bash
cd frontend

# Install frontend packages
npm install

# Start Vite development server
npm run dev
```
Open your browser at: `http://localhost:5173`.

---

### Method 2: Docker Deployment

To launch the complete stack with PostgreSQL, FastAPI backend, and Nginx-served React frontend:

```bash
# 1. Copy environment template
cp .env.example .env

# 2. Build and run containers
docker-compose up --build -d
```
The application will be live at:
- **Frontend**: `http://localhost` (Port 80)
- **Backend API**: `http://localhost:8000`
- **PostgreSQL**: `localhost:5432`

---

## 🔑 Pre-Seeded Demo Credentials

TechDebt AI comes pre-seeded with realistic projects (`Customer Web Portal`, `Payment Gateway Service`) and dependencies (`react`, `moment`, `lodash`, `fastapi`, `sqlalchemy`, `pydantic`):

| Role | Email | Password |
| :--- | :--- | :--- |
| **CTO / Administrator** | `admin@techdebt.ai` | `AdminPass123!` |
| **Engineering Manager** | `manager@techdebt.ai` | `ManagerPass123!` |
| **Developer** | `dev@techdebt.ai` | `DevPass123!` |

*(You can also register a brand new organization from the landing page).*

---

## 🧪 Automated Testing

### Backend Unit & Integration Tests (Pytest)
```bash
cd backend
python -m pytest -v
```
*Executes 34 automated tests covering:*
- Multi-tenant cross-organization isolation and tenant boundary enforcement
- Organization-aware integration credential decryption and isolation
- Privilege escalation prevention (Admin vs Manager invitation constraints)
- SHA-256 hashed invitation token storage and single-use validation
- Truthful Memento connectivity and failure provenance
- Unassessed and Insufficient Evidence scoring states
- Accurate Firecrawl provenance and unmanufactured publication dates
- Scheduler update, disable, and concurrent worker execution locking

### Frontend Component Tests (Vitest)
```bash
cd frontend
npm test
```
*Executes Vitest tests verifying UI badges, health derivations, 'Not Assessed' states, and accessibility.*

---

## 🏛️ System Architecture

```mermaid
flowchart LR
    subgraph UI ["React 19 Frontend"]
        D[Dashboard]
        P[Projects & Manifest Dropzone]
        R[Risk Center]
        C[Comparison Engine]
        H[Memento Memory Timeline]
    end

    subgraph API ["FastAPI Backend (REST API /api/v1)"]
        Auth[Auth & RBAC]
        Parsers[8-Format Dependency Parsers]
        Firecrawl[Firecrawl Intelligence Engine]
        Scorer[8-Category Weighted AI Scorer]
        Memento[Memento Memory Adapter]
        Scheduler[Background Review Scheduler]
        Reporter[PDF & CSV Report Engine]
    end

    subgraph Storage ["Persistence"]
        DB[(PostgreSQL / SQLite)]
        Mem[(Memento Cloud / Fallback)]
    end

    UI --> API
    API --> DB & Mem
```

---

## 📄 License
MIT License. Built for modern software engineering teams.

