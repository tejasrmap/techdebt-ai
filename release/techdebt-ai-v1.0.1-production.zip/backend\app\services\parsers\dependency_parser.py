import re
import json
import xml.etree.ElementTree as ET
from typing import List, Dict, Any, Optional

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        import toml as tomllib

def clean_version(raw_version: str) -> str:
    if not raw_version:
        return "latest"
    # Strip common package manager version specifiers
    cleaned = re.sub(r"^[~^><=v\s]+", "", raw_version.strip())
    # Take first version in range if multiple e.g. ">=1.0, <2.0"
    cleaned = cleaned.split(",")[0].strip()
    return cleaned if cleaned else "latest"

class DependencyParser:
    @staticmethod
    def parse(file_name: str, content: str) -> List[Dict[str, Any]]:
        name_lower = file_name.lower()
        if name_lower.endswith("package.json"):
            return DependencyParser._parse_package_json(content)
        elif name_lower.endswith("requirements.txt") or "requirements" in name_lower:
            return DependencyParser._parse_requirements_txt(content)
        elif name_lower.endswith("pyproject.toml"):
            return DependencyParser._parse_pyproject_toml(content)
        elif name_lower.endswith("pom.xml"):
            return DependencyParser._parse_pom_xml(content)
        elif name_lower.endswith("build.gradle") or name_lower.endswith("build.gradle.kts"):
            return DependencyParser._parse_build_gradle(content)
        elif name_lower.endswith("cargo.toml"):
            return DependencyParser._parse_cargo_toml(content)
        elif name_lower.endswith("go.mod"):
            return DependencyParser._parse_go_mod(content)
        elif name_lower.endswith("composer.json"):
            return DependencyParser._parse_composer_json(content)
        else:
            # Fallback heuristic: try JSON, then toml, then line-based
            try:
                data = json.loads(content)
                if "dependencies" in data or "require" in data:
                    return DependencyParser._parse_package_json(content)
            except Exception:
                pass
            return DependencyParser._parse_requirements_txt(content)

    @staticmethod
    def _parse_package_json(content: str) -> List[Dict[str, Any]]:
        results = []
        try:
            data = json.loads(content)
            deps = data.get("dependencies", {})
            dev_deps = data.get("devDependencies", {})
            
            for pkg, ver in deps.items():
                results.append({
                    "name": pkg,
                    "installed_version": clean_version(str(ver)),
                    "ecosystem": "npm",
                    "category": "Library",
                    "is_direct_dep": True,
                    "file_source": "package.json"
                })
            for pkg, ver in dev_deps.items():
                results.append({
                    "name": pkg,
                    "installed_version": clean_version(str(ver)),
                    "ecosystem": "npm",
                    "category": "DevDependency",
                    "is_direct_dep": False,
                    "file_source": "package.json"
                })
        except Exception:
            pass
        return results

    @staticmethod
    def _parse_requirements_txt(content: str) -> List[Dict[str, Any]]:
        results = []
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-r") or line.startswith("--"):
                continue
            # Regex for name and version
            match = re.split(r"(==|>=|<=|~=|!=|>|<)", line)
            pkg_name = match[0].strip()
            # Remove environment markers like '; python_version < "3.8"'
            pkg_name = pkg_name.split(";")[0].strip()
            version = "latest"
            if len(match) > 2:
                ver_part = match[2].split(";")[0].strip()
                version = clean_version(ver_part)
            if pkg_name:
                results.append({
                    "name": pkg_name,
                    "installed_version": version,
                    "ecosystem": "pypi",
                    "category": "Library",
                    "is_direct_dep": True,
                    "file_source": "requirements.txt"
                })
        return results

    @staticmethod
    def _parse_pyproject_toml(content: str) -> List[Dict[str, Any]]:
        results = []
        try:
            data = tomllib.loads(content) if hasattr(tomllib, "loads") else {}
            # Check PEP 621 project.dependencies
            deps = data.get("project", {}).get("dependencies", [])
            for item in deps:
                if isinstance(item, str):
                    res = DependencyParser._parse_requirements_txt(item)
                    for r in res:
                        r["file_source"] = "pyproject.toml"
                        results.append(r)
            
            # Check Poetry [tool.poetry.dependencies]
            poetry_deps = data.get("tool", {}).get("poetry", {}).get("dependencies", {})
            for pkg, ver in poetry_deps.items():
                if pkg.lower() == "python":
                    continue
                version_str = str(ver) if not isinstance(ver, dict) else str(ver.get("version", "latest"))
                results.append({
                    "name": pkg,
                    "installed_version": clean_version(version_str),
                    "ecosystem": "pypi",
                    "category": "Library",
                    "is_direct_dep": True,
                    "file_source": "pyproject.toml"
                })
        except Exception:
            pass
        return results

    @staticmethod
    def _parse_pom_xml(content: str) -> List[Dict[str, Any]]:
        results = []
        try:
            # Strip namespaces for easier parsing
            clean_xml = re.sub(r' xmlns="[^"]+"', '', content, count=1)
            root = ET.fromstring(clean_xml)
            for dep in root.findall(".//dependency"):
                group_id = dep.findtext("groupId", "").strip()
                artifact_id = dep.findtext("artifactId", "").strip()
                version = dep.findtext("version", "latest").strip()
                name = f"{group_id}:{artifact_id}" if group_id else artifact_id
                if name:
                    results.append({
                        "name": name,
                        "installed_version": clean_version(version),
                        "ecosystem": "maven",
                        "category": "Library",
                        "is_direct_dep": True,
                        "file_source": "pom.xml"
                    })
        except Exception:
            pass
        return results

    @staticmethod
    def _parse_build_gradle(content: str) -> List[Dict[str, Any]]:
        results = []
        patterns = [
            r"""(?:implementation|api|compile|testImplementation)\s*['"]([^:'"]+):([^:'"]+)(?::([^:'"]+))?['"]""",
            r"""(?:implementation|api|compile)\s*\(\s*['"]([^:'"]+):([^:'"]+)(?::([^:'"]+))?['"]\s*\)"""
        ]
        for pattern in patterns:
            matches = re.findall(pattern, content)
            for m in matches:
                group, artifact = m[0].strip(), m[1].strip()
                version = m[2].strip() if len(m) > 2 and m[2] else "latest"
                name = f"{group}:{artifact}"
                results.append({
                    "name": name,
                    "installed_version": clean_version(version),
                    "ecosystem": "gradle",
                    "category": "Library",
                    "is_direct_dep": True,
                    "file_source": "build.gradle"
                })
        return results

    @staticmethod
    def _parse_cargo_toml(content: str) -> List[Dict[str, Any]]:
        results = []
        try:
            data = tomllib.loads(content) if hasattr(tomllib, "loads") else {}
            deps = data.get("dependencies", {})
            for pkg, val in deps.items():
                ver = val if isinstance(val, str) else (val.get("version", "latest") if isinstance(val, dict) else "latest")
                results.append({
                    "name": pkg,
                    "installed_version": clean_version(str(ver)),
                    "ecosystem": "cargo",
                    "category": "Crate",
                    "is_direct_dep": True,
                    "file_source": "Cargo.toml"
                })
        except Exception:
            pass
        return results

    @staticmethod
    def _parse_go_mod(content: str) -> List[Dict[str, Any]]:
        results = []
        in_require_block = False
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("//"):
                continue
            if line.startswith("require ("):
                in_require_block = True
                continue
            if in_require_block:
                if line == ")":
                    in_require_block = False
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    results.append({
                        "name": parts[0],
                        "installed_version": clean_version(parts[1]),
                        "ecosystem": "go",
                        "category": "Module",
                        "is_direct_dep": not ("// indirect" in line),
                        "file_source": "go.mod"
                    })
            elif line.startswith("require "):
                parts = line.replace("require ", "").split()
                if len(parts) >= 2:
                    results.append({
                        "name": parts[0],
                        "installed_version": clean_version(parts[1]),
                        "ecosystem": "go",
                        "category": "Module",
                        "is_direct_dep": not ("// indirect" in line),
                        "file_source": "go.mod"
                    })
        return results

    @staticmethod
    def _parse_composer_json(content: str) -> List[Dict[str, Any]]:
        results = []
        try:
            data = json.loads(content)
            reqs = data.get("require", {})
            for pkg, ver in reqs.items():
                if pkg.lower() == "php":
                    continue
                results.append({
                    "name": pkg,
                    "installed_version": clean_version(str(ver)),
                    "ecosystem": "packagist",
                    "category": "Package",
                    "is_direct_dep": True,
                    "file_source": "composer.json"
                })
        except Exception:
            pass
        return results

