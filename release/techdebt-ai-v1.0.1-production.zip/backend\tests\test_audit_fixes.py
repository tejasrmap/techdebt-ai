import os
import uuid
import asyncio
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta
import pytest
from pydantic import ValidationError
from fastapi.testclient import TestClient

from app.config import Settings, DEFAULT_DEV_SECRET, PROHIBITED_SECRET_DEFAULTS
from app.database import SessionLocal
from app.models.all_models import (
    Organization, User, Project, ScheduledReview, ReviewJob,
    HistoricalAssessment, Assessment, DistributedLock
)
from app.services.scheduler_service import (
    run_scheduled_job,
    acquire_distributed_lock,
    release_distributed_lock,
    execute_project_review
)
from app.services.ai_analyzer import AITechnologyDebtAnalyzer
from app.services.memento_adapter import MementoMemoryAdapter
from app.main import app

client = TestClient(app)

def get_or_create_test_org(db) -> Organization:
    org = db.query(Organization).first()
    if not org:
        org = Organization(name="Test Org " + uuid.uuid4().hex[:6], slug="test-org-" + uuid.uuid4().hex[:6])
        db.add(org)
        db.commit()
        db.refresh(org)
    return org

def get_or_create_test_project(db) -> Project:
    org = get_or_create_test_org(db)
    proj = db.query(Project).filter(Project.org_id == org.id).first()
    if not proj:
        proj = Project(org_id=org.id, name="Test Project " + uuid.uuid4().hex[:6])
        db.add(proj)
        db.commit()
        db.refresh(proj)
    return proj

# -------------------------------------------------------------
# 1. DOCKER SECRETS & PRODUCTION CONFIGURATION TESTS
# -------------------------------------------------------------
def test_production_rejects_default_secrets():
    """Verify production configuration rejects known default secret keys and weak values."""
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": DEFAULT_DEV_SECRET,
        "ENCRYPTION_KEY": "a" * 32,
        "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="FATAL SECURITY VIOLATION: In production, SECRET_KEY"):
            Settings()

    # Reject known defaults in prohibited set
    for default_sec in PROHIBITED_SECRET_DEFAULTS:
        with patch.dict(os.environ, {
            "ENVIRONMENT": "production",
            "SECRET_KEY": default_sec,
            "ENCRYPTION_KEY": "a" * 32,
            "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
        }):
            with pytest.raises(ValueError, match="FATAL SECURITY VIOLATION"):
                Settings()

    # Reject short secret key (< 32 characters)
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "short-secret-key-too-brief",
        "ENCRYPTION_KEY": "a" * 32,
        "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="at least 32 characters long"):
            Settings()

def test_production_requires_encryption_key():
    """Verify production configuration requires valid ENCRYPTION_KEY."""
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "a-strong-random-production-secret-key-that-is-long-enough",
        "ENCRYPTION_KEY": "",
        "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="ENCRYPTION_KEY must be explicitly set"):
            Settings()

    # Reject known default encryption key
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "a-strong-random-production-secret-key-that-is-long-enough",
        "ENCRYPTION_KEY": "techdebt-ai-fernet-encryption-key-prod-2025",
        "DATABASE_URL": "postgresql://user:valid_strong_pass@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="must not match known default values"):
            Settings()

def test_production_rejects_default_db_password():
    """Verify production rejects known default postgres passwords in DATABASE_URL."""
    with patch.dict(os.environ, {
        "ENVIRONMENT": "production",
        "SECRET_KEY": "a-strong-random-production-secret-key-that-is-long-enough",
        "ENCRYPTION_KEY": "a-strong-production-fernet-key-valid",
        "DATABASE_URL": "postgresql://postgres:postgrespassword@localhost:5432/db"
    }):
        with pytest.raises(ValueError, match="DATABASE_URL must not use default or trivial passwords"):
            Settings()


# -------------------------------------------------------------
# 2. DATABASE MIGRATION STARTUP & ROLLBACK TESTS
# -------------------------------------------------------------
def test_alembic_startup_fails_on_migration_error():
    """Verify application startup fails if Alembic migration fails without falling back to create_all."""
    from app.main import lifespan

    # Mock command.upgrade to simulate migration error
    with patch("alembic.command.upgrade", side_effect=Exception("Simulated schema migration syntax error")):
        with patch.object(app, "router"):
            async def run():
                async with lifespan(app):
                    pass
            with pytest.raises(RuntimeError, match="Application startup aborted: Alembic migrations failed"):
                asyncio.run(run())

def test_database_migration_downgrade_and_reupgrade():
    """Test Alembic migration rollback to base and re-upgrade to head programmatically."""
    from alembic.config import Config
    from alembic import command
    from app.config import settings

    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ini_path = os.path.join(base_dir, "alembic.ini")
    assert os.path.exists(ini_path)

    alembic_cfg = Config(ini_path)
    alembic_cfg.set_main_option("script_location", os.path.join(base_dir, "alembic"))
    alembic_cfg.set_main_option("sqlalchemy.url", settings.DATABASE_URL)

    # Downgrade to base
    command.downgrade(alembic_cfg, "base")

    # Re-upgrade to head
    command.upgrade(alembic_cfg, "head")

    # Re-seed test database to preserve baseline seed data for remaining test suites
    from app.seed_data import seed
    seed()

    # Verify tables exist by acquiring a lock
    db = SessionLocal()
    try:
        acquired = acquire_distributed_lock(db, "test_migration_lock", "test_runner", ttl_seconds=30)
        assert acquired is True
        released = release_distributed_lock(db, "test_migration_lock", "test_runner")
        assert released is True
    finally:
        db.close()


# -------------------------------------------------------------
# 3 & 4. SCHEDULER BUG FIX, ATOMIC LOCKING & CONCURRENT WORKERS
# -------------------------------------------------------------
def test_scheduler_run_scheduled_job_success():
    """Directly execute run_scheduled_job() and verify ReviewJob and schedule status updates."""
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(org_id=org.id, name=f"Sched Direct Run Proj {uuid.uuid4().hex[:6]}")
        db.add(proj)
        db.commit()

        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Daily",
            cron_expression="0 0 * * *",
            is_active=True
        )
        db.add(schedule)
        db.commit()
        schedule_id = schedule.id

        # Mock execute_project_review to avoid slow full web crawls during unit test
        async def mock_review(*args, **kwargs):
            return Assessment(project_id=proj.id, status="completed", overall_health_score=82.0)

        with patch("app.services.scheduler_service.execute_project_review", side_effect=mock_review):
            executed = run_scheduled_job(schedule_id, worker_id="test_worker_1")
            assert executed is True

        # Check job status in database
        job = db.query(ReviewJob).filter(ReviewJob.scheduled_review_id == schedule_id).order_by(ReviewJob.started_at.desc()).first()
        assert job is not None
        assert job.status == "Completed"
        assert job.completed_at is not None

        # Check schedule last run and next run updated
        db.refresh(schedule)
        assert schedule.last_run_at is not None
        assert schedule.next_run_at is not None
    finally:
        db.close()

def test_scheduler_run_scheduled_job_failure_and_retries():
    """Directly execute run_scheduled_job() with failing execution and verify retry behavior."""
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(org_id=org.id, name=f"Sched Fail Proj {uuid.uuid4().hex[:6]}")
        db.add(proj)
        db.commit()

        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Daily",
            cron_expression="0 0 * * *",
            is_active=True
        )
        db.add(schedule)
        db.commit()
        schedule_id = schedule.id

        attempts = []
        async def mock_failing_review(*args, **kwargs):
            attempts.append(len(attempts) + 1)
            raise RuntimeError("Simulated failure in review pipeline")

        with patch("app.services.scheduler_service.execute_project_review", side_effect=mock_failing_review):
            with patch("time.sleep"):  # Skip sleep duration in test
                executed = run_scheduled_job(schedule_id, max_retries=3, worker_id="test_fail_worker")
                assert executed is False

        # Verify retry count: must have been attempted 3 times
        assert len(attempts) == 3

        # Check job recorded as Failed with error message
        job = db.query(ReviewJob).filter(ReviewJob.scheduled_review_id == schedule_id).order_by(ReviewJob.started_at.desc()).first()
        assert job is not None
        assert job.status == "Failed"
        assert "Simulated failure" in job.error_message
    finally:
        db.close()

def test_two_concurrent_workers_attempting_same_scheduled_job():
    """Verify atomic distributed locking prevents two concurrent workers from running the same job."""
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(org_id=org.id, name=f"Concurrent Proj {uuid.uuid4().hex[:6]}")
        db.add(proj)
        db.commit()

        schedule = ScheduledReview(
            project_id=proj.id,
            frequency="Weekly",
            cron_expression="0 0 * * 1",
            is_active=True
        )
        db.add(schedule)
        db.commit()
        schedule_id = schedule.id

        # Worker 1 acquires lock
        lock_key = f"review_job_lock_{schedule_id}"
        lock_1 = acquire_distributed_lock(db, lock_key, "worker_1", ttl_seconds=60)
        assert lock_1 is True

        # Worker 2 attempts to run the same scheduled job while lock is held
        # run_scheduled_job should return False without running
        executed = run_scheduled_job(schedule_id, worker_id="worker_2")
        assert executed is False

        # Release Worker 1's lock
        released = release_distributed_lock(db, lock_key, "worker_1")
        assert released is True

        # Now Worker 2 can acquire and run
        async def mock_review(*args, **kwargs):
            return Assessment(project_id=proj.id, status="completed", overall_health_score=85.0)

        with patch("app.services.scheduler_service.execute_project_review", side_effect=mock_review):
            executed_after_release = run_scheduled_job(schedule_id, worker_id="worker_2")
            assert executed_after_release is True
    finally:
        db.close()


# -------------------------------------------------------------
# 5. AI PROVIDER VERIFICATION TESTS (GEMINI & OPENAI)
# -------------------------------------------------------------
def test_ai_provider_verification_gemini_unconfigured():
    """Verify Gemini connectivity reports unconfigured when key is empty."""
    analyzer = AITechnologyDebtAnalyzer(gemini_key="")
    res = asyncio.run(analyzer.verify_connectivity("gemini"))
    assert res["status"] == "unconfigured"
    assert res["connected"] is False

def test_ai_provider_verification_gemini_connected():
    """Verify Gemini connectivity reports connected when API returns HTTP 200."""
    analyzer = AITechnologyDebtAnalyzer(gemini_key="valid-mock-key")
    mock_resp = MagicMock(status_code=200)

    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("gemini"))
        assert res["status"] == "connected"
        assert res["connected"] is True
        assert res["model"] == analyzer.model_name

def test_ai_provider_verification_gemini_invalid_key():
    """Verify Gemini connectivity reports invalid_credentials on HTTP 403."""
    analyzer = AITechnologyDebtAnalyzer(gemini_key="invalid-key")
    mock_resp = MagicMock(status_code=403, text="API key not valid")

    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("gemini"))
        assert res["status"] == "invalid_credentials"
        assert res["connected"] is False

def test_ai_provider_verification_gemini_quota_exceeded():
    """Verify Gemini connectivity reports quota_exceeded on HTTP 429."""
    analyzer = AITechnologyDebtAnalyzer(gemini_key="rate-limited-key")
    mock_resp = MagicMock(status_code=429)

    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("gemini"))
        assert res["status"] == "quota_exceeded"
        assert res["connected"] is False

def test_ai_provider_verification_openai_connected():
    """Verify OpenAI connectivity reports connected when API returns HTTP 200."""
    analyzer = AITechnologyDebtAnalyzer(openai_key="sk-mock-valid-key")
    mock_resp = MagicMock(status_code=200)

    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("openai"))
        assert res["status"] == "connected"
        assert res["connected"] is True

def test_ai_provider_verification_openai_invalid_key():
    """Verify OpenAI connectivity reports invalid_credentials on HTTP 401."""
    analyzer = AITechnologyDebtAnalyzer(openai_key="sk-invalid-key")
    mock_resp = MagicMock(status_code=401)

    with patch("httpx.AsyncClient.get", return_value=mock_resp):
        res = asyncio.run(analyzer.verify_connectivity("openai"))
        assert res["status"] == "invalid_credentials"
        assert res["connected"] is False


# -------------------------------------------------------------
# 6. MEMENTO CLOUD SYNC & RETRIEVAL TESTS
# -------------------------------------------------------------
def test_memento_remote_memory_creation_success():
    """Verify successful remote memory creation records storage_provider=memento_cloud."""
    mem = MementoMemoryAdapter(api_key="valid-memento-token", endpoint="https://api.memento.ai/v1")
    db = SessionLocal()
    try:
        org = get_or_create_test_org(db)
        proj = Project(org_id=org.id, name=f"Memento Cloud Proj {uuid.uuid4().hex[:6]}")
        db.add(proj)
        db.commit()

        ass = Assessment(project_id=proj.id, status="completed", overall_health_score=90.0)
        db.add(ass)
        db.commit()

        # Mock successful push to Memento Cloud API (HTTP 201)
        mock_resp = MagicMock(status_code=201)
        with patch("httpx.AsyncClient.post", return_value=mock_resp):
            hist = asyncio.run(mem.record_assessment_snapshot(
                db=db,
                project_id=proj.id,
                assessment_id=ass.id,
                overall_score=90.0,
                risk_classification="Healthy",
                tech_scores=[],
                identified_risks=[]
            ))
            assert hist.storage_provider == "memento_cloud"
            assert hist.sync_status == "synced_to_memento_cloud"
            assert hist.sync_error == ""
    finally:
        db.close()

def test_memento_remote_memory_retrieval_success():
    """Verify get_historical_memories retrieves from Memento Cloud when available."""
    mem = MementoMemoryAdapter(api_key="valid-memento-token", endpoint="https://api.memento.ai/v1")
    db = SessionLocal()
    try:
        proj = get_or_create_test_project(db)
        cloud_payload = {
            "memories": [
                {"id": "cloud_mem_1", "health_score": 92.0, "risk_classification": "Healthy"}
            ]
        }
        mock_resp = MagicMock(status_code=200, json=lambda: cloud_payload)
        with patch("httpx.AsyncClient.get", return_value=mock_resp):
            memories = asyncio.run(mem.get_historical_memories(db, proj.id))
            assert memories["storage_provider"] == "memento_cloud"
            assert memories["remote_sync_status"] == "synced"
            assert len(memories["memories"]) == 1
            assert memories["memories"][0]["id"] == "cloud_mem_1"
    finally:
        db.close()
