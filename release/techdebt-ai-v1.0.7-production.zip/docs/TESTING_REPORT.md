# TechDebt AI v1.0.7 — Automated Testing & Quality Report

**Product:** TechDebt AI – Technology Debt Review Assistant  
**Release Version:** v1.0.7  
**Test Frameworks:** Pytest 9.1 (Backend) & Vitest 4.1 (Frontend)  
**Execution Environment:** Windows Server / Python 3.10.9 / Node 20  
**Date:** November 6, 2026  

---

## 1. Test Execution Summary

| Domain | Total Tests | Passed | Skipped | Failed | Duration | Status |
|---|---|---|---|---|---|---|
| Backend Pytest Suite | 78 | 75 | 3 | 0 | 67.76s | **PASSED** |
| Frontend Vitest Suite | 4 | 4 | 0 | 0 | 2.05s | **PASSED** |
| TypeScript Compiler (`tsc -b`) | — | — | — | 0 errors | 0.75s | **PASSED** |
| Frontend Linter (`oxlint`) | — | — | — | 0 errors | 31ms | **PASSED** |
| Docker Compose Config Validation | — | — | — | 0 errors | 0.8s | **PASSED** |
| **Combined Quality Gate** | **82** | **79** | **3** | **0** | **~71s** | **ALL PASSED** |

> [!NOTE]
> 3 backend tests are intentionally skipped when live third-party API credentials (live Firecrawl / Gemini) are not injected in the local test environment. All mocked and fallback intelligence paths execute and pass.

---

## 2. Backend Test Breakdown

### 2.1 Scheduler, Transactional Fencing & Concurrency Suite (`test_audit_fixes.py`)
- `test_premature_commit_regression_and_atomic_persistence`: Validates that `verify_ownership_short_transaction()` does not commit caller's session, preserves active row lock, blocks competing worker attempts, and commits all assessment records and snapshot in a single atomic commit.
- `test_premature_commit_regression_rollback_variant`: Proves that failures before final commit roll back cleanly, leaving zero uncommitted or orphaned records.
- `test_final_persistence_boundary_concurrency_lock_loss`: Proves that Worker A paused at the final persistence boundary is rejected when Worker B reclaims ownership, Worker B completes under generation 2, and zero stale records or duplicate assessments occur.
- `test_genuine_mid_execution_lock_loss_stale_write_rejection`: End-to-end integration test with independent DB sessions and active worker thread. Worker A starts assessment under generation 1 with active heartbeat -> pauses at synchronization barrier -> lease expires -> Worker B reclaims with generation 2 -> Worker A resumes and attempts commit -> DB rejects write with `StaleGenerationWriteError` -> Worker A terminates safely -> Worker B completes assessment -> Worker A cannot release Worker B's lock -> exactly 1 completed assessment and 1 historical snapshot recorded with generation 2.
- `test_heartbeat_renewal_unblocked_during_slow_ai_request`: Proves that slow AI or Firecrawl requests do NOT hold database row locks, allowing LockHeartbeat to renew leases smoothly and rejecting competing workers.
- `test_scheduler_suite_a_initial_acquisition`: Lock acquisition on unoccupied key sets owner, generation=1, and valid expiration.
- `test_scheduler_suite_b_active_ownership_rejection`: Second worker receives False and cannot mutate active lock.
- `test_scheduler_suite_c_expired_lock_reclamation`: Conditional UPDATE reclaims expired lock and increments generation to 2.
- `test_scheduler_suite_d_concurrent_expired_lock_reclamation`: Multiprocessing test with 2 OS worker processes competing for an expired lock; exactly 1 acquires and 1 is rejected.
- `test_scheduler_suite_e_heartbeat_renewal_multiple_times`: Heartbeat background thread advances `expires_at` across multiple triggers.
- `test_scheduler_suite_f_worker_ownership_renewal_isolation`: Imposter worker or mismatched generation token cannot renew lease.
- `test_scheduler_suite_g_worker_ownership_release_isolation`: Imposter worker or mismatched generation token cannot delete lease.
- `test_scheduler_suite_h_long_running_assessment_heartbeat`: Long-running review maintains heartbeat throughout full assessment pipeline.
- `test_scheduler_suite_i_mid_execution_fencing_rejection_and_rollback`: Fencing token mismatch at pipeline checkpoints raises RuntimeError and rolls back database transaction.
- `test_scheduler_suite_j_transient_db_interruption_during_heartbeat`: Heartbeat retries bounded number of times before flagging lock as lost.
- `test_genuine_multiprocessing_scheduler_concurrency`: Two independent OS processes execute scheduled reviews concurrently via APScheduler; exactly one executes review job.
- `test_safe_database_migration_downgrade_and_upgrade_on_disposable_db`: Alembic rollback to base and re-upgrade to head on disposable temporary database.

### 2.2 Security & Multi-Tenancy Suite (`test_security_multitenancy.py`)
- `test_public_registration_prevents_unauthorized_org_join`: 400 on existing organization name.
- `test_invitation_flow_and_membership`: Full invitation token lifecycle.
- `test_cross_organization_data_isolation`: 404 on cross-organization project read/update/delete.
- `test_rbac_restrictions`: 403 on non-admin accessing integration settings or issuing unauthorized invites.
- `test_token_revocation_on_logout`: Instantaneous JWT invalidation via blocklist.
- `test_file_upload_validation`: Validation of file size (2MB cap) and disallowed extensions.
- `test_organization_integration_credentials_isolation`: Tenant-isolated Fernet encryption keys.
- `test_organization_technology_catalog_visibility`: Tenant-scoped catalog queries.
- `test_expired_revoked_token_purging`: Database cleanliness maintenance.
- `test_exhaustive_cross_organization_negative_authorization`: 404 rejection across reports, schedules, review jobs, and assessments.

### 2.3 AI & Integrations Suite (`test_ai_and_integrations.py`)
- `test_memento_authoritative_postgresql_provenance`: Verifies PostgreSQL multi-tenant memory storage and local-first MCP architecture clarity.
- `test_scheduler_update_and_disable`: Verifies schedule frequency updates and disabling.
- `test_ai_analyzer_error_handling_and_fallback`: Verifies graceful fallback to deterministic rules when LLM fails.
- `test_firecrawl_timeout_and_error_recovery`: Verifies timeout handling (15s) and registry fallback.
- `test_prompt_injection_defense`: Verifies `<untrusted_crawled_content>` XML fences.

### 2.4 Core & Lifecycle Suite (`test_core.py`, `test_api.py`, `test_e2e_lifecycle.py`)
- `test_full_26_step_end_to_end_acceptance`: Full journey from registration, project creation, manifest import, live intelligence gathering, AI analysis, weighted debt scoring, Memento/PostgreSQL snapshot, risk triage, report generation, to logout.
- `test_dashboard_overview`: Dashboard KPI aggregation and null-safe health score averaging.
- `test_projects_crud`: Project management and inventory queries.
- `test_technology_comparison`: Side-by-side trade-off matrix generation.
- `test_risk_management`: Lifecycle triage state transitions.

---

## 3. Frontend Quality Suite

- **Vitest Unit Tests:** 4 tests passing in `src/test/components.test.tsx` (HealthScoreBadge, RiskBadge, Button, Input components).
- **TypeScript Build:** Zero compilation errors on `tsc -b && vite build`.
- **Linter Analysis:** Zero errors across 23 files and 116 rules in `oxlint`.

