# TechDebt AI v1.0.5 — Production Release Manifest

**Product:** TechDebt AI – Technology Debt Review Assistant  
**Release Tag:** `v1.0.5`  
**Developer Organization:** GT InnoX LLP  
**Date:** November 6, 2026  
**Status:** Certified Production Release Candidate  

---

## 1. Executive Summary

TechDebt AI v1.0.5 is an enterprise-grade technology debt assessment and software engineering intelligence platform. This release delivers database-level transactional fencing, stale-write protection across multi-worker deployments, verified mid-execution lease expiration recovery, complete removal of deprecated cloud memory configurations, and full multi-tenant isolation.

---

## 2. Release Highlights & Engineering Certifications

### 2.1 Genuine Transactional Fencing and Stale-Write Protection
- **Transactional Row Locking:** Implemented `assert_valid_fenced_lease_transactional()` utilizing database-level row locking (`SELECT ... FOR UPDATE`) coordinated inside the exact transaction that persists assessment results, technology scores, and review jobs.
- **Monotonic Generation Tracking:** Database migrations add `fencing_generation` columns to `assessments`, `review_jobs`, and `historical_assessments`.
- **Conditional SQL Updates:** All updates to `Assessment` and `ReviewJob` enforce `fencing_generation <= generation`.
- **`StaleGenerationWriteError`:** Any worker holding a superseded, expired, or stolen lease is rejected at the database level. Failure status writes (`status='failed'`) are strictly suppressed when lock ownership is lost, preventing stale workers from corrupting active executions.
- **Genuine Mid-Execution Lock-Loss Test:** Verified via `test_genuine_mid_execution_lock_loss_stale_write_rejection()` with independent database sessions: Worker A starts -> lease expires -> Worker B reclaims with generation 2 -> Worker A resumes and is rejected with `StaleGenerationWriteError` -> Worker B completes assessment -> exactly 1 completed assessment and 1 historical snapshot exist.

### 2.2 Complete Memento Cloud Configuration Cleanup
- **Schema & Config Cleanup:** Removed obsolete `MEMENTO_API_KEY`, `MEMENTO_API_URL`, and `api.memento.ai` references from `.env.example`, `docker-compose.yml`, settings schemas, database models, and documentation.
- **Authoritative PostgreSQL Storage:** Retains PostgreSQL as the authoritative multi-tenant longitudinal memory store (`HistoricalAssessment` model).
- **Truthful UI Provenance:** Frontend displays truthful provenance (`PostgreSQL Historical Storage`) across all views, headers, and badges.

### 2.3 Quality and Security Verification
- **Backend Test Suite:** 74 tests (71 passing, 3 skipped for optional live external credentials, 0 failed).
- **Frontend Test Suite:** 4 component tests (4 passing, 0 failed).
- **TypeScript Compilation:** Zero errors (`tsc -b`).
- **Static Analysis:** Zero errors (`oxlint`).
- **Docker Compose Configuration:** Verified valid syntax with mandatory secret guards.

---

## 3. Directory Layout and Key File Manifest

```
GenAI/
├── README.md                                             # Production documentation & architectural overview
├── RELEASE_MANIFEST.md                                   # This release manifest
├── docker-compose.yml                                    # Production Docker orchestration (backend, worker, db, frontend)
├── .env.example                                          # Production environment variable template (no placeholders)
├── backend/
│   ├── alembic.ini                                       # Alembic database migration configuration
│   ├── requirements.txt                                  # Python dependencies
│   ├── alembic/
│   │   ├── env.py                                        # Migration runner
│   │   └── versions/
│   │       ├── 001_initial_complete_schema.py            # Baseline relational schema (17 tables)
│   │       └── 002_transactional_fencing_and_memento_cleanup.py  # Fencing columns & Memento cleanup
│   ├── app/
│   │   ├── main.py                                       # FastAPI entrypoint, lifespan migration, & CORS
│   │   ├── worker.py                                     # Dedicated APScheduler review worker process
│   │   ├── config.py                                     # Pydantic v2 settings & prohibited secret validator
│   │   ├── database.py                                   # SQLAlchemy engine, session maker, & SQLite timeout
│   │   ├── api/v1/                                       # Scoped REST API routers
│   │   │   ├── auth.py                                   # Registration, login, logout, invitations, & profile
│   │   │   ├── projects.py                               # Multi-tenant project management & file upload
│   │   │   ├── assessments.py                            # Review trigger & assessment result inspection
│   │   │   ├── history.py                                # Longitudinal memory & delta comparison
│   │   │   ├── settings.py                               # Encrypted integration settings & provider probes
│   │   │   ├── reports.py                                # Executive debt & audit reporting
│   │   │   └── scheduler.py                              # Scheduled review administration
│   │   ├── models/
│   │   │   └── all_models.py                             # SQLAlchemy ORM models with fencing generation
│   │   ├── schemas/
│   │   │   └── schemas.py                                # Pydantic response and request schemas
│   │   └── services/
│   │       ├── scheduler_service.py                      # Distributed locking, heartbeat, & transactional fencing
│   │       ├── memento_adapter.py                        # Authoritative PostgreSQL historical memory adapter
│   │       ├── integration_config_service.py              # Tenant-isolated credential decryption & injection
│   │       ├── ai_analyzer.py                            # Gemini/OpenAI technology debt analyzer & prompt hardening
│   │       ├── firecrawl_service.py                      # Web intelligence gathering & registry scraping
│   │       ├── osv_service.py                            # Google OSV vulnerability scanning service
│   │       ├── manifest_parser.py                        # Multi-ecosystem dependency parser (8 package ecosystems)
│   │       ├── debt_calculator.py                        # Pure Python deterministic 8-category debt scoring
│   │       └── crypto_service.py                         # Fernet symmetric credential encryption
│   └── tests/                                            # Complete automated test suites (74 test cases)
│       ├── test_audit_fixes.py                           # Scheduler concurrency, fencing, & migration tests
│       ├── test_security_multitenancy.py                 # Multi-tenant authorization & negative access tests
│       ├── test_e2e_lifecycle.py                         # 26-step full platform lifecycle integration test
│       ├── test_ai_and_integrations.py                   # Provider verification & parsing tests
│       ├── test_api.py                                   # REST API endpoints & authentication
│       └── test_core.py                                  # Debt calculation & formula verification
├── frontend/
│   ├── package.json                                      # Node dependencies (React 19, Tailwind CSS v4, Lucide)
│   ├── vite.config.ts                                    # Vite build configuration
│   ├── nginx.conf                                        # Production SPA routing & reverse proxy configuration
│   ├── src/
│   │   ├── App.tsx                                       # Root application & routing
│   │   ├── main.tsx                                      # Application bootstrap
│   │   ├── context/
│   │   │   └── AuthContext.tsx                           # Authentication state & JWT management
│   │   ├── views/                                        # Frontend UI views
│   │   │   ├── LandingView.tsx                           # Public landing page
│   │   │   ├── DashboardView.tsx                         # Executive technical debt dashboard
│   │   │   ├── ProjectsView.tsx                          # Repository inventory & dependency upload
│   │   │   ├── AssessmentsView.tsx                       # Assessment triggers & detail breakdowns
│   │   │   ├── HistoricalIntelligenceView.tsx            # Longitudinal memory & debt trends
│   │   │   ├── IntegrationsView.tsx                      # API settings & connection probes
│   │   │   ├── ScheduledReviewsView.tsx                  # Recurring review schedule management
│   │   │   ├── ReportsView.tsx                           # Audit logs & exportable debt reports
│   │   │   └── TeamView.tsx                              # Organization members & invitation modal
│   │   └── test/
│   │       └── components.test.tsx                       # Vitest UI component test suite
└── docs/
    ├── DATABASE_MIGRATION_GUIDE.md                       # Alembic migration procedures & history
    ├── DEPLOYMENT_GUIDE.md                               # Container orchestration & production deployment runbook
    ├── FINAL_AUDIT.md                                    # Comprehensive engineering audit signoff
    ├── FINAL_COMPLETION_REPORT.md                        # Master completion report & test matrix
    ├── INTEGRATION_GUIDE.md                              # Firecrawl, GenAI, and PostgreSQL memory guide
    ├── MEMENTO_INTEGRATION_GUIDE.md                      # Official Memento architecture & PostgreSQL store guide
    ├── SCHEDULER_ARCHITECTURE.md                         # Distributed locking, heartbeat, & transactional fencing
    ├── SECURITY_AUDIT.md                                 # Application security, threat modeling, & OWASP audit
    └── TESTING_REPORT.md                                 # Automated quality report & test breakdowns
```

---

## 4. Operational Runbook

To start the complete production stack:

```bash
# 1. Provide production environment credentials in .env
cp .env.example .env
# Edit .env with genuine non-placeholder secrets

# 2. Build and start services
docker compose up -d --build

# 3. Verify health status
docker compose ps

# 4. View logs
docker compose logs -f
```
