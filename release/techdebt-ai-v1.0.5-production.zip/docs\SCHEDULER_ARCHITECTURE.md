# TechDebt AI v1.0.5 — Distributed Scheduler Architecture

**Component:** Background Review Worker & Distributed Locking Engine  
**Product:** TechDebt AI – Technology Debt Review Assistant  
**Release Version:** v1.0.5  

---

## 1. Architectural Philosophy

TechDebt AI executes recurring and on-demand technical debt assessments across repositories containing hundreds of dependencies. In an enterprise deployment with multiple web API containers and worker replicas, background scheduling adheres to strict reliability and consistency principles:

1. **Process Separation:** The web API process (`uvicorn app.main:app`) handles user requests and NEVER initializes APScheduler. Background execution is strictly isolated to dedicated worker processes (`python -m app.worker`).
2. **Atomic Mutual Exclusion:** Only one worker can execute an assessment for a given project at any point in time.
3. **Genuine Transactional Fencing (`generation`):** Reclaiming an expired lease increments a monotonic generation counter. Protected writes are committed inside a transactional fencing guard (`assert_valid_fenced_lease_transactional`) using database row-level locking (`with_for_update`) and conditional SQL updates (`fencing_generation <= generation`).
4. **Stale-Write Rejection (`StaleGenerationWriteError`):** Stale workers holding expired or superseded leases are rejected at the database level and cannot overwrite results produced by newer generations.
5. **Active Lease Renewal:** Long-running assessments (>10 minutes) maintain active leases via a background heartbeat thread without premature lease expiration.
6. **Safe Abort on Lost Lease:** If a worker loses its lease (e.g. network partition, GC pause, or lease expiry), it rolls back all uncommitted mutations, suppresses status writes (e.g. will never falsely overwrite a newer worker's assessment with `status='failed'`), and terminates safely.

---

## 2. Distributed Locking Table Schema

The `distributed_locks` table stores lease state:

```sql
CREATE TABLE distributed_locks (
    lock_key VARCHAR(255) PRIMARY KEY,
    owner_id VARCHAR(255) NOT NULL,
    generation INTEGER NOT NULL DEFAULT 1,
    acquired_at TIMESTAMP NOT NULL,
    expires_at TIMESTAMP NOT NULL
);
```

Associated business tables carry `fencing_generation` columns (introduced in migration `002_transactional_fencing_and_memento_cleanup`):
- `assessments.fencing_generation` (INTEGER NOT NULL DEFAULT 1)
- `review_jobs.fencing_generation` (INTEGER NOT NULL DEFAULT 1)
- `historical_assessments.fencing_generation` (INTEGER NOT NULL DEFAULT 1)

---

## 3. Atomic Acquisition Algorithm

The acquisition mechanism in `backend/app/services/scheduler_service.py` prevents race conditions:

```python
def acquire_distributed_lock(db: Session, lock_key: str, owner_id: str, ttl_seconds: int = 600) -> bool:
    now = datetime.utcnow()
    expires_at = now + timedelta(seconds=ttl_seconds)

    # 1. Attempt atomic conditional UPDATE to reclaim expired lock
    updated = (
        db.query(DistributedLock)
        .filter(
            DistributedLock.lock_key == lock_key,
            DistributedLock.expires_at <= now
        )
        .update(
            {
                "owner_id": owner_id,
                "acquired_at": now,
                "expires_at": expires_at,
                "generation": DistributedLock.generation + 1
            },
            synchronize_session=False
        )
    )
    if updated > 0:
        db.commit()
        return True

    # 2. Check if an active, unexpired lock exists
    active = db.query(DistributedLock).filter(
        DistributedLock.lock_key == lock_key,
        DistributedLock.expires_at > now
    ).first()
    if active:
        db.rollback()
        return False

    # 3. No lock exists: atomically INSERT new lock with generation = 1
    new_lock = DistributedLock(
        lock_key=lock_key,
        owner_id=owner_id,
        generation=1,
        acquired_at=now,
        expires_at=expires_at
    )
    db.add(new_lock)
    db.commit()
    return True
```

---

## 4. Transactional Fencing and Stale-Write Protection

In v1.0.5, verification is transactional rather than a simple SELECT followed by an unbound commit:

```python
def assert_valid_fenced_lease_transactional(
    db: Session,
    lock_key: str,
    owner_id: str,
    expected_generation: int
) -> DistributedLock:
    now = datetime.utcnow()
    try:
        lock_rec = (
            db.query(DistributedLock)
            .filter(DistributedLock.lock_key == lock_key)
            .with_for_update()
            .first()
        )
    except Exception:
        lock_rec = db.query(DistributedLock).filter(DistributedLock.lock_key == lock_key).first()

    if not lock_rec:
        raise StaleGenerationWriteError("Lock record not found.")
    if lock_rec.owner_id != owner_id:
        raise StaleGenerationWriteError(f"Lock lost to owner '{lock_rec.owner_id}'.")
    if lock_rec.generation != expected_generation:
        raise StaleGenerationWriteError(f"Generation superseded by {lock_rec.generation}.")
    if lock_rec.expires_at <= now:
        raise StaleGenerationWriteError("Lease expired.")
    return lock_rec
```

### Protected Write Pattern:
All assessment persistence, technology scores, and historical memory snapshots run under the same guarded transaction with conditional SQL updates:
```python
db.query(Assessment).filter(
    Assessment.id == assessment.id,
    Assessment.fencing_generation <= expected_generation
).update({ ... "fencing_generation": expected_generation })
```
If rows updated == 0, `StaleGenerationWriteError` is raised and the transaction is aborted.

---

## 5. LockHeartbeat Lifecycle & Safe Abort

The `LockHeartbeat` runs as a dedicated daemon thread:
- **Interval:** Every 15 seconds (configurable).
- **Extension:** Extends `expires_at` by 600 seconds (10 minutes) on each pulse.
- **Verification:** Verifies `owner_id == worker_id` AND `generation == expected_generation`.
- **Bounded Retries:** If transient database errors occur, it retries up to 3 times before setting `lost_lock_event.set()`.
- **Safe Abort:** The worker checks `heartbeat.is_lock_lost()` before and after every network call. Stale workers rolling back will never update `status = "failed"`, preventing interference with the newer active worker.
        expires_at=expires_at
    )
    db.add(new_lock)
    db.commit()
    return True
```

### Why this eliminates race conditions:
- If two workers attempt to reclaim the same expired lock simultaneously, the database row-level locking ensures only ONE worker's conditional update (`WHERE expires_at <= now`) matches. The winning worker updates `expires_at` into the future; the second worker matches 0 rows and fails.
- If two workers attempt to insert a brand new lock simultaneously, the primary key constraint triggers an `IntegrityError` on the second worker, which catches the exception and cleanly returns `False`.

---

## 4. Ten Pipeline Checkpoints with Fencing Token Protection

During execution of `execute_project_review()`, the worker validates lease ownership and fencing token across 10 distinct execution stages:

```
[ Worker acquires lock: generation=K ]
        │
        ├─► Checkpoint 1: Pre-assessment record creation
        ├─► Checkpoint 2: Pre-technology iteration
        ├─► Checkpoint 3: Pre-intelligence gathering (per tech)
        ├─► Checkpoint 4: Post-intelligence gathering (per tech)
        ├─► Checkpoint 5: Pre-AI reasoning analysis (per tech)
        ├─► Checkpoint 6: Post-AI analysis & score record insertion
        ├─► Checkpoint 7: Pre-composite health score calculation
        ├─► Checkpoint 8: Pre-assessment & project status commit
        ├─► Checkpoint 9: Pre-historical snapshot creation
        └─► Checkpoint 10: Pre-completion commit
```

At every checkpoint, `assert_valid_fenced_lease()` verifies:
```python
active = db.query(DistributedLock).filter(
    DistributedLock.lock_key == lock_key,
    DistributedLock.owner_id == owner_id,
    DistributedLock.generation == expected_generation,
    DistributedLock.expires_at > datetime.utcnow()
).first()
if not active:
    db.rollback()
    raise RuntimeError(f"Fencing token validation failed: Worker {owner_id} lost lease.")
```

If the lease was lost or claimed by another worker, execution immediately halts, the database transaction rolls back, and no stale records are written.

---

## 5. LockHeartbeat Lifecycle

The `LockHeartbeat` runs as a dedicated daemon thread:
- **Interval:** Every 15 seconds (configurable).
- **Extension:** Extends `expires_at` by 600 seconds (10 minutes) on each pulse.
- **Verification:** Queries the database to verify `owner_id == worker_id` AND `generation == expected_generation`.
- **Bounded Retries:** If a transient database disconnection occurs, it retries up to 3 times with exponential backoff before flagging `lost_lock_event.set()`.
- **Safe Abort:** The worker checks `heartbeat.is_lock_lost()` before and after every network call.

