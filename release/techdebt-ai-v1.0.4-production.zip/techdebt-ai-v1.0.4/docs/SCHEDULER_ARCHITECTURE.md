# TechDebt AI v1.0.4 — Distributed Scheduler Architecture

**Component:** Background Review Worker & Distributed Locking Engine  
**Product:** TechDebt AI – Technology Debt Review Assistant  
**Release Version:** v1.0.4  

---

## 1. Architectural Philosophy

TechDebt AI executes recurring and on-demand technical debt assessments across repositories containing hundreds of dependencies. In an enterprise deployment with multiple web API containers and worker replicas, background scheduling must adhere to strict principles:

1. **Process Separation:** The web API process (`uvicorn app.main:app`) handles user requests and NEVER initializes APScheduler. Background execution is strictly isolated to dedicated worker processes (`python -m app.worker`).
2. **Atomic Mutual Exclusion:** Only one worker can execute an assessment for a given project at any point in time.
3. **Fencing Token (`generation`) Protection:** Reclaiming an expired lease increments a generation counter. Stale workers holding expired leases are prevented from committing results.
4. **Active Lease Renewal:** Long-running assessments (>10 minutes) maintain active leases via a background heartbeat thread without premature lease expiration.
5. **Safe Abort on Lost Lease:** If a worker loses its lease (e.g. network partition or database failure), it must abort execution and suppress status writes, avoiding split-brain corruption.

---

## 2. Distributed Locking Table Schema

The `distributed_locks` table stores lease state:

```sql
CREATE TABLE distributed_locks (
    lock_key VARCHAR(255) PRIMARY KEY,
    owner_id VARCHAR(255) NOT NULL,
    generation INTEGER NOT NULL DEFAULT 1,
    acquired_at TIMESTAMP NOT NULL,
    expires_at TIMESTAMP NOT NULL
);
```

---

## 3. Atomic Acquisition Algorithm

The acquisition mechanism in `backend/app/services/scheduler_service.py` prevents race conditions:

```python
def acquire_distributed_lock(db: Session, lock_key: str, owner_id: str, ttl_seconds: int = 600) -> bool:
    now = datetime.utcnow()
    expires_at = now + timedelta(seconds=ttl_seconds)

    # 1. Attempt atomic conditional UPDATE to reclaim expired lock
    updated = (
        db.query(DistributedLock)
        .filter(
            DistributedLock.lock_key == lock_key,
            DistributedLock.expires_at <= now
        )
        .update(
            {
                "owner_id": owner_id,
                "acquired_at": now,
                "expires_at": expires_at,
                "generation": DistributedLock.generation + 1
            },
            synchronize_session=False
        )
    )
    if updated > 0:
        db.commit()
        return True

    # 2. Check if an active, unexpired lock exists
    active = db.query(DistributedLock).filter(
        DistributedLock.lock_key == lock_key,
        DistributedLock.expires_at > now
    ).first()
    if active:
        return False

    # 3. No lock exists: atomically INSERT new lock with generation = 1
    new_lock = DistributedLock(
        lock_key=lock_key,
        owner_id=owner_id,
        generation=1,
        acquired_at=now,
        expires_at=expires_at
    )
    db.add(new_lock)
    db.commit()
    return True
```

### Why this eliminates race conditions:
- If two workers attempt to reclaim the same expired lock simultaneously, the database row-level locking ensures only ONE worker's conditional update (`WHERE expires_at <= now`) matches. The winning worker updates `expires_at` into the future; the second worker matches 0 rows and fails.
- If two workers attempt to insert a brand new lock simultaneously, the primary key constraint triggers an `IntegrityError` on the second worker, which catches the exception and cleanly returns `False`.

---

## 4. Ten Pipeline Checkpoints with Fencing Token Protection

During execution of `execute_project_review()`, the worker validates lease ownership and fencing token across 10 distinct execution stages:

```
[ Worker acquires lock: generation=K ]
        │
        ├─► Checkpoint 1: Pre-assessment record creation
        ├─► Checkpoint 2: Pre-technology iteration
        ├─► Checkpoint 3: Pre-intelligence gathering (per tech)
        ├─► Checkpoint 4: Post-intelligence gathering (per tech)
        ├─► Checkpoint 5: Pre-AI reasoning analysis (per tech)
        ├─► Checkpoint 6: Post-AI analysis & score record insertion
        ├─► Checkpoint 7: Pre-composite health score calculation
        ├─► Checkpoint 8: Pre-assessment & project status commit
        ├─► Checkpoint 9: Pre-historical snapshot creation
        └─► Checkpoint 10: Pre-completion commit
```

At every checkpoint, `assert_valid_fenced_lease()` verifies:
```python
active = db.query(DistributedLock).filter(
    DistributedLock.lock_key == lock_key,
    DistributedLock.owner_id == owner_id,
    DistributedLock.generation == expected_generation,
    DistributedLock.expires_at > datetime.utcnow()
).first()
if not active:
    db.rollback()
    raise RuntimeError(f"Fencing token validation failed: Worker {owner_id} lost lease.")
```

If the lease was lost or claimed by another worker, execution immediately halts, the database transaction rolls back, and no stale records are written.

---

## 5. LockHeartbeat Lifecycle

The `LockHeartbeat` runs as a dedicated daemon thread:
- **Interval:** Every 15 seconds (configurable).
- **Extension:** Extends `expires_at` by 600 seconds (10 minutes) on each pulse.
- **Verification:** Queries the database to verify `owner_id == worker_id` AND `generation == expected_generation`.
- **Bounded Retries:** If a transient database disconnection occurs, it retries up to 3 times with exponential backoff before flagging `lost_lock_event.set()`.
- **Safe Abort:** The worker checks `heartbeat.is_lock_lost()` before and after every network call.
